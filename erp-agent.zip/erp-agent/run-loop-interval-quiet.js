// 재고/매출 갱신을 일정 간격으로 계속 반복하되, 조용한 시간대(매장 미운영 시간)에는
// 건너뛰는 버전입니다. 기존 run-loop-interval.js랑 같은 방식으로 부르면 됩니다:
//   node run-loop-interval-quiet.js <스크립트파일> <간격(분)>
//
// 조용한 시간대는 아래 QUIET_START/QUIET_END에서 고정값으로 관리합니다 (기본: 00:30~09:30).

const { spawn } = require("child_process");
const path = require("path");

const scriptFile = process.argv[2];
const intervalMin = Number(process.argv[3] || 15);
const intervalMs = intervalMin * 60 * 1000;

const QUIET_START = { hour: 0, minute: 30 }; // 00:30
const QUIET_END = { hour: 9, minute: 30 }; // 09:30

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function isQuietHours() {
  const now = new Date();
  const curMin = now.getHours() * 60 + now.getMinutes();
  const startMin = QUIET_START.hour * 60 + QUIET_START.minute;
  const endMin = QUIET_END.hour * 60 + QUIET_END.minute;
  return curMin >= startMin && curMin < endMin;
}

function runOnce() {
  if (isQuietHours()) {
    log(`조용한 시간대(00:30~09:30)라 건너뜁니다. (${scriptFile})`);
    return;
  }
  log(`실행: ${scriptFile}`);
  const child = spawn("node", [path.join(__dirname, scriptFile)], {
    cwd: __dirname,
    env: process.env,
  });
  child.stdout.on("data", (d) => process.stdout.write(d));
  child.stderr.on("data", (d) => process.stderr.write(d));
  child.on("exit", (code) => {
    if (code !== 0) log(`⚠ ${scriptFile} 비정상 종료 (코드 ${code})`);
  });
}

if (!scriptFile) {
  console.error("사용법: node run-loop-interval-quiet.js <스크립트파일> <간격(분)>");
  process.exit(1);
}

log(`시작합니다. ${intervalMin}분마다 ${scriptFile} 실행 (00:30~09:30은 건너뜀).`);
runOnce();
setInterval(runOnce, intervalMs);
