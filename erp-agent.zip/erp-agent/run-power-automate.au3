; Power Automate Desktop 흐름(erp_daily)을 자동으로 실행하는 스크립트 - v4
;
; MARK: v2는 창을 "항상 같은 좌표로 강제 이동"하는 방식이었는데, 실제로는 창이 뜨는
; 위치가 매번 다를 수 있다는 걸 확인했습니다. v3는 실행마다 실제 창 위치(WinGetPos)를
; 확인해서 절대 픽셀 오프셋을 더하는 방식으로 바꿨는데, 2026-09-20 새벽에 그 절대
; 오프셋 자체가(특히 검색창 x=1673) 이 PC의 실제 창 너비(약 1456px)보다 커서 창 밖을
; 클릭하는 사고로 이어졌습니다(아래 v4 설명 참고).
;
; v4는 이 문제를 근본적으로 고칩니다:
;   1. 절대 픽셀 오프셋 대신, "흐름 실행" 확인 팝업 처리에서 이미 쓰던 것과 같은 방식 —
;      창 크기 대비 비율(%)로 좌표를 계산합니다. 해상도/DPI가 달라져도 항상 창 안의
;      같은 상대 위치를 클릭합니다.
;   2. "목록에서 줄 클릭 → 툴바의 실행 버튼 클릭" 2단계를, 검색으로 필터링된 흐름 자체의
;      "▷ 실행" 아이콘 1번 클릭으로 단순화했습니다. 다른 흐름들의 체크박스/선택 상태와
;      무관하게 그 흐름 하나만 실행됩니다.
;
; 또한 파워오토메이트(WPF 기반)가 창이 뜨자마자 바로 조작하면 내부 오류로 죽는 경우가
; 있어서("이 Visual이 PresentationSource에 연결되지 않았습니다"), 창이 완전히 자리잡을
; 때까지 넉넉하게 기다립니다.
;
; MARK 2026-09-21 안전장치 추가 (사고 발생 — 다행히 미수 그침):
; 2026-09-20 새벽 2:25, 3:35 두 번 다 검색 필터링이 안 먹혀서(위 원인) 흐름 목록 5개가
; 전부 선택된 채로 "실행" 버튼 좌표를 눌렀고, 그 좌표가 하필 다중선택 상태의 툴바에서는
; "삭제" 버튼 자리와 겹쳐서 "흐름 삭제" 확인 팝업이 떴습니다. 팝업 기본 포커스가
; "아니요"라 실제로 삭제되지는 않았지만(다행), 스크립트는 이걸 감지 못 하고 그냥
; 스크린샷만 찍고 "완료"로 끝나버렸습니다. 실제로 화면을 열어서 재현/실측해서 위 v4
; 방식으로 근본 원인을 고쳤고, 혹시 모를 상황 대비로 이 감지+취소 안전장치도 남겨뒀습니다.

#include <MsgBoxConstants.au3>
#include <ScreenCapture.au3>

; MARK: 새벽에 모니터가 절전으로 꺼져있으면 자동화 입력이 잘 안 먹힐 수 있어서, 맨 처음에
; 마우스를 살짝 움직이고 무해한 키를 하나 눌러서 화면을 깨웁니다.
MouseMove(100, 100, 0)
Sleep(200)
MouseMove(300, 300, 0)
Sleep(200)
Send("{SHIFT}")
Sleep(2000)

; ===== 설정 =====
Local $sFlowName = "erp_daily"
; MARK 2026-09-21: 절대좌표 대신 창 크기 대비 비율(2026-09-21 실측: 1456x819 창에서
; 검색창 중심 (1300,120), 필터링된 흐름의 자체 "실행" 아이콘 (505,200) 기준으로 계산).
Local $fSearchRatioX = 0.893, $fSearchRatioY = 0.1465 ; 검색창
Local $fRunIconRatioX = 0.347, $fRunIconRatioY = 0.244 ; 필터링된 흐름 줄의 자체 "실행"(▷) 아이콘

; ===== 1단계: 파워오토메이트 데스크톱 앱 실행 =====
ConsoleWrite("Power Automate Desktop 앱 실행 중..." & @CRLF)
Run("explorer.exe shell:AppsFolder\Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Console")

ConsoleWrite("창 뜨는 중 기다리는 중..." & @CRLF)
Local $hWin = WinWait("Power Automate", "", 30)
If $hWin = 0 Then
    ConsoleWrite("⚠ Power Automate 창을 30초 안에 못 찾았어요." & @CRLF)
    Exit 1
EndIf

; MARK: 창이 뜨자마자 바로 건드리면 파워오토메이트가 내부 오류로 죽을 수 있어서, 화면이
; 완전히 그려질 시간을 넉넉하게 기다립니다.
ConsoleWrite("창이 완전히 뜰 때까지 여유있게 기다리는 중..." & @CRLF)
Sleep(3000)

; ===== 2단계: 창 위치 확인 =====
; MARK: 예전엔 여기서 WinSetState(@SW_MAXIMIZE)로 직접 최대화시켰는데, 이 동작 자체가
; 파워오토메이트(WPF 기반) 앱을 내부 오류로 죽이는 원인이었던 것으로 확인됐습니다
; ("이 Visual이 PresentationSource에 연결되지 않았습니다"). 파워오토메이트는 마지막
; 창 크기/상태를 기억하기 때문에, 사용자가 손으로 한 번 최대화해두면 그다음부턴 항상
; 최대화된 채로 뜹니다 — 그래서 프로그램으로 최대화시키지 않고, 이미 최대화되어 있다고
; 보고 그냥 현재 위치만 확인합니다.
ConsoleWrite("창 위치 확인 중 (최대화는 사용자가 미리 설정해두신 상태를 그대로 씁니다)..." & @CRLF)
WinActivate($hWin)
Sleep(1000)

Local $aWinPos = WinGetPos($hWin)
If Not IsArray($aWinPos) Then
    ConsoleWrite("⚠ 창 위치를 못 가져왔어요." & @CRLF)
    Exit 1
EndIf
ConsoleWrite("🔍 [진단] 창 위치: " & $aWinPos[0] & "," & $aWinPos[1] & " 크기: " & $aWinPos[2] & "x" & $aWinPos[3] & @CRLF)

Local $iSearchX = $aWinPos[0] + Int($aWinPos[2] * $fSearchRatioX)
Local $iSearchY = $aWinPos[1] + Int($aWinPos[3] * $fSearchRatioY)
Local $iRunIconX = $aWinPos[0] + Int($aWinPos[2] * $fRunIconRatioX)
Local $iRunIconY = $aWinPos[1] + Int($aWinPos[3] * $fRunIconRatioY)
ConsoleWrite("🔍 [진단] 계산된 좌표 — 검색창: " & $iSearchX & "," & $iSearchY & " / 실행아이콘: " & $iRunIconX & "," & $iRunIconY & @CRLF)

; ===== 3단계: 검색창에 흐름 이름 입력해서 필터링 =====
ConsoleWrite("검색창 클릭 후 '" & $sFlowName & "' 입력 중..." & @CRLF)
; MARK 2026-09-21: 싱글클릭만으로는 가끔 검색창이 포커스를 못 받는 걸 실측으로 확인해서,
; 더블클릭으로 한 번 더 확실하게 포커스를 잡습니다.
MouseClick("left", $iSearchX, $iSearchY, 2)
Sleep(500)
Send("^a") ; 기존 검색어 있으면 지우고 새로 입력
Send("{DEL}")
Sleep(200)
Send($sFlowName)
Sleep(1000) ; 필터링 결과 뜰 시간

; ===== 4단계: 필터링된 흐름의 자체 "실행" 아이콘 클릭 =====
; MARK 2026-09-21: 목록에서 줄을 따로 클릭해서 선택한 다음 툴바의 실행 버튼을 누르는
; 대신, 필터링된 흐름 자체의 "▷ 실행" 아이콘을 바로 클릭합니다. 체크박스/다중선택
; 상태와 무관하게 그 흐름 하나만 실행되고, 다른 흐름이 선택된 채 엉뚱한 툴바 버튼
; (삭제 등)을 누르게 될 위험이 구조적으로 없습니다.
ConsoleWrite("필터링된 흐름의 '실행'(▷) 아이콘 클릭 중..." & @CRLF)
MouseMove($iRunIconX, $iRunIconY, 5) ; MARK: 마우스를 올려야 아이콘이 나타나는 행일 수 있어 먼저 살짝 이동
Sleep(300)
MouseClick("left", $iRunIconX, $iRunIconY, 1)
Sleep(1500)

; ===== 5단계: 위험한 "흐름 삭제" 팝업부터 최우선으로 확인 (안전장치) =====
; MARK 2026-09-21: 혹시 모를 상황에 대비한 이중 안전장치입니다. 이 팝업이 뜨면 절대
; 그냥 넘어가지 않고, 즉시 ESC(=취소, 기본 포커스인 "아니요"와 동일한 효과)를 눌러
; 취소한 뒤 실패로 중단합니다.
ConsoleWrite("🔍 위험한 '흐름 삭제' 팝업이 떴는지부터 확인 중..." & @CRLF)
Local $hDangerWin = WinWait("흐름 삭제", "", 3)
If $hDangerWin <> 0 Then
    ConsoleWrite("🚨 [위험] '흐름 삭제' 확인 팝업 감지! 즉시 취소합니다." & @CRLF)
    WinActivate($hDangerWin)
    Sleep(300)
    Send("{ESC}") ; MARK: ESC는 표준 Windows 대화상자에서 항상 "취소"와 동일 — 기본 포커스가 뭐든 안전
    Sleep(500)
    Local $sDangerPath = @DesktopDir & "\위험_흐름삭제팝업_" & @YEAR & @MON & @MDAY & "_" & @HOUR & @MIN & @SEC & ".png"
    _ScreenCapture_Capture($sDangerPath)
    ConsoleWrite("🔍 [진단] 위험 상황 스크린샷 저장: " & $sDangerPath & @CRLF)
    ConsoleWrite("⚠ 파워오토메이트 흐름은 실행되지 않았습니다. 좌표 재측정이 필요합니다 — 수동으로 확인해주세요." & @CRLF)
    Exit 2
EndIf
ConsoleWrite("위험한 팝업 없음 — 정상 진행합니다." & @CRLF)

; ===== 6단계: "흐름 실행" 확인 팝업 처리 =====
; MARK: 앱 안에서 "실행" 버튼을 눌러도, 이 흐름 자체가 "외부에서 가져온 것"으로
; 등록되어 있는지 매번 "외부 원본에서 다음 흐름을 실행하려고 합니다 / 계속" 확인
; 팝업이 뜨는 걸로 확인됐습니다. 그냥 넘어가지 말고, 뜨면 "계속" 버튼을 클릭합니다.
; 이 팝업은 WPF 기반이라 ControlClick으로 버튼을 특정하기 어려워서, 팝업 창 크기 대비
; 비율로 "계속" 버튼 위치를 계산해서 클릭합니다(이 부분은 원래부터 비율 기반이라 이번
; 사고와 무관하게 잘 동작했습니다).
ConsoleWrite("'흐름 실행' 확인 팝업 뜨는지 확인 중..." & @CRLF)
Local $hConfirmWin = WinWait("흐름 실행", "", 8)
If $hConfirmWin <> 0 Then
    ConsoleWrite("확인 팝업 떴어요 — '계속' 버튼 클릭 시도..." & @CRLF)
    WinActivate($hConfirmWin)
    Sleep(500)
    Local $aConfirmPos = WinGetPos($hConfirmWin)
    If IsArray($aConfirmPos) Then
        Local $iContinueX = $aConfirmPos[0] + Int($aConfirmPos[2] * 0.74)
        Local $iContinueY = $aConfirmPos[1] + Int($aConfirmPos[3] * 0.80)
        MouseClick("left", $iContinueX, $iContinueY, 1)
        Sleep(1000)
    Else
        ConsoleWrite("⚠ 팝업 위치를 못 가져와서 Enter로 대신 시도합니다..." & @CRLF)
        Send("{ENTER}")
        Sleep(1000)
    EndIf
Else
    ConsoleWrite("확인 팝업 안 떴어요 — 그대로 진행합니다." & @CRLF)
EndIf

ConsoleWrite("✅ 완료! 파워오토메이트 흐름이 실행되기 시작했을 거예요." & @CRLF)

; MARK: 디버그용 — 여기까지 진행된 화면 상태를 바탕화면에 스크린샷으로 남깁니다.
; 스크린샷은 화면을 그대로 읽어오기만 하는 거라(마우스/키보드 입력을 보내는 게 아님)
; 파워오토메이트 실행 중이어도 전혀 방해되지 않습니다.
Local $sDebugPath = @DesktopDir & "\디버그_PA실행_" & @YEAR & @MON & @MDAY & "_" & @HOUR & @MIN & @SEC & ".png"
_ScreenCapture_Capture($sDebugPath)
ConsoleWrite("🔍 [디버그] 스크린샷 저장: " & $sDebugPath & @CRLF)
