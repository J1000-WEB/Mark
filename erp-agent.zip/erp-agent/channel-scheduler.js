// 채널 하나(한컬렉션/롯데면세/무신사 중 하나)를 독립적으로 여러 시간대에 재시도하고,
// 성공하면 결과를 캐시 파일(cache/채널명_YYYYMMDD.json)로 저장하는 범용 스케줄러입니다.
//
// 채널마다 정기점검 시간대가 달라서(면세는 00시~02시 확실히 안 됨, 한컬렉션은 시간대
// 불명확) 채널별로 완전히 독립적인 시간표를 갖도록 분리했습니다. 실제 최종 파일 합치기는
// merge-inshop.js가 따로 주기적으로 돌면서, 그때까지 캐시된 채널들만 모아서 만듭니다.
//
// 사용법 (직접 실행 안 하고, channel-*.js 파일들이 이 파일을 불러다 씁니다):
//   const { runChannelScheduler } = require("./channel-scheduler.js");
//   runChannelScheduler({ channelName: "한컬렉션", retryHours: [1,2,5], fetchFn: fetchHancollection });

const fs = require("fs");
const path = require("path");

const CACHE_DIR = path.join(__dirname, "cache");
if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

function log(prefix, ...args) {
  console.log(`[${prefix}] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
}

function yesterdayString() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
}

function cacheFilePath(channelKey, dateStr) {
  return path.join(CACHE_DIR, `${channelKey}_${dateStr}.json`);
}

function saveCache(channelKey, dateStr, rows) {
  fs.writeFileSync(cacheFilePath(channelKey, dateStr), JSON.stringify(rows), "utf8");
}

function hasCache(channelKey, dateStr) {
  return fs.existsSync(cacheFilePath(channelKey, dateStr));
}

// channelKey: 캐시 파일명에 쓸 영문 키 (예: "hankollection", "lotte", "musinsa")
// channelName: 로그에 표시할 한글 이름 (예: "한컬렉션")
// retryHours: 이 채널을 시도할 시(24시간제) 배열, 오름차순 (예: [1,2,5])
// fetchFn: async (fromDate, toDate) => rows[]  — build-inshop-upload.js의 fetch 함수
function runChannelScheduler({ channelKey, channelName, retryHours, fetchFn }) {
  let lastAttemptedSlot = null;

  async function attempt(hour) {
    const dateStr = yesterdayString(); // 인샵매출은 항상 "어제"치를 조회함 (build-inshop-upload.js와 동일한 규칙)
    if (hasCache(channelKey, dateStr)) {
      log(channelName, "이미 오늘 성공해서 캐시가 있어요 — 건너뜁니다.");
      return;
    }
    log(channelName, `${hour}시가 되어 시도합니다...`);
    try {
      const rows = await fetchFn(dateStr, dateStr);
      if (!rows || !rows.length) throw new Error("결과가 0건이에요.");
      saveCache(channelKey, dateStr, rows);
      log(channelName, `✅ 성공! ${rows.length}건 캐시 저장.`);
    } catch (err) {
      log(channelName, `⚠ 실패: ${err.message || err}`);
      const remaining = retryHours.filter((h) => h > hour);
      if (remaining.length) {
        log(channelName, `다음 예정 시간(${remaining[0]}시)에 재시도합니다.`);
      } else {
        log(channelName, "오늘 예정된 재시도를 다 썼어요. 수동으로 확인해주세요.");
      }
    }
  }

  function tick() {
    const now = new Date();
    const hour = now.getHours();
    if (!retryHours.includes(hour)) return;
    const slotKey = `${todayString()}-${hour}`;
    if (lastAttemptedSlot === slotKey) return;
    lastAttemptedSlot = slotKey;
    attempt(hour);
  }

  log(channelName, `스케줄러 시작. 시도 예정 시간: [${retryHours.join(", ")}시]`);
  setInterval(tick, 60 * 1000);
  tick();
}

module.exports = { runChannelScheduler, saveCache, hasCache, cacheFilePath, todayString, yesterdayString, CACHE_DIR };
