// 무신사 화면 요소 진단 스크립트
//
// 완전자동화(진짜 클릭 재현)를 만들려면 어느 입력칸/버튼을 눌러야 하는지 알아야 해서,
// 화면에 있는 input/button 요소들의 정보(id, class, placeholder 등)를 뽑아봅니다.
//
// 실행: node inspect-musinsa-page.js
//
// 1단계: 로그인 화면 요소를 자동으로 찍습니다.
// 2단계: 직접 로그인 + 매출재고조회 화면까지 이동해주시면(조회 버튼은 누르지 마세요),
//        Enter 누르시면 그 화면 요소도 찍습니다.

const puppeteer = require("puppeteer");

async function dumpElements(page, label) {
  const info = await page.evaluate(() => {
    function describe(el) {
      return {
        tag: el.tagName,
        id: el.id || null,
        name: el.getAttribute("name") || null,
        type: el.getAttribute("type") || null,
        class: el.className || null,
        placeholder: el.getAttribute("placeholder") || null,
        text: (el.innerText || el.value || "").trim().slice(0, 30) || null,
        visible: el.offsetWidth > 0 && el.offsetHeight > 0,
      };
    }
    const inputs = Array.from(document.querySelectorAll("input")).map(describe);
    const buttons = Array.from(document.querySelectorAll("button, [role='button'], a")).map(describe);
    const divsWithClick = Array.from(document.querySelectorAll("div[onclick], span[onclick]")).map(describe);

    // MARK: Nexacro는 버튼을 <button> 태그로 안 그리고, div/span에 이벤트를 addEventListener로
    // 붙이는 경우가 많아서 위 방식으론 못 잡습니다 — "로그인"/"조회" 같은 글자가 직접 들어있는
    // 요소(자식이 아니라 그 요소 "자신"의 텍스트)를 전부 찾아서, 어느 걸 눌러야 할지 좁힙니다.
    const KEYWORDS = ["로그인", "조회", "검색", "인증", "확인", "다운로드", "정산"];
    const textMatches = [];
    document.querySelectorAll("*").forEach((el) => {
      const ownText = Array.from(el.childNodes)
        .filter((n) => n.nodeType === 3) // TEXT_NODE
        .map((n) => n.textContent.trim())
        .join("")
        .trim();
      if (!ownText) return;
      if (KEYWORDS.some((k) => ownText.includes(k))) {
        textMatches.push({
          tag: el.tagName,
          id: el.id || null,
          class: el.className || null,
          ownText,
          visible: el.offsetWidth > 0 && el.offsetHeight > 0,
          parentId: el.parentElement?.id || null,
        });
      }
    });

    return { inputs, buttons: buttons.slice(0, 60), divsWithClick: divsWithClick.slice(0, 30), textMatches };
  });

  console.log(`\n========== [${label}] 입력칸(input) ==========`);
  console.log(JSON.stringify(info.inputs, null, 2));
  console.log(`\n========== [${label}] 버튼류(button/a) — 최대 60개 ==========`);
  console.log(JSON.stringify(info.buttons, null, 2));
  console.log(`\n========== [${label}] onclick 달린 div/span — 최대 30개 ==========`);
  console.log(JSON.stringify(info.divsWithClick, null, 2));
  console.log(`\n========== [${label}] "로그인"/"조회"/"검색" 글자가 들어간 요소 ==========`);
  console.log(JSON.stringify(info.textMatches, null, 2));
}

async function main() {
  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();

  await page.goto("https://partner.musinsa.com/", { waitUntil: "networkidle2" });
  await new Promise((r) => setTimeout(r, 2000)); // 화면 렌더링 시간 대기

  await dumpElements(page, "로그인 화면");

  console.log("\n============================================");
  console.log(" 이제 직접 로그인(아이디/비번/OTP)까지 완료해주세요.");
  console.log(" (그 다음 화면까지만 가시면 됩니다 — 매출 다운로드 버튼은 아직 누르지 마세요)");
  console.log(" 다 되면 이 CMD 창에서 Enter 키를 눌러주세요.");
  console.log("============================================\n");
  await new Promise((resolve) => {
    process.stdin.resume();
    process.stdin.once("data", resolve);
  });

  await dumpElements(page, "로그인 후 화면");

  console.log("\n진단 완료. 위 내용을 전체 복사해서 보내주세요. (Ctrl+C로 종료하셔도 됩니다)");
  await new Promise(() => {});
}

main().catch((err) => {
  console.error("⚠ 실패:", err.message || err);
  process.exit(1);
});
