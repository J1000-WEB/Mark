// 과거 ERP "매출일보" 원본 파일들을, 지금 새벽 자동화(build-inshop-upload.js)가 만드는
// "인샵매출YYYYMMDD.xlsx"와 완전히 같은 형식으로 변환합니다. 그대로 sgerp-login.exe로
// ERP 업로드하실 수 있게, 날짜별로 파일을 따로따로 나눠서 만듭니다(한 파일에 여러 날짜가
// 섞여있으면 ERP 업로드 화면의 "판매일자" 칸 하나로 전체가 잘못 들어갈 수 있어서요).
//
// 사용법:
//   node convert-maechul-to-upload.js 파일1.xls 파일2.xls ... (여러 개 한번에 가능)
//   node convert-maechul-to-upload.js 폴더경로                 (폴더 안 파일 전부)
//
// 결과: 바탕화면에 "인샵매출YYYYMMDD.xlsx" 형태로 날짜별 저장 (기존 파일 있으면 병합)

const fs = require("fs");
const path = require("path");
const os = require("os");
const XLSX = require("xlsx");
const { fixFullColorNameToCode, fixOldStyleSizeColorOrder } = require("./build-inshop-upload.js");

const CHANNEL_CODE_HANCOL = "81026";
const HEADER_SEARCH_NAMES = ["매입거래처\n상품코드", "매입거래처상품코드"];
const MAX_HEADER_SEARCH_ROWS = 15;

function log(...args) {
  console.log(`[매출일보변환] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function excelSerialToYYYYMMDD(serial) {
  // 엑셀 날짜 일련번호(1899-12-30 기준) → "YYYYMMDD" 문자열
  const utcMs = Math.round((Number(serial) - 25569) * 86400 * 1000);
  const d = new Date(utcMs);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${y}${m}${day}`;
}

function fixBarcode(barcode) {
  let b = String(barcode || "").trim();
  if (!b) return b;
  if (b.includes("_")) b = b.split("_")[0];
  if (b.length >= 13) {
    const r1 = fixFullColorNameToCode(b);
    if (r1.changed) b = r1.fixed;
  }
  const r2 = fixOldStyleSizeColorOrder(b);
  if (r2.changed) b = r2.fixed;
  return b;
}

// 헤더 행을 찾아서 { headerRowIndex, colIndexes } 반환
function findColumns(rows) {
  for (let r = 0; r < Math.min(MAX_HEADER_SEARCH_ROWS, rows.length); r++) {
    const row = rows[r];
    const barcodeColIdx = row.findIndex((c) => HEADER_SEARCH_NAMES.some((n) => String(c || "").replace(/\s/g, "") === n.replace(/\s/g, "")));
    if (barcodeColIdx >= 0) {
      // 이 헤더 행 기준으로, 알고 있는 상대 위치로 나머지 컬럼도 찾습니다
      // (실측 기준: 스타일=5, 칼라=8, SIZE=9, 매입거래처상품코드=10, 정상판매가=14,
      //  실판매가=16, 판매수량=17, 판매일자=3)
      return {
        headerRowIndex: r,
        dateCol: 3,
        styleCol: 5,
        colorCol: 8,
        sizeCol: 9,
        barcodeCol: barcodeColIdx,
        priceCol: 16,
        qtyCol: 17,
      };
    }
  }
  return null;
}

function buildBarcodeFromParts(styleCode, colorCode, size) {
  const cleanSize = String(size || "").replace(/^0+/, "") || String(size || "");
  return `${styleCode}${colorCode}${cleanSize}`;
}

// 파일 하나를 읽어서 [{date, barcode, qty, price}, ...] 배열로 변환
function parseFile(filePath) {
  const wb = XLSX.readFile(filePath);
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: "" });

  const cols = findColumns(rows);
  if (!cols) {
    log(`  ⚠ ${path.basename(filePath)}: 헤더를 못 찾아서 건너뜁니다.`);
    return [];
  }

  const result = [];
  for (let i = cols.headerRowIndex + 1; i < rows.length; i++) {
    const r = rows[i];
    const styleCode = String(r[cols.styleCol] || "").trim();
    if (!styleCode) continue; // 요약행/빈행 건너뜀

    const dateSerial = r[cols.dateCol];
    if (!dateSerial) continue;
    const date = typeof dateSerial === "number" ? excelSerialToYYYYMMDD(dateSerial) : String(dateSerial).replace(/[^0-9]/g, "");

    let barcode = String(r[cols.barcodeCol] || "").trim();
    if (barcode) {
      barcode = fixBarcode(barcode);
    } else {
      // 매입거래처상품코드가 비어있으면 스타일+칼라+사이즈로 직접 만듭니다
      const colorCode = String(r[cols.colorCol] || "").trim();
      const size = String(r[cols.sizeCol] || "").trim();
      barcode = buildBarcodeFromParts(styleCode, colorCode, size);
    }
    if (!barcode) continue;

    const qty = Number(r[cols.qtyCol] || 0);
    const price = Number(r[cols.priceCol] || 0);
    if (!qty) continue; // 수량 0인 행은 제외(반품은 마이너스라 포함됨)

    result.push({ date, barcode, qty, price });
  }
  return result;
}

function saveAllInOne(allRows, outFileName) {
  const desktopDir = path.join(os.homedir(), "Desktop");
  const outPath = path.join(desktopDir, outFileName);

  const mapped = allRows.map((r) => ({
    일자: r.date,
    POS: "P1",
    채널: CHANNEL_CODE_HANCOL,
    바코드: r.barcode,
    수량: r.qty,
    단가: r.price,
    출처: "한컬렉션(과거데이터)",
    확인필요: r.barcode.length >= 15 ? "Y (바코드 15자 이상)" : "",
  }));

  const ws = XLSX.utils.json_to_sheet(mapped);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "UPLOAD");
  XLSX.writeFile(wb, outPath);

  log(`✅ 전체 ${mapped.length}건 저장 → ${outPath}`);
}

function main() {
  const args = process.argv.slice(2);
  if (!args.length) {
    console.error("사용법: node convert-maechul-to-upload.js 파일1.xls [파일2.xls ...] 또는 폴더경로");
    process.exit(1);
  }

  let files = [];
  for (const arg of args) {
    const stat = fs.statSync(arg);
    if (stat.isDirectory()) {
      const inDir = fs.readdirSync(arg).filter((f) => {
        const lower = f.toLowerCase();
        return (lower.endsWith(".xlsx") || lower.endsWith(".xls")) && !lower.endsWith(".bak");
      });
      files.push(...inDir.map((f) => path.join(arg, f)));
    } else {
      files.push(arg);
    }
  }

  log(`총 ${files.length}개 파일 변환 시작...`);
  const allRows = [];
  for (const f of files) {
    log(`처리 중: ${f}`);
    const parsed = parseFile(f);
    log(`  ${parsed.length}건 추출됨.`);
    allRows.push(...parsed);
  }

  const dates = [...new Set(allRows.map((r) => r.date))].sort();
  log(`포함된 날짜: ${dates.join(", ")}`);
  saveAllInOne(allRows, "인샵매출_한컬과거데이터.xlsx");
  log("✅ 전체 완료. 바탕화면에서 파일을 확인해주세요.");
}

main();
