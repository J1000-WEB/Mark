// MARK ERP Agent — 공용 모듈 (MARK 6.71)
//
// daily-snapshot.js / stock-refresh.js / sales-refresh.js가 공통으로 쓰는
// 로그인·API 호출·사이즈 매핑·매장목록·상품목록 로직을 여기 한 곳에 모아둡니다.
// 이 파일 하나만 고치면 세 스크립트에 다 반영돼요 (예전엔 daily-snapshot.js
// 안에만 있어서 재사용이 안 됐음).

const fs = require("fs");
const path = require("path");
const https = require("https");
const querystring = require("querystring");

function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}
loadEnvFile();

const ERP_USER = process.env.ERP_USER;
const ERP_PASS = process.env.ERP_PASS;
const ERP_HOST = "gim.sgerp.com";
const COMP_CD = process.env.ERP_COMP_CD || "GI001";
const PRODUCT360_TOKEN = process.env.PRODUCT360_TOKEN_OBT;
const MARK_BASE_URL = process.env.MARK_BASE_URL || "http://localhost:3000";

// 오프라인으로 취급할 채널 그룹 (common/getGiCfCode.do, GBN_CD=SL008 기준)
// 2=로드샵, 3=백화점, 4=아울렛, 5=쇼핑몰
const OFFLINE_SHOP_GB = ["2", "3", "4", "5"];

const CONCURRENCY = Number(process.env.ERP_CONCURRENCY || 6); // 동시에 몇 개씩 호출할지
const REQUEST_DELAY_MS = Number(process.env.ERP_DELAY_MS || 50); // 각 배치 사이 살짝 쉬는 시간

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" })}]`, ...args);
}

function todayKST(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  // en-CA 로케일은 YYYY-MM-DD 형식으로 나옴
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Seoul" }).format(d).replace(/-/g, "");
}

// ERP는 sale_dt 파라미터로 YYYYMMDD(하이픈 없음)를 쓰지만,
// MARK 업로드 API(/api/erp-daily-sales-import)는 YYYY-MM-DD(하이픈 있음)만 받음 — 변환 필요.
function toIsoDate(yyyymmdd) {
  return `${yyyymmdd.slice(0, 4)}-${yyyymmdd.slice(4, 6)}-${yyyymmdd.slice(6, 8)}`;
}

// ---------- 아주 작은 쿠키 저장소 (세션 유지용) ----------
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }
  update(setCookieHeaders) {
    if (!setCookieHeaders) return;
    for (const raw of setCookieHeaders) {
      const pair = raw.split(";")[0];
      const idx = pair.indexOf("=");
      if (idx === -1) continue;
      this.cookies.set(pair.slice(0, idx).trim(), pair.slice(idx + 1).trim());
    }
  }
  header() {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }
}

const jar = new CookieJar();

function erpRequest(pathName, formData) {
  return new Promise((resolve, reject) => {
    const body = querystring.stringify(formData);
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
      "Content-Length": Buffer.byteLength(body),
      Cookie: jar.header(),
    };
    const req = https.request(
      { hostname: ERP_HOST, path: pathName, method: "POST", headers },
      (res) => {
        if (res.headers["set-cookie"]) jar.update(res.headers["set-cookie"]);
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch (err) {
            reject(new Error(`JSON 파싱 실패 (${pathName}): ${data.slice(0, 200)}`));
          }
        });
      }
    );
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

function httpsGetJson(hostname, pathName, headers) {
  return new Promise((resolve, reject) => {
    const req = https.request({ hostname, path: pathName, method: "GET", headers }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch (err) {
          reject(new Error(`JSON 파싱 실패 (${pathName}): ${data.slice(0, 200)}`));
        }
      });
    });
    req.on("error", reject);
    req.end();
  });
}

// ---------- 아주 작은 동시성 제한 실행기 ----------
async function runWithConcurrency(items, worker, concurrency = CONCURRENCY) {
  const results = [];
  let idx = 0;
  async function runner() {
    while (idx < items.length) {
      const cur = idx++;
      try {
        results[cur] = await worker(items[cur], cur);
      } catch (err) {
        results[cur] = { error: err.message || String(err) };
      }
      if (REQUEST_DELAY_MS) await new Promise((r) => setTimeout(r, REQUEST_DELAY_MS));
    }
  }
  await Promise.all(Array.from({ length: concurrency }, runner));
  return results;
}

// ---------- ERP 로그인 ----------
async function login() {
  log("ERP 로그인 중...");
  const res = await erpRequest("/login/loginChkGI.do", {
    COMP_ID: COMP_CD,
    EMPL_ID: ERP_USER,
    PASSWORD: ERP_PASS,
  });
  if (res.RESULT_CODE !== "SUCCESS") {
    throw new Error(`로그인 실패: ${JSON.stringify(res)}`);
  }
  log("로그인 성공.");
}

// ---------- Product360에서 활성 스타일+컬러 조합 뽑기 (3안: 재고>0 전체) ----------
async function getActiveCombos() {
  log("Product360에서 상품 목록 가져오는 중...");
  const data = await httpsGetJson("gi-board.vercel.app", "/api/archive/product360", {
    "x-archive-token": PRODUCT360_TOKEN,
  });
  if (!data.products) throw new Error(`Product360 응답 이상: ${JSON.stringify(data).slice(0, 300)}`);

  const combos = [];
  const colorNameMap = new Map(); // styCd__colCd -> 컬러명 (Product360 기준, ERP 매출 응답엔 컬러명이 없어서 여기서 채움)
  for (const p of data.products) {
    if (!p.stockQty || p.stockQty <= 0) continue;
    const colorStock = new Map();
    const colorNames = new Map();
    for (const c of p.colors || []) {
      colorStock.set(c.color, (colorStock.get(c.color) || 0) + (c.stock || 0));
      if (c.colorName) colorNames.set(c.color, c.colorName);
    }
    for (const [color, stock] of colorStock) {
      if (stock > 0) {
        combos.push({ styCd: p.code, colCd: color, styNm: p.name });
        colorNameMap.set(`${p.code}__${color}`, colorNames.get(color) || color);
      }
    }
  }
  log(`활성 스타일+컬러 조합 ${combos.length}개 (품번 ${data.products.length}개 중 재고>0 필터링 후)`);
  return { combos, colorNameMap };
}

// MARK 6.74: SHOP_GB 2~5(로드샵/백화점/아울렛/쇼핑몰)로만 걸러도, "오프라인_송도"처럼 실제
// 관리 대상이 아닌 위탁/특수 채널까지 같이 딸려옵니다. lib/dataBuilder.ts의
// isCoreOfflineSalesStore()와 완전히 같은 판별 규칙을 여기 그대로 옮겨서(주간탭/일간탭이
// 이미 "진짜 매장"으로 인정하는 기준과 동일하게), 그 기준을 통과하는 매장만 남깁니다.
function isCoreOfflineStoreName(storeName) {
  const raw = String(storeName || "").trim();
  const lower = raw.toLowerCase();
  if (!raw || raw === "합계" || raw === "채널명") return false;

  // 온라인 채널
  if (
    lower.startsWith("온라인") ||
    lower.includes("29cm") ||
    lower.includes("ssf") ||
    lower.includes("네이버") ||
    lower.includes("지그재그") ||
    lower.includes("w컨셉") ||
    lower.includes("wconcept") ||
    lower.includes("eql") ||
    lower.includes("한섬")
  ) {
    return false;
  }

  // 포시즌아울렛(프로젝트성) / 글로벌_ / 기타_ 채널
  if (
    raw.includes("포시즌") ||
    raw.startsWith("글로벌_") ||
    raw.startsWith("기타_") ||
    lower.startsWith("global_") ||
    lower.startsWith("etc_") ||
    raw === "기타" ||
    raw.startsWith("기타") ||
    raw.includes("글로벌")
  ) {
    return false;
  }

  // 위탁/면세/한컬렉션/무신사/"오프라인_" 접두사 채널 (실제 직영매장이 아님)
  if (
    raw.startsWith("오프라인_") ||
    lower.includes("위탁") ||
    lower.includes("면세") ||
    lower.includes("한컬렉션") ||
    lower.includes("han collection") ||
    lower.includes("hancollection") ||
    lower.includes("무신사")
  ) {
    return false;
  }

  return true;
}

// ---------- 오프라인 매장 목록 ----------
async function getOfflineShops() {
  log("매장 목록 가져오는 중...");
  const res = await erpRequest("/GI/SL/SL1010/getMainShopList.do", {
    comp_cd: COMP_CD,
    sale_dt: todayKST(),
    day_div: "2",
    shop_gb: "",
    shop_tp: "",
  });
  if (res.RESULT_CODE !== "SUCCESS") throw new Error(`매장 목록 조회 실패: ${JSON.stringify(res)}`);

  const byShopGb = res.RESULT_DATA.filter((s) => OFFLINE_SHOP_GB.includes(String(s.SHOP_GB)));
  const offline = byShopGb.filter((s) => isCoreOfflineStoreName(s.SHOP_NM));
  const excluded = byShopGb.length - offline.length;
  log(`오프라인 매장 ${offline.length}개 확인됨. (SHOP_GB 기준 ${byShopGb.length}개 중 위탁/특수채널 ${excluded}개 제외)`);
  return offline; // { SHOP_CD, SHOP_NM, SHOP_GB, ... }
}

// MARK 6.70: SL4010(재고) 응답의 SIZE_1~SIZE_18은 사이즈명이 아니라 "전사 사이즈코드를
// 알파벳순으로 정렬했을 때의 자리 번호"인 것으로 실측 확인됐습니다 (2026-08-04, 소천님이
// PC ERP "Style 채널별 재고현황" 화면과 대조).
//   - GF1LPT501/BK/성수·한남 플래그십: 실제 S=1,M=10,L=6,XL=3개인데 API는
//     SIZE_2=6(L), SIZE_3=10(M), SIZE_4=1(S), SIZE_5=3(XL) → L<M<S<XL 알파벳순과 일치.
//   - GF2UCP103(캡, F사이즈 전용): API가 SIZE_1에만 값이 들어있고 나머지는 전부 null
//     → 슬롯1=F 확정.
// 슬롯 1~5(F,L,M,S,XL)는 실측 확인 완료 — 대부분의 상품은 이걸로 커버됩니다.
// 슬롯 6 이후(신발 사이즈 등, 숫자라서 알파벳 정렬 규칙이 그대로 이어질지 불확실)는
// 아직 실측 데이터가 없어서 맵에 안 넣어뒀습니다. 그런 값이 나오면 추측해서 이름
// 붙이지 않고 "??"로 표시해서, 눈에 띄면 그때 실측해서 채워넣는 방식으로 갑니다.
const SIZE_SLOT_MAP = {
  1: "F", // 실측 확인 (GF2UCP103)
  2: "L", // 실측 확인 (성수/한남 플래그십)
  3: "M", // 실측 확인
  4: "S", // 실측 확인 (2개 매장)
  5: "XL", // 실측 확인
  // 6 이후는 일부러 비워둠 — unpivotSizeRow가 "??"로 표시
};

// SIZE_1~SIZE_18로 넓게 펼쳐진(pivot) 한 행을, 사이즈별 낱개 행(long format)으로 풀어줍니다.
function unpivotSizeRow(row) {
  const out = [];
  for (let i = 1; i <= 18; i++) {
    const raw = row[`SIZE_${i}`];
    if (raw === null || raw === undefined || raw === "") continue;
    const qty = Number(raw);
    if (!Number.isFinite(qty)) continue;
    out.push({ size: SIZE_SLOT_MAP[i] || "??", qty });
  }
  return out;
}

// MARK 6.69: SL1010(매출) 응답의 사이즈 필드명 후보들.
const SIZE_FIELD_CANDIDATES = ["SIZE_NM", "SIZE_CD", "SZ_NM", "SZ_CD", "SIZE", "SIZE_NO"];
function extractSizeField(row) {
  for (const key of SIZE_FIELD_CANDIDATES) {
    const v = row?.[key];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
}

// ---------- MARK 업로드 (청크 + upsert 지원) ----------
// MARK 6.71: 재고 갱신(stock-refresh)과 매출 갱신(sales-refresh)이 같은 "오늘" 날짜를
// 각자 따로 갱신하게 되면서, 예전처럼 "그날 데이터 통째로 교체"하면 서로의 값을
// 지워버립니다. onlyFields로 "이번엔 이 필드들만 갱신한다"는 걸 명시하고, 서버가
// upsert 모드로 그 필드만 부분 갱신하도록 합니다.
// mode: "replace"(그날짜 통째 교체, 기본) | "append"(이어붙이기, 중복 키는 건너뜀) |
//       "upsert"(키가 있으면 onlyFields만 갱신, 없으면 새로 만듦)
const MAX_CHUNK_BYTES = 3 * 1024 * 1024; // Vercel 4.5MB 한도에 여유를 두고 3MB로 자름

// MARK 6.72: 매장명/상품명/컬러명이 대부분 한글이라, 문자 길이(.length, UTF-16 기준)로
// 재면 실제 전송 바이트(UTF-8, 한글 1글자=3바이트)보다 훨씬 작게 잡혀서 청크가 너무
// 커지는 버그가 있었습니다. 반드시 Buffer.byteLength로 실제 바이트를 재야 합니다.
function chunkRowsByBytes(rows, maxBytes = MAX_CHUNK_BYTES) {
  const chunks = [];
  let current = [];
  let currentLen = 2; // "[]"
  for (const row of rows) {
    const rowLen = Buffer.byteLength(JSON.stringify(row), "utf8") + 1;
    if (current.length && currentLen + rowLen > maxBytes) {
      chunks.push(current);
      current = [];
      currentLen = 2;
    }
    current.push(row);
    currentLen += rowLen;
  }
  if (current.length) chunks.push(current);
  return chunks;
}

// mode: "replace"(그날짜 통째 교체, 기본) | "append"(이어붙이기, 중복 키는 건너뜀) |
//       "upsert"(키가 있으면 onlyFields만 갱신, 없으면 새로 만듦)
async function uploadRows(date, rows, { mode = "replace", onlyFields } = {}) {
  const res = await fetch(`${MARK_BASE_URL}/api/erp-daily-sales-import`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ date, rows, mode, onlyFields }),
  });
  const text = await res.text();
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`서버가 JSON이 아닌 응답을 줬습니다 (status ${res.status}): ${text.slice(0, 200)}`);
  }
  if (!data.ok) throw new Error(data.error || "업로드 실패");
  return data;
}

async function uploadRowsChunked(date, rows, options = {}) {
  const chunks = chunkRowsByBytes(rows);
  log(`${chunks.length}개 청크로 나눠서 전송합니다 (총 ${rows.length}건).`);
  let totalNew = 0;
  let totalUpdated = 0;
  for (let i = 0; i < chunks.length; i++) {
    // replace 모드일 때만 "첫 청크는 교체, 나머지는 이어붙이기"가 필요함.
    // upsert/append 모드는 애초에 기존 걸 안 지우니까 청크마다 그대로 같은 모드 유지.
    const chunkMode = options.mode === "replace" && i > 0 ? "append" : options.mode;
    log(`  청크 ${i + 1}/${chunks.length} 전송 중... (${chunks[i].length}건, mode=${chunkMode})`);
    const data = await uploadRows(date, chunks[i], { ...options, mode: chunkMode });
    totalNew += data.newRows || 0;
    totalUpdated += data.updatedRows || 0;
  }
  return { totalNew, totalUpdated };
}

module.exports = {
  ERP_USER,
  ERP_PASS,
  COMP_CD,
  PRODUCT360_TOKEN,
  MARK_BASE_URL,
  OFFLINE_SHOP_GB,
  CONCURRENCY,
  log,
  todayKST,
  toIsoDate,
  erpRequest,
  httpsGetJson,
  runWithConcurrency,
  login,
  getActiveCombos,
  getOfflineShops,
  unpivotSizeRow,
  extractSizeField,
  SIZE_SLOT_MAP,
  chunkRowsByBytes,
  uploadRows,
  uploadRowsChunked,
};
