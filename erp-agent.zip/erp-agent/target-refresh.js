// MARK ERP Agent — 매출목표 자동 갱신 (MARK 6.74)
//
// 하는 일:
//   1) 오프라인 매장 목록 조회
//   2) SL1030(목표대비실적 화면)을 "오늘 ± 범위"로 조회 — 전사(shop_cd 빈값) 1번 +
//      매장별로 각각 1번씩, 총 (매장수+1)번 호출. 응답은 하루 단위로 PLAN_AMT(목표)/
//      SALES_AMT(실적)가 이미 분해되어 나옵니다.
//   3) 하루 단위 값을 "주(월요일 기준)"와 "월(YYYY-MM)"로 묶어서 합산
//   4) /api/weekly-target-import로 업로드 (기존 "일_전일" 시트 수동 갱신을 대체)
//
// ⚠️ 확인 필요: shop_cd를 채워서 매장별로 개별 조회되는지 아직 실측 확인 전입니다.
// 처음 실행할 때 진단 로그로 회사 전체 값과 매장별 값이 서로 다르게 나오는지 꼭 확인해주세요
// (다 똑같이 나오면 shop_cd가 실제로 안 먹히고 있다는 뜻이니 코드를 다시 봐야 합니다).
//
// 실행 방법:
//   node erp-agent/target-refresh.js
//   (보통은 run-monday-schedule.js를 통해 매주 월요일 아침에만 자동 실행됩니다)

const {
  log,
  todayKST,
  login,
  getOfflineShops,
  erpRequest,
  runWithConcurrency,
  COMP_CD,
  MARK_BASE_URL,
  ERP_USER,
  ERP_PASS,
} = require("./erp-core");

// 앞뒤로 몇 주치를 갱신할지 (요청: 전전주~다음주 정도 — 우선 앞 2주 + 뒤 2주로 넉넉하게 잡음.
// 다음 세션에서 정확한 범위 확정 예정)
const WEEKS_BACK = 2;
const WEEKS_FORWARD = 2;

function ymd(d) {
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
}
function isoFromYmd(yyyymmdd) {
  return `${yyyymmdd.slice(0, 4)}-${yyyymmdd.slice(4, 6)}-${yyyymmdd.slice(6, 8)}`;
}
function mondayOf(dateIso) {
  const d = new Date(`${dateIso}T00:00:00`);
  const day = d.getDay(); // 0=일 1=월
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

// MARK 6.88: 실측해보니 SL1030이 sale_dt~sale_dt_to 범위를 그대로 안 쓰고, sale_dt가
// 속한 "그 달 전체"만 돌려주는 것으로 보입니다(예: sale_dt=7/28로 보냈는데 7월 31일치가
// 옴 — 8월분은 sale_dt_to가 8/25여도 아예 안 옴). 그래서 범위 하나로 부르는 대신,
// 필요한 각 "달"마다 sale_dt를 그 달 1일로 따로 넣어서 여러 번 부르고 합칩니다.
function monthsToQuery() {
  const now = new Date();
  const months = new Set();
  const cursor = new Date(now);
  cursor.setDate(cursor.getDate() - WEEKS_BACK * 7);
  const last = new Date(now);
  last.setDate(last.getDate() + WEEKS_FORWARD * 7);
  while (cursor <= last) {
    months.add(`${cursor.getFullYear()}${String(cursor.getMonth() + 1).padStart(2, "0")}01`);
    cursor.setMonth(cursor.getMonth() + 1);
    cursor.setDate(1);
  }
  // 혹시 몰라 마지막 달(last)도 확실히 포함
  months.add(`${last.getFullYear()}${String(last.getMonth() + 1).padStart(2, "0")}01`);
  return Array.from(months);
}

// SL1030 응답(하루 단위 배열)을 받아서 { weekMonday -> {target, actual} }, { monthKey -> target }로 묶습니다.
function bucketDailyRows(rows) {
  const byWeek = new Map(); // weekMonday -> { target, actual }
  const byMonth = new Map(); // monthKey -> target
  for (const row of rows || []) {
    // SALES_DATE는 "2026/08/03" 형식 — ISO로 변환
    const iso = String(row.SALES_DATE || "").replace(/\//g, "-");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) continue;
    const week = mondayOf(iso);
    const month = iso.slice(0, 7);
    // MARK 6.89: 실측해보니 PLAN_AMT/SALES_AMT가 "원" 단위가 아니라 "천원" 단위로 옵니다
    // (예: 성수 플래그십 주간목표가 67500으로 왔는데, 원 단위로 읽으면 6만7500원짜리
    // 매장이 되어 말이 안 됨 — 천원 단위(6,750만원)로 보면 실제 매장 규모와 맞음).
    // 그래서 여기서 ×1000 해서 진짜 "원" 단위로 저장합니다.
    const plan = Number(row.PLAN_AMT || 0) * 1000;
    const sales = Number(row.SALES_AMT || 0) * 1000;

    if (!byWeek.has(week)) byWeek.set(week, { target: 0, actual: 0 });
    const w = byWeek.get(week);
    w.target += plan;
    w.actual += sales;

    byMonth.set(month, (byMonth.get(month) || 0) + plan);
  }
  return { byWeek, byMonth };
}

let diagnosticLogged = false;

async function fetchSl1030(shopCd, saleDt, debugLabel) {
  // MARK 6.88: sale_dt_to는 실제로 안 먹히는 것 같아서(그 달 전체만 오는 것으로 보임) 뺐습니다.
  // sale_dt 하나에 그 달 아무 날짜(1일)를 넣고, 필요한 달마다 따로 호출해서 합칩니다.
  const res = await erpRequest("/GI/SL/SL1030/getMainList.do", {
    comp_cd: COMP_CD,
    sale_dt: saleDt,
    shop_cd: shopCd,
    shop_gb: "",
    shop_tp: "",
    day_div: "2",
  });
  if (debugLabel) {
    log(
      `🔍 [원본진단:${debugLabel}] sale_dt=${saleDt} shop_cd=${shopCd} RESULT_CODE=${res.RESULT_CODE} RESULT_DATA건수=${(res.RESULT_DATA || []).length}`
    );
    if ((res.RESULT_DATA || []).length) {
      log(`🔍 [원본진단:${debugLabel}] 첫/마지막 행:`, JSON.stringify(res.RESULT_DATA[0]), JSON.stringify(res.RESULT_DATA[res.RESULT_DATA.length - 1]));
    } else {
      log(`🔍 [원본진단:${debugLabel}] 전체 응답:`, JSON.stringify(res).slice(0, 500));
    }
  }
  if (res.RESULT_CODE !== "SUCCESS") return [];
  return res.RESULT_DATA || [];
}

async function main() {
  if (!ERP_USER || !ERP_PASS) {
    console.error("ERP_USER / ERP_PASS가 .env에 없습니다.");
    process.exit(1);
  }

  const overallStart = Date.now();
  try {
    await login();
    const offlineShops = await getOfflineShops();
    const months = monthsToQuery();
    log(`매출목표 조회 대상 달: ${months.map(isoFromYmd).join(", ")}`);

    // 1) 전사 합계 — MARK 6.75: ERP한테 직접 물어본 "전사 합계"(shop_cd 빈값)는 온라인/기타
    // 채널까지 포함돼 있어서, MARK가 관리하는 22개 오프라인 매장 합계(KPI 카드가 보여주는 값)
    // 랑 서로 달라 화면 안에서 두 숫자가 어긋나는 문제가 있었습니다. ERP 전사 API를 따로
    // 부르지 않고, 우리가 필터링한 매장들의 목표를 더해서 "전사 합계"로 씁니다 — 그래야
    // KPI 카드(매장 합계)와 AI브리핑(전사 합계)이 항상 같은 숫자를 보게 됩니다.

    // 2) 매장별 — MARK 6.88: 달마다 따로 불러서 합칩니다 (위 monthsToQuery 설명 참고).
    const storeResults = await runWithConcurrency(offlineShops, async (shop, idx) => {
      const isDebugTarget = idx === 0 || shop.SHOP_NM.includes("대전");
      let allRows = [];
      for (const m of months) {
        let rows = await fetchSl1030(shop.SHOP_CD, m, isDebugTarget ? `idx${idx}:${shop.SHOP_NM}:${isoFromYmd(m)}` : null);
        if (!rows.length) {
          await new Promise((r) => setTimeout(r, 300));
          rows = await fetchSl1030(shop.SHOP_CD, m, isDebugTarget ? `idx${idx}:${shop.SHOP_NM}:${isoFromYmd(m)}(재시도)` : null);
        }
        allRows = allRows.concat(rows);
      }
      return { shopNm: shop.SHOP_NM, shopCd: shop.SHOP_CD, buckets: bucketDailyRows(allRows) };
    });
    if (storeResults.length) {
      // MARK 6.87: JSON.stringify는 Map을 그냥 {}로 찍어버려서(Map은 순수 JS 객체가 아님),
      // 실제로는 데이터가 있는데 진단 로그엔 빈 것처럼 보이는 착시가 있었습니다.
      // Map을 배열로 풀어서 찍도록 고쳤습니다.
      const sample = storeResults[0];
      log("🔍 [진단] SL1030 매장별 응답 샘플:", JSON.stringify({
        shopNm: sample.shopNm,
        shopCd: sample.shopCd,
        byWeek: Array.from(sample.buckets.byWeek.entries()),
        byMonth: Array.from(sample.buckets.byMonth.entries()),
      }));
    }

    // ⚠️ 진단: 매장별 값이 서로 다 똑같이 나오면 shop_cd가 안 먹히고 있다는 뜻
    if (!diagnosticLogged && storeResults.length >= 2) {
      diagnosticLogged = true;
      const a = [...(storeResults[0]?.buckets.byWeek.values() || [])][0];
      const b = [...(storeResults[1]?.buckets.byWeek.values() || [])][0];
      if (a && b && a.target === b.target) {
        log("⚠️ [진단] 매장별 값이 서로 동일합니다 — shop_cd 파라미터가 실제로 반영 안 되고 있을 수 있어요. 결과를 그대로 믿지 말고 확인해주세요.");
      } else {
        log("✅ [진단] 매장별 값이 서로 다르게 나옵니다 — shop_cd가 정상 반영되는 것으로 보입니다.");
      }
    }

    // 3) 주차별로 묶어서 업로드 payload 만들기 (전사 합계 = 매장 목표 합)
    const allWeeks = new Set();
    for (const sr of storeResults) for (const w of sr.buckets.byWeek.keys()) allWeeks.add(w);

    const savedAtDate = isoFromYmd(todayKST());
    const weeksPayload = Array.from(allWeeks).map((weekMonday) => {
      const monthKey = weekMonday.slice(0, 7);
      const storeRows = storeResults.map((sr) => {
        const wk = sr.buckets.byWeek.get(weekMonday) || { target: 0, actual: 0 };
        const monthTarget = sr.buckets.byMonth.get(monthKey) || 0;
        return { storeName: sr.shopNm, weekTarget: wk.target, weekActual: wk.actual, monthTarget };
      });
      const companyTotal = storeRows.reduce(
        (acc, s) => ({
          weekTarget: acc.weekTarget + s.weekTarget,
          weekActual: acc.weekActual + s.weekActual,
          monthTarget: acc.monthTarget + s.monthTarget,
        }),
        { weekTarget: 0, weekActual: 0, monthTarget: 0 }
      );
      return {
        weekMonday,
        monthKey,
        refreshedDate: savedAtDate,
        baseDate: savedAtDate,
        companyTotal,
        stores: storeRows,
      };
    });

    log(`${weeksPayload.length}개 주차 업로드 중...`);
    const res = await fetch(`${MARK_BASE_URL}/api/weekly-target-import`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ weeks: weeksPayload }),
    });
    const data = await res.json();
    if (!data.ok) throw new Error(data.error || "업로드 실패");

    const totalSec = ((Date.now() - overallStart) / 1000).toFixed(1);
    log(`✅ 완료 (${totalSec}초). ${data.savedWeeks}개 주차 저장됨.`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
