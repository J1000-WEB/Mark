// 롯데면세 기간 백필 다운로드 — 로그인/화면진입은 딱 한 번만 하고, 그 뒤로는 날짜만
// 바꿔가며 조회를 반복합니다 (기존 fetchLotte는 호출할 때마다 로그인부터 새로 해서
// 느렸는데, 이 스크립트는 브라우저/로그인 세션을 계속 재사용해서 훨씬 빠릅니다).
//
// 응답에 날짜가 없어서(기간으로 조회하면 전부 시작일로 뭉뚱그려짐) 하루씩 개별 조회해야
// 하는 건 기존과 동일합니다 — 그 부분만 "매번 새로 로그인" 대신 "한 번 로그인 후 반복"으로
// 바꿨습니다.
//
// 사용법:
//   node download-lotte-range.js 20250820 20251231
//   (인자 없이 실행하면 기본값으로 이 기간을 씁니다)

const path = require("path");
const os = require("os");
const XLSX = require("xlsx");
const puppeteer = require("puppeteer");
const {
  CHANNEL_CODE,
  waitMs,
  parseSalesRows,
  clickById,
  typeIntoById,
  typeDateRobustly,
  findInputIdBySuffix,
  selectComboOption,
} = require("./build-inshop-upload.js");

function log(...args) {
  console.log(`[롯데면세-기간다운로드] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function addDays(dateStr, days) {
  const y = Number(dateStr.slice(0, 4));
  const m = Number(dateStr.slice(4, 6)) - 1;
  const d = Number(dateStr.slice(6, 8));
  const dt = new Date(Date.UTC(y, m, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  return `${dt.getUTCFullYear()}${String(dt.getUTCMonth() + 1).padStart(2, "0")}${String(dt.getUTCDate()).padStart(2, "0")}`;
}

function toDash(dateStr) {
  return `${dateStr.slice(0, 4)}-${dateStr.slice(4, 6)}-${dateStr.slice(6, 8)}`;
}

async function main() {
  const fromDate = process.argv[2] || "20250820";
  const toDate = process.argv[3] || "20251231";

  const USER_ID = process.env.LOTTE_DFS_USER_ID;
  const PASSWORD = process.env.LOTTE_DFS_PASSWORD;
  if (!USER_ID || !PASSWORD) {
    console.error("⚠ LOTTE_DFS_USER_ID/LOTTE_DFS_PASSWORD가 .env에 없어요.");
    process.exit(1);
  }

  const BASE = "https://srm.lottedfs.co.kr";
  log(`${fromDate} ~ ${toDate} 기간을 하루씩 조회합니다 (로그인은 한 번만).`);

  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  const client = await page.target().createCDPSession();
  await client.send("Network.enable");
  let capturedRows = null;
  const pending = new Map();
  client.on("Network.requestWillBeSent", (params) => {
    if (params.request.url.includes("SrmSalesStckInqryController/inqrySrmSalesStck")) {
      pending.set(params.requestId, true);
    }
  });
  client.on("Network.loadingFinished", (params) => {
    if (!pending.has(params.requestId)) return;
    pending.delete(params.requestId);
    (async () => {
      try {
        const body = await client.send("Network.getResponseBody", { requestId: params.requestId });
        const text = body.base64Encoded ? Buffer.from(body.body, "base64").toString("utf8") : body.body;
        const rows = parseSalesRows(text);
        if (rows.length) capturedRows = rows;
      } catch {
        // 무시 — 결과 대기 루프에서 타임아웃으로 처리됨
      }
    })();
  });

  const allRows = [];
  const failedDates = [];

  try {
    // ===== 로그인 + 화면진입 (한 번만) =====
    log("페이지 초기화 중...");
    await page.goto(`${BASE}/ui/ldfs_ui/index.html`, { waitUntil: "networkidle2" });
    await waitMs(2000);

    log("아이디/비밀번호 입력 중...");
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userId:input", USER_ID);
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userPwd:input", PASSWORD);
    await page.keyboard.press("Enter");
    await waitMs(4000);

    log("환영 패널 닫는 중(있으면)...");
    const closeBtnId = await page.evaluate(() => {
      const all = document.querySelectorAll("div, span");
      for (const el of all) {
        const ownText = Array.from(el.childNodes)
          .filter((n) => n.nodeType === 3)
          .map((n) => n.textContent.trim())
          .join("")
          .trim();
        const idOrClass = `${el.id || ""} ${el.className || ""}`.toLowerCase();
        if (el.offsetWidth > 0 && el.offsetHeight > 0 && (ownText === "X" || ownText === "×" || idOrClass.includes("close") || idOrClass.includes("btnclose"))) {
          return el.id || null;
        }
      }
      return null;
    });
    if (closeBtnId) {
      await clickById(page, closeBtnId);
      await waitMs(1500);
    }

    log("'매출재고조회' 화면 진입 중...");
    await typeIntoById(page, "mainFrame.vFrameSet1.frameTop.form.edt_search:input", "매출재고조회");
    await waitMs(800);
    await page.keyboard.press("Enter");
    await waitMs(1000);
    await page.keyboard.press("Enter");
    await waitMs(2500);

    const menuFound = await page.evaluate(() => document.body.innerText.includes("매출재고조회내역") || document.body.innerText.includes("Ref No"));
    if (!menuFound) throw new Error("매출재고조회 화면으로 진입 못 했어요.");
    log("화면 진입 확인됨. 이제부터 날짜만 바꿔가며 반복 조회합니다.");
    await waitMs(3000);

    const startId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_start.calendaredit:input");
    const endId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_end.calendaredit:input");
    if (!startId || !endId) throw new Error("날짜 입력칸을 못 찾았어요.");

    const agrgDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_agrgDvs.comboedit:input");
    const amtDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_amtDvs.comboedit:input");
    if (agrgDvsId) await selectComboOption(page, agrgDvsId, "SKU");
    if (amtDvsId) await selectComboOption(page, amtDvsId, "원화금액");

    // ===== 날짜만 바꿔가며 반복 조회 =====
    let cur = fromDate;
    let dayCount = 0;
    while (true) {
      dayCount++;
      log(`(${dayCount}일째) ${cur} 조회 중...`);
      try {
        capturedRows = null;
        await typeDateRobustly(page, startId, cur, toDash(cur));
        await typeDateRobustly(page, endId, cur, toDash(cur));

        const searchBtnTextId = await page.evaluate(() => {
          const all = document.querySelectorAll(".nexatextitem");
          for (const el of all) {
            const ownText = (el.textContent || "").trim();
            if (ownText === "조회" && el.parentElement?.id?.includes("btn_comSearch")) return el.parentElement.id;
          }
          return null;
        });
        if (!searchBtnTextId) throw new Error("조회 버튼을 못 찾았어요.");
        await clickById(page, searchBtnTextId);

        // MARK: 옛날 데이터는 조회에 1분20초 정도 걸리는 걸 확인해서(오늘 실측), 20초였던
        // 대기시간을 2분으로 넉넉하게 늘렸습니다. 너무 짧으면 실제로는 서버에서 아직 조회가
        // 진행 중인데 포기해버려서, 화면이 그 이전 요청 처리 중이라 막혀있는 상태로 다음
        // 날짜 입력까지 실패하는 연쇄 문제가 있었습니다.
        for (let i = 0; i < 120 && !capturedRows; i++) {
          await waitMs(1000);
          if ((i + 1) % 10 === 0) log(`  (${i + 1}초째 대기 중...)`);
        }
        if (!capturedRows) throw new Error("조회 결과를 못 받았어요(0건일 수도 있어요).");

        // MARK: salesamt는 "그 줄 전체 총액"이라서, 수량이 2 이상이면 그대로 두면
        // 나중에 수량×단가로 두 배 뻥튀기됩니다 — 총액÷수량으로 개당단가 구해서
        // 수량만큼 1개씩 낱개 행으로 쪼갭니다 (build-inshop-upload.js와 동일 로직).
        const dayRows = [];
        for (const r of capturedRows) {
          const barcode = String(r.refno || "").trim();
          const qty = Number(r.salesQty || 0);
          const totalAmt = Number(r.salesamt || 0);
          if (!barcode || qty === 0) continue;

          const unitQty = qty > 0 ? 1 : -1;
          const qtyCount = Math.abs(qty);
          const unitPrice = totalAmt !== 0 ? Math.round(totalAmt / qtyCount) : 10;

          for (let i = 0; i < qtyCount; i++) {
            dayRows.push({ date: cur, pos: "P1", channel: CHANNEL_CODE.lotte, barcode, qty: unitQty, price: unitPrice, source: "롯데면세" });
          }
        }

        log(`  ✅ ${cur}: ${dayRows.length}건`);
        allRows.push(...dayRows);
      } catch (err) {
        log(`  ⚠ ${cur} 실패: ${err.message || err}`);
        failedDates.push(cur);
      }

      if (cur === toDate) break;
      cur = addDays(cur, 1);
      await waitMs(1500);
    }
  } finally {
    await browser.close();
  }

  log(`전체 조회 완료. 총 ${allRows.length}건 (실패 ${failedDates.length}일).`);
  if (failedDates.length) {
    log(`⚠ 실패한 날짜: ${failedDates.join(", ")}`);
  }

  const mapped = allRows.map((r) => ({
    일자: r.date,
    POS: r.pos,
    채널: r.channel,
    바코드: r.barcode,
    수량: r.qty,
    단가: r.price,
    출처: r.source,
    확인필요: r.barcode.length >= 15 ? "Y (바코드 15자 이상)" : "",
  }));

  // MARK: PC에 따라 바탕화면이 OneDrive 폴더 안에 있는 경우가 있어서(예:
  // C:\Users\User\OneDrive\Desktop), 두 위치 다 확인해서 실제로 존재하는 쪽을 씁니다.
  // 둘 다 없으면(폴더 자체가 없는 특이 케이스) 만들어서라도 저장합니다.
  const fsSync = require("fs");
  const candidates = [path.join(os.homedir(), "OneDrive", "Desktop"), path.join(os.homedir(), "Desktop")];
  let desktopDir = candidates.find((p) => fsSync.existsSync(p)) || candidates[1];
  try {
    if (!fsSync.existsSync(desktopDir)) fsSync.mkdirSync(desktopDir, { recursive: true });
  } catch {
    // MARK: 안전장치 — 바탕화면 경로 자체가 이상하면(권한 문제 등), 특히 긴 작업(수십~백여 일)
    // 끝나고 나서 저장이 안 되면 너무 아까우니, 이 스크립트가 있는 폴더에라도 저장합니다.
    log("⚠ 바탕화면 폴더를 못 찾거나 못 만들어서, 이 스크립트가 있는 폴더에 대신 저장합니다.");
    desktopDir = __dirname;
  }
  const outPath = path.join(desktopDir, `롯데면세_${fromDate}_${toDate}.xlsx`);
  try {
    const ws = XLSX.utils.json_to_sheet(mapped);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "UPLOAD");
    XLSX.writeFile(wb, outPath);
    log(`✅ 저장 완료 → ${outPath}`);
  } catch (err) {
    // MARK: 마지막 저장 단계에서도 실패하면, 애써 모은 데이터를 그냥 날리지 않도록
    // JSON으로라도 스크립트 폴더에 남깁니다(나중에 이 JSON으로 엑셀 다시 만들 수 있음).
    const fallbackPath = path.join(__dirname, `롯데면세_${fromDate}_${toDate}_백업.json`);
    require("fs").writeFileSync(fallbackPath, JSON.stringify(mapped, null, 2), "utf8");
    log(`⚠ 엑셀 저장 실패(${err.message}) — 대신 JSON으로 백업했어요: ${fallbackPath}`);
  }
}

main().catch((err) => {
  console.error("⚠ 전체 실패:", err.message || err);
  process.exit(1);
});
