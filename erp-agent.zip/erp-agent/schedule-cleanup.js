// 크롬/엑셀 정리를 매일 두 번 실행하는 스케줄러:
//   3:33 — 중간 정리(cleanup-simple.au3, 파워오토메이트 2차 시도 전, 단순 강제종료만)
//   4:55 — 최종 정리(cleanup-4-30.au3, PIP업로드 끝난 뒤, PIP파일 확인 후 필요시 저장)
//
// 두 정리가 하는 일이 서로 달라서(하나는 단순 종료, 하나는 PIP 확인+저장) 스크립트 파일도
// 다르게 씁니다 — CLEANUP_JOBS 배열에서 시각별로 어떤 스크립트를 돌릴지 지정합니다.

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const iconv = require("iconv-lite");

const CLEANUP_JOBS = [
  { hour: 3, minute: 33, script: "cleanup-simple.au3", label: "중간정리" },
  { hour: 4, minute: 55, script: "cleanup-4-30.au3", label: "최종정리" },
];
const CHECK_INTERVAL_MS = 60 * 1000;

const AUTOIT_CANDIDATES = ["C:\\Program Files (x86)\\AutoIt3\\AutoIt3.exe", "C:\\Program Files\\AutoIt3\\AutoIt3.exe"];
const AUTOIT_EXE = AUTOIT_CANDIDATES.find((p) => fs.existsSync(p)) || AUTOIT_CANDIDATES[0];

function log(...args) {
  console.log(`[정리-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function runCleanup(job) {
  log(`오전 ${job.hour}시 ${job.minute}분이 되어 ${job.label}(${job.script})를 시작합니다...`);
  const scriptPath = path.join(__dirname, job.script);
  const child = spawn(AUTOIT_EXE, [scriptPath], { stdio: ["inherit", "pipe", "pipe"] });
  child.stdout.on("data", (buf) => process.stdout.write(iconv.decode(buf, "cp949")));
  child.stderr.on("data", (buf) => process.stderr.write(iconv.decode(buf, "cp949")));
  child.on("error", (err) => {
    log(`⚠ ${job.label} 실행 실패: ${err.message}`);
  });
  child.on("exit", (code) => {
    log(`${job.label} 스크립트 종료 (코드 ${code}).`);
  });
}

let lastRunSlot = null;
function tick() {
  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();
  const job = CLEANUP_JOBS.find((j) => j.hour === hour && j.minute === minute);
  if (!job) return;
  const slotKey = `${todayString()}-${hour}-${minute}`;
  if (lastRunSlot === slotKey) return;
  lastRunSlot = slotKey;
  runCleanup(job);
}

log(`시작합니다. 매일 [${CLEANUP_JOBS.map((j) => `${j.hour}시${j.minute}분(${j.label})`).join(", ")}]에 정리를 자동 실행합니다.`);
setInterval(tick, CHECK_INTERVAL_MS);
tick();
