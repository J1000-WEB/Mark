// MARK ERP Agent — 통합 실행기 (MARK 6.100)
//
// 예전엔 창을 3개(재고/매출/매출목표) 따로 켜두셔야 했는데, 창 하나가 닫히거나 놓치면
// 그 부분만 조용히 멈춰서 데이터에 구멍이 생기는 문제가 있었습니다(2026-08-16~18 매출
// 누락 사례). 이 스크립트 하나만 켜두면 세 가지가 전부 한 창 안에서 동시에 돌아갑니다.
//
// 실행: node erp-agent/run-all.js
// (또는 run-all.bat 더블클릭)
//
// 각 줄 앞에 [재고]/[매출]/[목표] 라벨이 붙어서 어디서 나온 로그인지 구분됩니다.
// 하나가 죽어도(에러로 프로세스가 꺼져도) 다른 두 개는 계속 돌고, 죽은 건 10초 뒤 자동
// 재시작됩니다 — "언제부터 멈춰있었는지 모르는" 상황 자체를 없애는 게 목적입니다.
//
// 2026-09-18 추가 — 코드 수정 자동 반영(파일 감시 → 자동 재시작):
// schedule-lotte.js/schedule-hankollection.js(channel-scheduler.js 기반)나 merge-inshop.js는
// setInterval로 계속 떠있기만 하고 절대 안 죽는 구조라, build-inshop-upload.js 같은 걸 고쳐도
// 이미 떠있는 프로세스는 require() 시점(=이 창을 켰을 때)의 옛날 함수를 계속 메모리에 들고
// 돕니다. 실제로 면세(롯데) 수량 1개씩 분할 로직을 고쳤는데, run-all 창을 재시작 안 해서
// 다음날 새벽 자동 실행이 옛날 버전(분할 안 되는 버전)으로 돈 사례가 있었습니다(2026-09-17
// 수정 → 09-18 새벽 실행에 미반영). 이제 이 폴더 안의 .js 파일이 바뀌면 자동으로 감지해서
// 모든 작업을 재시작합니다 — 재시작을 깜빡할 걱정 자체를 없애는 게 목적입니다.

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");

function ts() {
  return new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" });
}

const TASKS = [
  // MARK: 재고/매출은 매장이 운영 안 하는 00:30~09:30에는 갱신할 필요가 없어서, 그 시간대를
  // 건너뛰는 버전(run-loop-interval-quiet.js)으로 교체했습니다.
  { label: "재고", color: "\x1b[36m", args: ["run-loop-interval-quiet.js", "stock-refresh.js", "15"] },
  { label: "매출", color: "\x1b[33m", args: ["run-loop-interval-quiet.js", "sales-refresh.js", "10"] },
  { label: "목표", color: "\x1b[35m", args: ["run-monday-schedule.js"] },
  // MARK: 인샵매출업로드 — 채널마다 정기점검 시간대가 달라서(면세는 00~02시 확정, 한컬렉션은
  // 불명확) 하나로 묶어서 재시도하면 서로 발목을 잡길래, 채널별로 완전히 독립된 스케줄러로
  // 나눴습니다. 각자 성공하면 캐시 파일을 남기고, "병합" 작업이 주기적으로 그때까지 모인
  // 채널들로 최종 파일을 다시 만듭니다.
  { label: "한컬", color: "\x1b[32m", args: ["schedule-hankollection.js"] },
  { label: "면세", color: "\x1b[34m", args: ["schedule-lotte.js"] },
  // MARK: 무신사는 자동화 접근을 "비정상적인 접근"으로 감지해서 능동적으로 비밀번호/OTP를
  // 초기화시키는 게 확인돼서(2026-08-30), 계정 보안 문제로 번질 수 있어 완전자동화를
  // 중단했습니다. schedule-musinsa.js 파일 자체는 남겨뒀지만 여기서 빼서 안 돌게 했어요.
  // { label: "무신사", color: "\x1b[91m", args: ["schedule-musinsa.js"] },
  { label: "병합", color: "\x1b[92m", args: ["merge-inshop.js"] },
  // MARK: 인샵매출업로드(한컬=1시, 면세=2시)가 끝난 뒤 여유를 두고 2시 20분에
  // ERP 업로드(sgerp-login.exe) 자동 실행.
  { label: "ERP", color: "\x1b[96m", args: ["schedule-sgerp-upload.js"] },
  // MARK: 파워오토메이트 1차 시도(2시25분) 전, 2시 22분에 ERP를 무조건 강제종료하는
  // 이중 안전장치 — sgerp-login.exe 자체가 도중에 죽어서 ERP를 못 닫았을 경우를 대비.
  { label: "ERP끄기", color: "\x1b[31m", args: ["schedule-erp-force-close.js"] },
  // MARK: 파워오토메이트(erp_daily) — 2시25분에 1차 시도, 그 시간대에 유독 잘 안 되는
  // 경우가 있어서 3시35분에 2차 시도까지 하도록 스케줄러 자체가 하루 두 번 돕니다.
  { label: "PA", color: "\x1b[95m", args: ["schedule-power-automate.js"] },
  // MARK: 파워오토메이트가 받아둔 "스타일별채널별 입고/판매/재고현황" 파일을 대시보드에
  // 자동 업로드 — 2차 파워오토메이트(3시35분) 끝난 뒤 여유를 두고 4시50분으로 잡음.
  { label: "PIP", color: "\x1b[93m", args: ["schedule-style-channel-upload.js"] },
  // MARK: 정리도 하루 두 번 — 3시33분(파워오토메이트 2차 시도 전 중간정리, 단순종료만)과
  // 4시55분(PIP업로드 끝난 뒤 최종정리, PIP파일 확인 후 필요시 엑셀 저장) — 두 정리는
  // 하는 일이 달라서 스크립트도 다릅니다(cleanup-simple.au3 / cleanup-4-30.au3).
  { label: "정리", color: "\x1b[90m", args: ["schedule-cleanup.js"] },
];
const RESET = "\x1b[0m";

function prefixLines(buf, label, color) {
  const text = buf.toString("utf8");
  return text
    .split(/\r?\n/)
    .filter((line) => line.length > 0)
    .map((line) => `${color}[${label}]${RESET} ${line}`)
    .join("\n");
}

function startTask(task) {
  // MARK 2026-09-18: 파일 변경 감지 시 "지금 바로" 재시작시키기 위한 훅. 평소 크래시 복구
  // (10초 대기)와 구분해서, 코드 변경으로 인한 재시작은 거의 즉시(0.5초) 다시 뜨게 합니다.
  let codeChangeRestart = false;
  task.requestRestart = () => {
    codeChangeRestart = true;
    if (task.child) task.child.kill();
  };

  function spawnChild() {
    console.log(`${task.color}[${task.label}]${RESET} [${ts()}] 시작합니다...`);
    // MARK 6.113: 버그 수정 — task.args 전체를 path.join에 다 넣어서
    // "run-loop-interval.js\stock-refresh.js\15" 같은 하나의(존재하지 않는) 파일 경로로
    // 합쳐버리는 실수가 있었습니다. 첫 번째 인자(스크립트 파일명)만 경로로 만들고,
    // 나머지(예: "stock-refresh.js", "15")는 그 스크립트에 넘길 커맨드라인 인자로 분리합니다.
    const [scriptFile, ...scriptArgs] = task.args;
    const child = spawn("node", [path.join(__dirname, scriptFile), ...scriptArgs], {
      cwd: __dirname,
      env: process.env,
    });
    task.child = child;

    child.stdout.on("data", (d) => {
      const out = prefixLines(d, task.label, task.color);
      if (out) console.log(out);
    });
    child.stderr.on("data", (d) => {
      const out = prefixLines(d, task.label, task.color);
      if (out) console.error(out);
    });

    child.on("exit", (code) => {
      const wasCodeChange = codeChangeRestart;
      codeChangeRestart = false;
      task.child = null;
      if (wasCodeChange) {
        console.log(`${task.color}[${task.label}]${RESET} [${ts()}] 코드 변경 감지로 재시작합니다...`);
        setTimeout(spawnChild, 500);
      } else {
        console.error(
          `${task.color}[${task.label}]${RESET} [${ts()}] ⚠ 종료됨(코드 ${code}) — 10초 뒤 자동으로 다시 시작합니다.`
        );
        setTimeout(spawnChild, 10000);
      }
    });
  }
  spawnChild();
}

console.log("============================================");
console.log(" MARK 로컬 자동화 통합 실행 중 (재고+매출+매출목표+인샵매출업로드)");
console.log(" 이 창 하나만 켜두시면 됩니다 — 이 창을 닫으면 전부 멈춥니다.");
console.log("============================================\n");

for (const task of TASKS) startTask(task);

// ============================================================
// 자동 재시작 — 이 폴더의 .js 파일이 바뀌면 모든 작업을 자동으로 재시작합니다.
// MARK 2026-09-18: channel-scheduler.js 기반 스케줄러(한컬/면세)나 merge-inshop.js는
// setInterval로 계속 떠있는 채 안 죽어서, require()로 가져온 함수(build-inshop-upload.js
// 등)를 고쳐도 재시작 전까진 옛날 버전이 그대로 도는 문제가 있었습니다(면세 수량분할 로직
// 고쳤는데 재시작을 깜빡해서 다음날 새벽에 옛날 버전으로 돈 실제 사례). 이제 저장하는 순간
// 알아서 재시작되니 이 문제 자체가 없어집니다. cache/debug 폴더나 .js가 아닌 파일(로그,
// 캐시 json, xlsx 등) 변경은 무시합니다.
// ============================================================
const IGNORE_DIRS = new Set(["cache", "debug", "node_modules", ".git"]);
let restartTimer = null;

function scheduleRestartAll(reason) {
  if (restartTimer) clearTimeout(restartTimer);
  // MARK: 저장 한 번에 파일시스템 이벤트가 여러 번(임시파일 생성+rename 등) 뜰 수 있어서,
  // 2초 안에 연달아 들어오는 변경은 하나로 묶어서 재시작 한 번만 합니다.
  restartTimer = setTimeout(() => {
    restartTimer = null;
    console.log(`\n${RESET}[감시] [${ts()}] ${reason} — 모든 작업을 재시작합니다...\n`);
    for (const task of TASKS) task.requestRestart();
  }, 2000);
}

try {
  fs.watch(__dirname, { recursive: true }, (eventType, filename) => {
    if (!filename) return;
    const normalized = filename.split(path.sep).join("/");
    const parts = normalized.split("/");
    if (parts.some((p) => IGNORE_DIRS.has(p))) return;
    if (!normalized.endsWith(".js")) return;
    scheduleRestartAll(`${normalized} 변경 감지`);
  });
  console.log("[감시] 이 폴더의 .js 파일 변경을 감시 중입니다 — 저장하면 자동으로 재시작됩니다.\n");
} catch (err) {
  console.error(`⚠ 파일 변경 감시를 시작하지 못했습니다(자동 재시작 비활성 — 수동 재시작 필요): ${err.message || err}`);
}
