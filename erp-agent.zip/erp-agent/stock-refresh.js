// MARK ERP Agent — 재고 실시간 갱신 (MARK 6.71)
//
// 하는 일:
//   1) Product360에서 재고>0인 스타일+컬러 조합 뽑기
//   2) ERP 재고(SL4010)를 오프라인 채널(로드샵/백화점/아울렛/쇼핑몰) 기준으로 전부 조회
//   3) "오늘" 날짜로, stock 필드만 upsert(부분 갱신)해서 업로드 — 매출(qty/amount)은
//      건드리지 않습니다 (그건 sales-refresh.js가 따로 담당).
//
// ERP한테 매번 진짜 재고를 다시 물어보는 방식이라, 입고/반품/조정 등 뭐가 됐든
// ERP 안에서 반영된 변화가 그대로 자동으로 따라옵니다 — 따로 계산할 필요 없음.
//
// 실행 방법:
//   node erp-agent/stock-refresh.js
//   (반복 실행은 run-loop-interval.js를 통해서 — 아래 run-stock-refresh.bat 참고)

const path = require("path");
const {
  log,
  todayKST,
  login,
  getActiveCombos,
  getOfflineShops,
  erpRequest,
  runWithConcurrency,
  unpivotSizeRow,
  uploadRowsChunked,
  COMP_CD,
  OFFLINE_SHOP_GB,
  ERP_USER,
  ERP_PASS,
  PRODUCT360_TOKEN,
} = require("./erp-core");

let stockDiagnosticLogged = false;

async function fetchStockSnapshot(combos) {
  log(`재고 조회 시작: 조합 ${combos.length}개 x 채널 ${OFFLINE_SHOP_GB.length}개 = 총 ${combos.length * OFFLINE_SHOP_GB.length}회 호출`);
  const jobs = [];
  for (const combo of combos) {
    for (const shopGb of OFFLINE_SHOP_GB) {
      jobs.push({ ...combo, shopGb });
    }
  }

  let done = 0;
  const startedAt = Date.now();
  const results = await runWithConcurrency(jobs, async (job) => {
    const res = await erpRequest("/GI/SL/SL4010/getMainList2.do", {
      comp_cd: COMP_CD,
      sty_cd: job.styCd,
      col_cd: job.colCd,
      shop_gb: job.shopGb,
    });
    done++;
    if (done % 1000 === 0) log(`  ...진행 ${done}/${jobs.length}`);
    if (res.RESULT_CODE !== "SUCCESS") return [];
    if (!stockDiagnosticLogged && (res.RESULT_DATA || []).length) {
      stockDiagnosticLogged = true;
      log("🔍 [진단] SL4010 재고 응답 원본 필드:", JSON.stringify(res.RESULT_DATA[0]));
    }
    return (res.RESULT_DATA || []).flatMap((row) => {
      const sizes = unpivotSizeRow(row);
      const base = { styCd: job.styCd, styNm: job.styNm, colCd: job.colCd, shopCd: row.SHOP_CD, shopNm: row.SHOP_NM };
      if (!sizes.length) return [{ ...base, size: "", totQty: Number(row.TOT_QTY || 0) }];
      return sizes.map((s) => ({ ...base, size: s.size, totQty: s.qty }));
    });
  });

  const flat = results.flat().filter((r) => r && !r.error);
  const durationSec = ((Date.now() - startedAt) / 1000).toFixed(1);
  log(`재고 조회 완료. ${flat.length}건 수집, ${durationSec}초 소요.`);
  return flat;
}

function toRows(stockSnapshot, colorNameMap, isoDate) {
  // 매장+품번+컬러+사이즈 키로 합산 (같은 조합이 여러 job으로 안 나뉘지만 안전하게 합산)
  const rows = new Map();
  const updatedAt = new Date().toISOString();
  for (const s of stockSnapshot) {
    const key = `${s.shopCd}__${s.styCd}__${s.colCd}__${s.size || ""}`;
    if (!rows.has(key)) {
      rows.set(key, {
        date: isoDate,
        storeName: s.shopNm,
        styleCode: s.styCd,
        productName: s.styNm || "",
        colorCode: s.colCd,
        colorName: colorNameMap.get(`${s.styCd}__${s.colCd}`) || s.colCd,
        size: s.size || "",
        stock: 0,
        stockUpdatedAt: updatedAt,
      });
    }
    rows.get(key).stock += s.totQty;
  }
  return Array.from(rows.values());
}

async function main() {
  if (!ERP_USER || !ERP_PASS) {
    console.error("ERP_USER / ERP_PASS가 .env에 없습니다.");
    process.exit(1);
  }
  if (!PRODUCT360_TOKEN) {
    console.error("PRODUCT360_TOKEN_OBT가 .env에 없습니다.");
    process.exit(1);
  }

  const overallStart = Date.now();
  try {
    await login();
    const { combos, colorNameMap } = await getActiveCombos();
    const stockSnapshot = await fetchStockSnapshot(combos);

    const isoDate = todayKST().replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
    const rows = toRows(stockSnapshot, colorNameMap, isoDate);

    log(`${isoDate} — ${rows.length}건 upsert(재고만 갱신) 업로드 중...`);
    const { totalNew, totalUpdated } = await uploadRowsChunked(isoDate, rows, {
      mode: "upsert",
      onlyFields: ["stock", "stockUpdatedAt"],
    });

    const totalSec = ((Date.now() - overallStart) / 1000).toFixed(1);
    log(`✅ 완료 (${totalSec}초). 신규 ${totalNew}건, 갱신 ${totalUpdated}건`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
