@echo off
REM MARK ERP Agent - 매출목표 매주 월요일 자동 갱신
cd /d "%~dp0"

echo ============================================
echo  MARK 매출목표 자동 갱신 (매주 월요일) - 실행중
echo  (이 창을 닫으면 멈춥니다)
echo ============================================
echo.

node run-monday-schedule.js

echo.
echo (멈췄습니다. 아무 키나 누르면 창이 닫힙니다)
pause >nul
