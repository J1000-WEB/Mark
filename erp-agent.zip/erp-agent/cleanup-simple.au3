; 중간 정리 스크립트(3:33용) — 파워오토메이트 1차 시도(2:25) 후, 2차 시도(3:35) 전에
; 켜져있는 크롬/엑셀/ERP를 정리해서 다음 시도가 깨끗한 상태에서 시작하게 합니다.
;
; MARK: 최종 정리(cleanup-4-30.au3, 4:55용)와 다르게, 이건 PIP 업로드(4:50)가 아직
; 시작도 안 한 시점에 도는 거라서, "오늘자 PIP 파일 있는지 확인해서 없으면 엑셀 저장"
; 로직을 그대로 쓰면 안 됩니다(아직 다 안 받은 엑셀을 섣불리 저장해버릴 수 있어서).
; 그래서 이건 그냥 단순하게 크롬/엑셀/ERP만 강제 종료합니다(저장 로직 없음).
;
; MARK: ERP도 여기서 같이 꺼줍니다 — 2:25 1차 시도(login-then-pa.au3)가 로그인해둔 ERP가
; 계속 켜진 채로 남아있으면, 3:35 2차 시도가 다시 로그인하려 할 때 꼬일 수 있어서,
; 재시도 전에 깨끗하게 닫아둡니다.

#include <MsgBoxConstants.au3>

; 새벽에 모니터가 절전으로 꺼져있으면 자동화 입력이 잘 안 먹힐 수 있어서, 화면을 깨웁니다.
MouseMove(100, 100, 0)
Sleep(200)
MouseMove(300, 300, 0)
Sleep(200)
Send("{SHIFT}")
Sleep(2000)

ConsoleWrite("중간 정리: 크롬/엑셀/ERP 강제 종료 중..." & @CRLF)
ProcessClose("chrome.exe")
ProcessClose("EXCEL.EXE")
ProcessClose("MiPlatform320U.exe")
Sleep(500)
ConsoleWrite("✅ 중간 정리 완료." & @CRLF)
