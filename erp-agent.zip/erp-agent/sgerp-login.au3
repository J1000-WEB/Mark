; SG ERP (MiPlatform320U.exe) 자동화 스크립트 - 1단계: 로그인 + 화면 진입까지
;
; 웹사이트가 아니라 설치된 윈도우 프로그램이라서, 브라우저 자동화 대신 AutoIt으로
; 진짜 윈도우 컨트롤(입력칸/버튼)을 직접 찾아서 값 넣고 클릭합니다.
;
; 사용법:
;   1. 이 파일을 sgerp-login.au3로 저장
;   2. 안에 있는 ID/비밀번호를 실제 값으로 바꾸기 (또는 커맨드라인 인자로 전달)
;   3. AutoIt 설치 후, 이 파일 더블클릭하면 실행됩니다
;      (또는 CMD에서: "C:\Program Files (x86)\AutoIt3\AutoIt3.exe" sgerp-login.au3)

#include <MsgBoxConstants.au3>

; MARK: 성공하든 실패하든(중간에 어디서 멈추든) 스크립트가 끝날 때 무조건 ERP를 꺼줘야
; 파워오토메이트가 다음에 깨끗한 상태에서 ERP를 새로 켤 수 있습니다. AutoIt의
; "스크립트 종료 시 항상 실행되는 함수 등록" 기능으로, 성공 경로든 Exit()로 중간에
; 빠져나가는 실패 경로든 전부 이 함수가 무조건 실행되도록 만듭니다.
OnAutoItExitRegister("_CloseErpOnExit")
Func _CloseErpOnExit()
    ConsoleWrite("ERP 프로그램 종료 중(성공/실패 무관하게 항상 실행)..." & @CRLF)
    ProcessClose("MiPlatform320U.exe")
EndFunc

; MARK: 새벽에 모니터가 절전으로 꺼져있으면, 진짜 키/마우스 입력이 있어야 화면이 다시
; 켜지고 Windows가 입력을 정상적으로 처리합니다. 아무것도 안 하고 있다가 갑자기 자동화가
; 시작되면 화면이 꺼진 채로 진행돼서 입력이 다 씹혔을 가능성이 높아서, 맨 처음에 마우스를
; 살짝 움직이고 무해한 키를 하나 눌러서 화면을 "깨웁니다".
MouseMove(100, 100, 0)
Sleep(200)
MouseMove(300, 300, 0)
Sleep(200)
Send("{SHIFT}")
Sleep(2000) ; 화면이 완전히 켜지고 안정화될 시간을 넉넉히 줍니다

; MARK: 사무실 PC에서 아이디/비밀번호가 같은 칸에 섞여 들어가는 문제가 있었는데, 화면
; 배율(DPI 확대) 때문에 저희가 계산한 좌표가 실제 화면 좌표랑 어긋난 것으로 추정됩니다.
; 스크립트를 "DPI 인식"으로 만들어서 좌표가 실제 화면과 정확히 일치하게 만듭니다.
DllCall("user32.dll", "bool", "SetProcessDPIAware")

; MARK: AutoIt Send()에서 !(Alt), +(Shift), ^(Ctrl), #(Win), {}(특수키 표시)는 글자가 아니라
; 특수 명령으로 해석됩니다 — 비밀번호에 !가 있으면 엉뚱하게 동작해서(Alt 키 취급) 안 들어갔던
; 거예요. 이 문자들을 {문자} 형태로 감싸서 "이건 진짜 글자"라고 표시해주는 함수입니다.
Func _EscapeForSend($sText)
    $sText = StringReplace($sText, "{", "{{}")
    $sText = StringReplace($sText, "}", "{}}")
    $sText = StringReplace($sText, "!", "{!}")
    $sText = StringReplace($sText, "+", "{+}")
    $sText = StringReplace($sText, "^", "{^}")
    $sText = StringReplace($sText, "#", "{#}")
    Return $sText
EndFunc

; MARK: 이 PC에서는 ControlClick(창에 메시지를 직접 꽂아넣는 방식)이 막혀있는 것 같아서,
; 컨트롤의 실제 화면 좌표를 계산해서 진짜 마우스로 클릭하는 함수입니다.
Func _RealClick($hWin, $sControl)
    Local $aPos = ControlGetPos($hWin, "", $sControl)
    Local $aWinPos = WinGetPos($hWin)
    If Not IsArray($aPos) Or Not IsArray($aWinPos) Then
        ConsoleWrite("⚠ _RealClick 실패 — " & $sControl & "의 위치를 못 가져왔어요." & @CRLF)
        Return False
    EndIf
    Local $iX = $aWinPos[0] + $aPos[0] + Int($aPos[2] / 2)
    Local $iY = $aWinPos[1] + $aPos[1] + Int($aPos[3] / 2)
    ConsoleWrite("🔍 [진단] " & $sControl & " 클릭 좌표: (" & $iX & ", " & $iY & ")  [창위치=" & $aWinPos[0] & "," & $aWinPos[1] & " / 컨트롤 내부위치=" & $aPos[0] & "," & $aPos[1] & " 크기=" & $aPos[2] & "x" & $aPos[3] & "]" & @CRLF)
    MouseClick("left", $iX, $iY, 1)
    Return True
EndFunc

; ===== 설정 =====
Local $sExePath = 'C:\Windows\SysWOW64\MiUpdater321.exe -L TRUE -R FALSE -D WIN32U -V 3.2 -K GENERAL_ERP -X http://general.sgerp.com/mi/erp_general.xml -Wd 1024 -Ht 768'
Local $sLoginId = "sjc"
Local $sLoginPw = "1031thwocjs!"
Local $sSearchMenu = "엑셀판매관리"  ; 찾아 들어갈 메뉴 이름

; ===== 1단계: 프로그램 실행 (이미 켜져 있으면 이 줄은 건너뛰어도 됩니다) =====
ConsoleWrite("프로그램 실행 중..." & @CRLF)
If Not ProcessExists("MiPlatform320U.exe") Then
    Run($sExePath)
    Sleep(5000) ; MARK: 새벽엔 화면을 막 깨운 직후라 평소보다 느릴 수 있어서 여유를 더 둠(3초→5초)
EndIf

; MARK: "#32770"은 윈도우 표준 대화상자 클래스라서 이 조건 하나만으로는 다른 창(심지어
; 저희 스크립트 자신의 진단 팝업!)이 잘못 걸릴 수 있습니다. 화면엔 분명히 로그인창이
; 보이는데 저희가 잡은 창에서 "sjc"를 못 읽는 문제가 있어서, #32770 클래스를 가진 창을
; 전부 찾아서 그중에 "진짜로 크기가 578x312 근처이고 안에 EditTobe 입력칸이 있는" 창을
; 정확히 골라내는 함수로 바꿨습니다.
Func _FindRealLoginWindow($iTimeoutSec)
    Local $iElapsed = 0
    While $iElapsed < $iTimeoutSec
        Local $aWinList = WinList("[CLASS:#32770]")
        For $i = 1 To $aWinList[0][0]
            Local $hCandidate = $aWinList[$i][1]
            If Not IsHWnd($hCandidate) And $hCandidate = 0 Then ContinueLoop
            Local $aPos = ControlGetPos($hCandidate, "", "EditTobe3")
            If IsArray($aPos) Then
                Local $aWinSize = WinGetPos($hCandidate)
                If IsArray($aWinSize) And $aWinSize[2] > 400 And $aWinSize[2] < 800 Then
                    ConsoleWrite("🔍 [진단] 진짜 로그인창 찾음! 핸들=" & $hCandidate & ", 크기=" & $aWinSize[2] & "x" & $aWinSize[3] & @CRLF)
                    Return $hCandidate
                EndIf
            EndIf
        Next
        Sleep(1000)
        $iElapsed += 1
    WEnd
    Return 0
EndFunc

; ===== 2단계: 로그인 창 찾기 (실패하면 프로그램 재시작해서 한 번 더 시도) =====
ConsoleWrite("로그인 창 기다리는 중 (여러 후보 중 진짜를 찾습니다)..." & @CRLF)
; MARK: 새벽엔 화면을 막 깨운 직후라 프로그램이 뜨는 데 평소보다 오래 걸릴 수 있어서,
; 시간제한을 20초 → 45초로 늘렸었는데, 그래도 간헐적으로(매일은 아니고 가끔) 45초
; 안에 못 뜨는 날이 있는 걸 확인했습니다(2026-09-15). 그래서 45초 기다려도 못 찾으면
; 프로그램을 완전히 강제종료하고 새로 켜서 한 번 더 시도하도록 재시도 로직을 추가했습니다.
Local $hLoginWin = 0
For $iLaunchAttempt = 1 To 2
    $hLoginWin = _FindRealLoginWindow(45)
    If $hLoginWin <> 0 Then ExitLoop
    ConsoleWrite("⚠ " & $iLaunchAttempt & "번째 시도에서 45초 안에 로그인 창을 못 찾았어요." & @CRLF)
    If $iLaunchAttempt < 2 Then
        ConsoleWrite("프로그램을 완전히 껐다가 다시 켜서 재시도합니다..." & @CRLF)
        ProcessClose("MiPlatform320U.exe")
        Sleep(2000)
        Run($sExePath)
        Sleep(5000)
    EndIf
Next
If $hLoginWin = 0 Then
    MsgBox($MB_OK, "실패", "2번 시도했는데도 로그인 창을 못 찾았어요. 프로그램이 실제로 켜졌는지 확인해주세요.", 10)
    Exit
EndIf

; MARK: 소천님이 실제로 하시는 걸 보니, 앱이 켜지고 업데이트까지 끝나면 자동으로
; 비밀번호 칸에 커서가 가있고, 아이디 칸엔 "sjc"가 자동으로 채워진다고 하셨어요.
; 그래서 클릭/활성화를 억지로 시도할 필요가 전혀 없었던 거예요 — 오히려 그게 방해가
; 됐을 수도 있어요. "sjc"가 나타나는 걸 "준비 완료" 신호로 보고 그냥 기다렸다가,
; 클릭 없이 바로 비밀번호 타이핑 + 엔터만 하면 됩니다(포커스가 이미 가있으니까요).
ConsoleWrite("앱 준비되는 중(업데이트 등) — 아이디 칸에 '" & $sLoginId & "'가 나타날 때까지 최대 60초 기다립니다..." & @CRLF)
Local $bReady = False
For $i = 1 To 60
    Local $sIdCheck = ControlGetText($hLoginWin, "", "EditTobe3")
    If $sIdCheck = $sLoginId Then
        $bReady = True
        ExitLoop
    EndIf
    Sleep(1000)
Next
If Not $bReady Then
    MsgBox($MB_OK, "실패", "60초를 기다렸는데도 아이디 칸에 '" & $sLoginId & "'가 안 나타났어요. 화면을 직접 확인해주세요.", 10)
    Exit
EndIf
ConsoleWrite("✅ 준비 완료 확인됨! (아이디 칸에 " & $sLoginId & " 나타남)" & @CRLF)
Sleep(500)

; ===== 3단계: 비밀번호 입력 (클릭 없이 — 이미 포커스가 가있는 상태) =====
; MARK: 사람이 직접 실행했을 땐 됐는데, 새벽에 스케줄러가 자동으로 돌릴 때는 그 사이에
; 뭔가(알림, 다른 창 등)가 포커스를 가져가서 비밀번호가 안 들어가는 문제가 있었습니다.
; 타이핑 직전에 창을 강제로 다시 활성화하고, 실패하면 최대 3번까지 재시도합니다.
ConsoleWrite("비밀번호 입력 중..." & @CRLF)
Local $sCheckPw = ""
For $iAttempt = 1 To 3
    ; 창을 강제로 다시 활성화 (그 사이 다른 창이 포커스를 가져갔을 수 있어서)
    WinActivate($hLoginWin)
    Sleep(200)
    If Not WinActive($hLoginWin) Then
        WinSetOnTop($hLoginWin, "", 1)
        Sleep(200)
        WinSetOnTop($hLoginWin, "", 0)
        WinActivate($hLoginWin)
        Sleep(300)
    EndIf

    Send(_EscapeForSend($sLoginPw))
    Sleep(500)
    $sCheckPw = ControlGetText($hLoginWin, "", "EditTobe2")
    ConsoleWrite("🔍 [진단] 비밀번호 입력 시도 " & $iAttempt & "번째 — 칸 길이: " & StringLen($sCheckPw) & "자" & @CRLF)
    If $sCheckPw <> "" Then ExitLoop
    Sleep(500)
Next
If $sCheckPw = "" Then
    MsgBox($MB_OK, "진단", "비밀번호 칸이 3번 시도해도 계속 비어있어요!", 10)
EndIf

; ===== 4단계: 엔터로 로그인 =====
ConsoleWrite("엔터로 로그인 시도..." & @CRLF)
Send("{ENTER}")
Sleep(1500)

; MARK: 로그인 창이 실제로 닫혔는지 확인 — 안 닫혔으면 로그인 자체가 실패한 거라 여기서 멈춥니다.
If WinExists($hLoginWin) Then
    ConsoleWrite("⚠ 로그인 창이 아직 안 닫혔어요 — 로그인이 실패했을 수 있어요." & @CRLF)
    MsgBox($MB_OK, "진단", "엔터를 눌렀는데 로그인 창이 아직 열려있어요. 비밀번호가 제대로 안 들어갔을 수 있어요.", 10)
    Exit
EndIf
ConsoleWrite("로그인 창 닫힘 확인 — 로그인 진행된 것 같아요." & @CRLF)

; ===== 5단계: 메인 화면 뜰 때까지 대기 =====
ConsoleWrite("메인 화면 기다리는 중..." & @CRLF)
Sleep(2000) ; MARK: 로그인 처리+메인화면 로딩 시간을 넉넉히 기다립니다
Local $hMainWin = WinWait("GENERAL ERP", "", 20)
If $hMainWin = 0 Then
    MsgBox($MB_OK, "실패", "로그인 후 메인 화면을 20초 안에 못 찾았어요. 아이디/비밀번호가 맞는지, 화면이 실제로 어떻게 됐는지 확인해주세요.", 10)
    Exit
EndIf
WinActivate($hMainWin)
Sleep(1000)
ConsoleWrite("로그인 성공! 메인 화면 진입 확인됨." & @CRLF)

; ===== 6단계: 검색창에 메뉴 이름 입력해서 화면 이동 =====
; AutoIt Window Info로 확인: 메인 화면 안의 검색창 = EditTobe 1번째
; MARK: 로그인 때와 같은 이유로 ControlSend가 이 PC에서 안 먹혀서, ControlFocus(포커스만
; 주는 가벼운 방식)로 포커스를 준 다음, 진짜 키보드 입력을 흉내내는(Send) 방식으로
; 통일합니다 — 로그인 단계에서 성공했던 것과 같은 방식이에요.
ConsoleWrite("메뉴 검색 중 (" & $sSearchMenu & ")..." & @CRLF)
ControlFocus($hMainWin, "", "EditTobe1")
Sleep(300)
Send("^a")
Send("{DEL}")
Sleep(200)
Send(_EscapeForSend($sSearchMenu))
Sleep(800)
Send("{ENTER}")
Sleep(1500)

; 검색 결과 드롭다운(트리 팝업)이 뜨면, 화살표 아래로 3번 눌러서 "엑셀판매관리"까지
; 내려간 다음 Enter로 확정합니다 (Fashion > 영업관리 > 판매관리 > 엑셀판매관리, 3단계 아래).
ConsoleWrite("검색 결과에서 메뉴 선택 시도 중..." & @CRLF)
Send("{DOWN}")
Sleep(200)
Send("{DOWN}")
Sleep(200)
Send("{DOWN}")
Sleep(200)
Send("{ENTER}")
Sleep(1500)

ConsoleWrite("여기까지 완료! 화면이 실제로 엑셀판매관리 화면으로 이동했는지 확인해주세요." & @CRLF)

; ===== 7단계: 업로드 형식 선택 + 엑셀업로드 버튼 클릭 =====
; MARK: "엑셀판매관리"는 창 제목이 아니라 화면 안의 텍스트였어요(별도 창으로 안 잡힘) —
; 로그인 때 이미 잡아둔 $hMainWin을 그대로 씁니다(같은 창 안에서 화면 내용만 바뀐 것).
ConsoleWrite("업로드 형식(일자-POS-채널-바코드-수량-단가) 선택 중..." & @CRLF)
Local $hUploadWin = $hMainWin
WinActivate($hUploadWin)
Sleep(500)

; "일자-POS-채널-바코드-수량-단가" 라디오버튼 선택
ConsoleWrite("업로드 형식(일자-POS-채널-바코드-수량-단가) 선택 중..." & @CRLF)
ControlClick($hUploadWin, "", "Button22")
Sleep(500)

; ===== 8단계: 업로드할 파일 찾기 (바탕화면의 가장 최근 "인샵매출*.xlsx") =====
Local $sUploadFile = _GetLatestUploadFile()
If $sUploadFile = "" Then
    MsgBox($MB_OK, "실패", "바탕화면에서 '인샵매출*.xlsx' 파일을 못 찾았어요. build-inshop-upload.js를 먼저 실행해주세요.", 10)
    Exit
EndIf
ConsoleWrite("업로드할 파일: " & $sUploadFile & @CRLF)

; ===== 9단계: "엑셀업로드" 버튼 클릭 → 팝업 → 팝업 안의 "엑셀업로드" 버튼 → 파일 선택창 =====
ConsoleWrite("엑셀업로드 버튼 클릭..." & @CRLF)
ControlClick($hUploadWin, "", "Button17")
Sleep(1500)

; MARK: 예상과 달리 바로 파일선택창이 안 뜨고, "엑셀가져오기"라는 중간 팝업이 먼저 뜹니다.
; 그 팝업 안에 있는 "엑셀업로드" 버튼을 한 번 더 눌러야 진짜 파일선택창이 뜹니다.
ConsoleWrite("엑셀가져오기 팝업 기다리는 중..." & @CRLF)
Local $hImportPopup = WinWait("엑셀판매업로드", "", 10)
If $hImportPopup = 0 Then
    MsgBox($MB_OK, "실패", "엑셀가져오기 팝업을 못 찾았어요.", 10)
    Exit
EndIf
WinActivate($hImportPopup)
Sleep(500)
ConsoleWrite("팝업 안의 엑셀업로드 버튼 클릭..." & @CRLF)
ControlClick($hImportPopup, "", "Button2")
Sleep(1500)

; 파일 선택창은 표준 윈도우 대화상자입니다 (경로칸에 전체 경로를 직접 넣고 엔터).
; MARK: 이 대화상자는 제목이 "열기"이고, "열기" 버튼은 Button1이 아니라 Button2였습니다
; (실제 AutoIt Window Info로 확인함).
Local $hFileDlg = WinWait("열기", "", 10)
If $hFileDlg = 0 Then
    MsgBox($MB_OK, "실패", "파일 선택창을 못 찾았어요.", 10)
    Exit
EndIf
WinActivate($hFileDlg)
Sleep(500)
ControlSetText($hFileDlg, "", "Edit1", $sUploadFile)
Sleep(500)
ControlClick($hFileDlg, "", "Button2") ; 실제 "열기" 버튼
Sleep(2000)

ConsoleWrite("파일 선택 완료! 미리보기 데이터가 화면에 떴는지 확인해주세요." & @CRLF)

; ===== 10단계: 업로드 완료 알림(ALERT) 확인 =====
ConsoleWrite("엑셀업로드 완료 알림 기다리는 중..." & @CRLF)
Local $hAlert = WinWait("ALERT", "", 10)
If $hAlert = 0 Then
    MsgBox($MB_OK, "실패", "엑셀업로드 완료 알림(ALERT)을 못 찾았어요.", 10)
    Exit
EndIf
WinActivate($hAlert)
Sleep(300)
ControlClick($hAlert, "", "Button1")
Sleep(500)

; ===== 11단계: "적용" 버튼 클릭 (엑셀가져오기 팝업 안) =====
ConsoleWrite("적용 버튼 클릭..." & @CRLF)
WinActivate($hImportPopup)
Sleep(300)
ControlClick($hImportPopup, "", "Button4")
Sleep(1000)

; ===== 12단계: "저장" 버튼 클릭 (메인 화면) =====
ConsoleWrite("저장 버튼 클릭..." & @CRLF)
WinActivate($hUploadWin)
Sleep(500)
ControlClick($hUploadWin, "", "Button10")
Sleep(1000)

; ===== 13단계: "저장하시겠습니까" 확인(CONFIRM) 팝업에서 "예" 클릭 =====
ConsoleWrite("저장 확인 팝업 처리 중..." & @CRLF)
Local $hConfirm = WinWait("CONFIRM", "", 10)
If $hConfirm = 0 Then
    MsgBox($MB_OK, "실패", "저장 확인(CONFIRM) 팝업을 못 찾았어요.", 10)
    Exit
EndIf
WinActivate($hConfirm)
Sleep(300)
ControlClick($hConfirm, "", "Button1")
Sleep(1500)

ConsoleWrite("✅ 전체 완료! ERP 업로드까지 자동으로 끝났어요." & @CRLF)
MsgBox($MB_OK, "완료", "✅ 전체 완료! ERP 업로드까지 자동으로 끝났어요. 실제로 저장됐는지 화면에서 확인해주세요.", 10)
; (ERP 종료는 파일 맨 위에 등록해둔 _CloseErpOnExit가 스크립트 종료 시 자동으로 처리합니다)

; ===== 헬퍼 함수: 바탕화면에서 가장 최근 "인샵매출*.xlsx" 파일 찾기 =====
Func _GetLatestUploadFile()
    Local $sDesktop = @DesktopDir
    Local $hSearch = FileFindFirstFile($sDesktop & "\인샵매출*.xlsx")
    If $hSearch = -1 Then Return ""
    Local $sLatest = ""
    Local $sFile
    While 1
        $sFile = FileFindNextFile($hSearch)
        If @error Then ExitLoop
        If $sFile > $sLatest Then $sLatest = $sFile ; 파일명에 날짜가 있어서 문자열 비교로 최신 파일 판별 가능
    WEnd
    FileClose($hSearch)
    If $sLatest = "" Then Return ""
    Return $sDesktop & "\" & $sLatest
EndFunc
