// 무신사 전용 — 새벽 1시에 성공하는 것으로 확인됨(실측). 딱 그 시간에만 시도합니다.
const { runChannelScheduler } = require("./channel-scheduler.js");
const { fetchMusinsa } = require("./build-inshop-upload.js");

runChannelScheduler({
  channelKey: "musinsa",
  channelName: "무신사",
  retryHours: [1],
  fetchFn: fetchMusinsa,
});
