// SG ERP(gierp.sgerp.com) 인샵매출 자동 업로드 스크립트
//
// MiPlatform이라는 프레임워크로 만들어진 ERP 프로그램인데, 데이터를 압축된 바이너리
// 형식으로 주고받습니다. Fiddler로 캡처한 실제 업로드 과정을 바이트 단위로 분석해서
// 정확히 재현하도록 만들었습니다(테스트로 직접 만든 바이트가 실제 캡처와 100% 일치하는 것까지 확인함).
//
// 순서: 로그인 → getExcelListP03(엑셀 미리보기, 서버가 마진율/부가세 등을 계산해서 돌려줌)
//       → saleReg(그 결과를 그대로 다시 보내서 최종 저장)
//
// 준비물(.env):
//   SGERP_LOGIN_ID=sjc
//   SGERP_LOGIN_PW=실제비밀번호
//
// 사용법 (다른 스크립트에서 불러와서 씀):
//   const { uploadToErp } = require("./sgerp-upload.js");
//   await uploadToErp(rows); // rows: [{date,pos,channel,barcode,qty,price}, ...]
//
// 단독 실행(테스트용):
//   node sgerp-upload.js  ← 바탕화면의 최신 "인샵매출*.xlsx" 파일을 찾아서 업로드 시도

const http = require("http");
const zlib = require("zlib");
require("dotenv").config();

const HOST = "gierp.sgerp.com";
const LOGIN_ID = process.env.SGERP_LOGIN_ID;
const LOGIN_PW = process.env.SGERP_LOGIN_PW;
const COMP_CD = "GI001";

function log(...args) {
  console.log(`[SG ERP] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

// ---------- 바이너리 인코딩 유틸 ----------
function u16(n) {
  const b = Buffer.alloc(2);
  b.writeUInt16BE(n);
  return b;
}
function u32(n) {
  const b = Buffer.alloc(4);
  b.writeUInt32BE(n);
  return b;
}
function kvPair(key, val) {
  const k = Buffer.from(key, "utf8");
  const v = Buffer.from(String(val ?? ""), "utf8");
  return Buffer.concat([u16(k.length), k, Buffer.from([0, 8]), u16(v.length), v]);
}
function encodeValue(val) {
  if (val === null || val === undefined) return Buffer.from([0, 0]); // NULL
  const vb = Buffer.from(String(val), "utf8");
  return Buffer.concat([Buffer.from([0, 8]), u16(vb.length), vb]);
}
// 컬럼정의+행데이터로 된 데이터셋 하나를 통째로 만듭니다(getExcelListP03의 inDs, pDs, paramDs 전부 이 형태).
// 컬럼정의+행데이터로 된 데이터셋 하나를 통째로 만듭니다.
// colTypeBytes: 컬럼 하나당 붙는 6바이트 타입정보 — 실제 캡처 검증 결과, 데이터셋 종류에 따라
// 조금씩 달랐습니다(엑셀업로드용 Col0X는 [0,1,1,0,0,1], 파라미터용은 [0,1,0,0xff,0,1]).
// MARK: 진짜 원인을 찾았습니다 — 행이 1개일 땐 "행 전체 길이 + 행개수(1) 한 번"과
// "행마다 자기 길이를 따로 갖는 것"이 우연히 같은 바이트가 나와서 구분이 안 됐는데,
// 실제로는 각 행이 [이 행의 길이][고정값 1][컬럼개수][값들...] 블록을 통째로 반복하는
// 구조였습니다(행이 여러 개일 때만 차이가 드러남 — 실제 다건 캡처로 재검증해서 확인).
function buildDataset(name, columns, rowsOfValues, colTypeBytes = [0, 1, 1, 0, 0, 1]) {
  const colBytes = Buffer.concat(
    columns.map((c) => {
      const cb = Buffer.from(c, "utf8");
      return Buffer.concat([u16(cb.length), cb, Buffer.from(colTypeBytes)]);
    })
  );
  let allRowsBuf = Buffer.alloc(0);
  for (const values of rowsOfValues) {
    const valuesEncoded = Buffer.concat(values.map((v) => encodeValue(v)));
    const inner = Buffer.concat([Buffer.from([0, 1]), u16(columns.length), valuesEncoded]); // [00 01][컬럼개수][값들]
    const rowBlock = Buffer.concat([u16(inner.length), inner]); // [이 행 길이][00 01][컬럼개수][값들]
    allRowsBuf = Buffer.concat([allRowsBuf, rowBlock]);
  }
  const dsBody = Buffer.concat([
    Buffer.from([0xfe, 0x10, 0x0f, 0xa0]),
    Buffer.from([0, 2]),
    u32(columns.length),
    colBytes,
    allRowsBuf,
    Buffer.from([0, 0, 0, 0]),
  ]);
  const nameBuf = Buffer.from(name, "utf8");
  return Buffer.concat([u16(nameBuf.length), nameBuf, dsBody]);
}

// 전체 요청 바디(헤더 KV + 데이터셋들)를 만듭니다.
function buildRequestBody(counterByte, kvList, datasetBufs) {
  const kvBytes = Buffer.concat(kvList.map(([k, v]) => kvPair(k, v)));
  const kvSection = Buffer.concat([Buffer.from([0, counterByte, 0xfe, 0x10, 0x0f, 0xa0]), u16(kvBytes.length + 2), u16(kvList.length), kvBytes]);
  const dsAll = Buffer.concat(datasetBufs);
  const footer = Buffer.concat([Buffer.from([0xfe, 0x01, 0x0f, 0xa0]), u16(dsAll.length)]);
  return Buffer.concat([kvSection, footer, dsAll]);
}

function compress(buf) {
  return Buffer.concat([Buffer.from([0xff, 0xad]), zlib.deflateSync(buf)]);
}
function decompress(buf) {
  return zlib.inflateSync(buf.slice(2));
}

// ---------- 쿠키 저장소 ----------
class CookieJar {
  constructor() {
    this.jsessionid = null;
  }
  update(setCookieHeaders) {
    if (!setCookieHeaders) return;
    const arr = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
    for (const raw of arr) {
      const m = raw.match(/JSESSIONID=([^;]+)/);
      if (m) this.jsessionid = m[1];
    }
  }
  header() {
    if (!this.jsessionid) return "";
    return `Expires=Thu, 01-Jan-1970 00:00:00 GMT; JSESSIONID=${this.jsessionid}; Max-Age=0; path=/; SCOUTER=xagentnode1`;
  }
}
const jar = new CookieJar();

// ---------- HTTP 요청 ----------
function httpRequest(method, path, body, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const headers = {
      Accept: "*/*",
      "Cache-Control": "no-cache",
      "User-Agent": "MiPlatform 3.2;win32;1920x1080",
      "Accept-Encoding": "identity",
      "Accept-Charset": "utf-8",
      "Accept-Language": "ko-KR",
      ...extraHeaders,
    };
    if (jar.header()) headers["Cookie"] = jar.header();
    if (body) {
      headers["Content-Type"] = "application/octet-stream";
      headers["Content-Length"] = body.length;
    }
    const req = http.request({ host: HOST, path, method, headers }, (res) => {
      jar.update(res.headers["set-cookie"]);
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => resolve({ status: res.statusCode, body: Buffer.concat(chunks) }));
    });
    req.on("error", reject);
    if (body) req.write(body);
    req.end();
  });
}

function getErrorCode(decompressed) {
  const idx = decompressed.indexOf("ErrorCode");
  if (idx < 0) return null;
  const after = decompressed.slice(idx + "ErrorCode".length);
  const typeMarker = after.readUInt16BE(0);
  if (typeMarker === 3) return after.readInt32BE(2);
  return null;
}

function getErrorMsg(decompressed) {
  const idx = decompressed.indexOf("ErrorMsg");
  if (idx < 0) return "";
  const after = decompressed.slice(idx + "ErrorMsg".length);
  const typeMarker = after.readUInt16BE(0);
  if (typeMarker !== 8) return "";
  const len = after.readUInt16BE(2);
  return after.slice(4, 4 + len).toString("utf8");
}

// ---------- 로그인 ----------
async function login() {
  log("로그인 중...");
  const kvList = [
    ["_method", "login"],
    ["Expires", "Thu, 01-Jan-1970 00:00:00 GMT"],
    ["gv_checkLoginUrl", "dreamerp"],
    ["gv_CompCd", ""],
    ["gv_CompNm", ""],
    ["gv_DeptCd", ""],
    ["gv_DeptNm", ""],
    ["gv_EmpID", ""],
    ["gv_EmpNm", ""],
    ["gv_LoginID", ""],
    ["Max-Age", "0"],
    ["path", "/"],
    ["SCOUTER", "xagentnode1"],
  ];
  const inDs = buildDataset("inDataSet", ["comp_cd", "login_id", "login_pw"], [[COMP_CD, LOGIN_ID, LOGIN_PW]], [0, 1, 0, 0xff, 0, 1]);
  const body = compress(buildRequestBody(2, kvList, [inDs]));

  const res = await httpRequest("POST", "/common/Login.do", body);
  const d = decompress(res.body);
  const errMsg = getErrorMsg(d);
  if (errMsg) throw new Error(`로그인 실패: ${errMsg}`);
  if (!jar.jsessionid) throw new Error("로그인 응답에서 세션(JSESSIONID)을 못 받았어요.");
  log("로그인 성공.");
}

// 로그인 직후에 쓰는 좀 더 단순한 헤더(Susl0020용 commonKv보다 항목이 적음) — 실제 캡처에서
// Syco0030/0036(메뉴 초기화) 요청이 이 형태를 썼습니다.
function postLoginKv(method) {
  return [
    ["_method", method],
    ["Expires", "Thu, 01-Jan-1970 00:00:00 GMT"],
    ["gv_checkLoginUrl", "dreamerp"],
    ["gv_CompCd", "GI001"],
    ["gv_CompNm", "(주)포이닉스"],
    ["gv_DeptCd", "10005"],
    ["gv_DeptNm", "오프라인"],
    ["gv_EmpID", LOGIN_ID],
    ["gv_EmpNm", "소재천"],
    ["gv_LoginID", LOGIN_ID],
    ["JSESSIONID", jar.jsessionid || ""],
    ["Max-Age", "0"],
    ["path", "/"],
    ["SCOUTER", "xagentnode1"],
  ];
}

// MARK: 로그인만 하고 바로 업로드를 시도하면 서버에서 "COMP_CD를 NULL로 넣을 수 없다"는
// SQL 에러가 났습니다 — 실제 캡처를 보니 로그인 직후 화면이 메뉴 목록을 두 번(전체메뉴/
// 마이메뉴) 불러오는데, 이 과정에서 서버 쪽에 회사코드 관련 세션 컨텍스트가 잡히는 것 같습니다.
// 그래서 로그인 후 업로드 시도 전에 이 두 호출을 그대로 재현해서 끼워넣습니다.
async function initMenuContext() {
  log("메뉴 초기화 중...");
  const kv1 = postLoginKv("userMenuList");
  const inDs1 = buildDataset(
    "inDataSet",
    ["comp_cd", "admin_yn", "login_id", "start_pmenu_id", "is_simulator"],
    [[COMP_CD, "N", LOGIN_ID, "", "N"]],
    [0, 1, 0, 0xff, 0, 1]
  );
  const body1 = compress(buildRequestBody(2, kv1, [inDs1]));
  const res1 = await httpRequest("POST", "/syco/Syco0030.do", body1);
  const d1 = decompress(res1.body);
  if (getErrorCode(d1) !== 0 && getErrorMsg(d1)) throw new Error(`메뉴 초기화 실패(userMenuList): ${getErrorMsg(d1)}`);

  const kv2 = postLoginKv("myMenuList");
  const inDs2 = buildDataset("inDataSet", ["comp_cd", "login_id", "start_menu_id"], [[COMP_CD, LOGIN_ID, "MYMENU"]], [0, 1, 0, 0xff, 0, 1]);
  const body2 = compress(buildRequestBody(2, kv2, [inDs2]));
  const res2 = await httpRequest("POST", "/syco/Syco0036.do", body2);
  const d2 = decompress(res2.body);
  if (getErrorCode(d2) !== 0 && getErrorMsg(d2)) throw new Error(`메뉴 초기화 실패(myMenuList): ${getErrorMsg(d2)}`);

  log("메뉴 초기화 완료.");
}

// MARK: 실제 캡처에서, 업로드 화면(FSSUSL0020)으로 들어갈 때 "이 화면에 방문했다"는
// 기록을 남기는 호출이 있었습니다(Common.do/pgmUsageSave, menu_id=FSSUSL0020). 이게
// 서버 쪽에 뭔가 필요한 컨텍스트를 세팅해줄 수도 있어서 재현합니다. 실패해도 치명적이지
// 않을 수 있어서(단순 사용이력 기록일 수도 있음) 에러가 나도 무시하고 계속 진행합니다.
async function visitScreen(menuId, pmenuId) {
  log(`화면 진입 기록 중 (${menuId})...`);
  const kvList = [
    ["_method", "pgmUsageSave"],
    ["access_ip", "127.0.0.1"],
    ["Expires", "Thu, 01-Jan-1970 00:00:00 GMT"],
    ["gv_AdminYn", "N"],
    ["gv_checkLoginUrl", "dreamerp"],
    ["gv_CompCd", "GI001"],
    ["gv_CompNm", "(주)포이닉스"],
    ["gv_CustCd", ""],
    ["gv_DeptCd", "10005"],
    ["gv_DeptNm", "오프라인"],
    ["gv_EmpID", LOGIN_ID],
    ["gv_EmpNm", "소재천"],
    ["gv_KeyCompCd", "GI001"],
    ["gv_KeyCompNm", "(주)포이닉스"],
    ["gv_LoginID", LOGIN_ID],
    ["gv_MacAddr", "BC-FC-E7-8A-95-25"],
    ["gv_MenuId", ""],
    ["gv_SysID", "EMP"],
    ["JSESSIONID", jar.jsessionid || ""],
    ["Max-Age", "0"],
    ["menu_id", menuId],
    ["path", "/"],
    ["pmenu_id", pmenuId],
    ["SCOUTER", "xagentnode1"],
  ];
  try {
    const body = compress(buildRequestBody(1, kvList, []));
    const res = await httpRequest("POST", "/common/Common.do", body);
    const d = decompress(res.body);
    const errMsg = getErrorMsg(d);
    if (errMsg) log(`⚠ 화면 진입 기록에서 메시지(무시하고 계속): ${errMsg}`);
    else log("화면 진입 기록 완료.");
  } catch (e) {
    log(`⚠ 화면 진입 기록 실패(무시하고 계속): ${e.message}`);
  }
}

function commonKv(method, menuId) {
  return [
    ["_method", method],
    ["Expires", "Thu, 01-Jan-1970 00:00:00 GMT"],
    ["gv_AdminYn", "N"],
    ["gv_checkLoginUrl", "dreamerp"],
    ["gv_CompCd", "GI001"],
    ["gv_CompNm", "(주)포이닉스"],
    ["gv_CustCd", ""],
    ["gv_DeptCd", "10005"],
    ["gv_DeptNm", "오프라인"],
    ["gv_EmpID", LOGIN_ID],
    ["gv_EmpNm", "소재천"],
    ["gv_KeyCompCd", "GI001"],
    ["gv_KeyCompNm", "(주)포이닉스"],
    ["gv_LoginID", LOGIN_ID],
    ["gv_MacAddr", "BC-FC-E7-8A-95-25"],
    ["gv_MenuId", menuId || ""],
    ["gv_SysID", "EMP"],
    ["JSESSIONID", jar.jsessionid || ""], // MARK: 이게 몸통 안에도 빠져있던 게 진짜 버그였어요 — 쿠키로만 보내고 있었음
    ["Max-Age", "0"],
    ["path", "/"],
    ["SCOUTER", "xagentnode1"],
  ];
}

// ---------- 엑셀 미리보기(getExcelListP03) ----------
async function getExcelListP03(rows, targetDateDash) {
  log(`엑셀 미리보기 조회 중... (${rows.length}건)`);
  // MARK: 실제 로그인부터 끝까지 새로 캡처해서 확인한 결과, 컬럼이 6개가 아니라 8개였습니다
  // (Col07=출처/매장명, Col08=빈값). 예전에 다른 캡처 보고 6개로 줄였던 게 잘못이었어요.
  const columns = ["Col01", "Col02", "Col03", "Col04", "Col05", "Col06", "Col07", "Col08"];
  const rowValues = rows.map((r) => [r.date, r.pos, r.channel, r.barcode, r.qty, r.price, r.source || "", ""]);
  log(`🔍 [진단] 보내는 데이터 예시(처음 3건): ${JSON.stringify(rowValues.slice(0, 3))}`);
  const inDs = buildDataset("inDs", columns, rowValues);
  const pDs = buildDataset(
    "pDs",
    ["p_sale_dt", "p_pos_no", "p_sale_gb", "p_gubun"],
    [["2", "P1", targetDateDash.replace(/-/g, ""), "02"]],
    [0, 1, 0, 0xff, 0, 1]
  );

  const kvList = commonKv("getExcelListP03", "");
  const body = compress(buildRequestBody(3, kvList, [inDs, pDs]));

  const res = await httpRequest("POST", "/fs/susl/Susl0020.do", body);
  const d = decompress(res.body);
  const errCode = getErrorCode(d);
  const errMsg = getErrorMsg(d);
  log(`🔍 [진단] 응답 status=${res.status}, ErrorCode=${errCode}, ErrorMsg="${errMsg}", 응답 전체 길이=${d.length}바이트`);
  if (errCode !== 0) throw new Error(`엑셀 미리보기 실패 (ErrorCode=${errCode}): ${errMsg}`);

  const marker = Buffer.from("outDs", "utf8");
  const idx = d.indexOf(marker);
  if (idx < 0) throw new Error("응답에서 outDs를 못 찾았어요.");
  const outDsBytes = d.slice(idx - 2); // [00 05] + "outDs" + 데이터셋 본문(끝까지)

  // outDs 안의 실제 행 개수를 파싱해서 보여줍니다.
  // MARK: 행마다 [이 행 길이][고정값1][컬럼개수][값들]이 반복되는 구조라, 길이=0(끝 마커)이
  // 나올 때까지 하나씩 건너뛰면서 셉니다.
  try {
    const openIdx = outDsBytes.indexOf(Buffer.from([0xfe, 0x10, 0x0f, 0xa0]));
    const colCount = outDsBytes.readUInt32BE(openIdx + 6);
    log(`🔍 [진단] outDs 컬럼 개수: ${colCount}`);
    let p = openIdx + 10;
    for (let i = 0; i < colCount; i++) {
      const nameLen = outDsBytes.readUInt16BE(p);
      p += 2 + nameLen + 6;
    }
    let rowCount = 0;
    while (p + 2 <= outDsBytes.length) {
      const rowLen = outDsBytes.readUInt16BE(p);
      if (rowLen === 0) break; // 끝 마커(0000)
      p += 2 + rowLen;
      rowCount++;
    }
    log(`🔍 [진단] outDs 실제 행 개수: ${rowCount}`);
    if (rowCount === 0) {
      log("⚠ 서버가 0건을 돌려줬어요 — 이번에 보낸 데이터가 상품마스터에서 하나도 안 찾아진 것 같아요.");
    } else if (rowCount < rows.length) {
      log(`⚠ 보낸 ${rows.length}건 중 ${rowCount}건만 매칭됐어요 — 나머지는 바코드가 상품마스터에 없는 것 같아요.`);
    }
    log(`미리보기 완료 (응답 ${outDsBytes.length}바이트).`);
    return { outDsBytes, matchedCount: rowCount };
  } catch (e) {
    log(`🔍 [진단] 행 개수 파싱 실패: ${e.message}`);
    log(`미리보기 완료 (응답 ${outDsBytes.length}바이트).`);
    return { outDsBytes, matchedCount: null };
  }
}

// ---------- 최종 저장(saleReg) ----------
async function saleReg(outDsBytes, targetDateDash) {
  log("최종 저장 중...");
  const inDsRenamed = Buffer.concat([u16(4), Buffer.from("inDs", "utf8"), outDsBytes.slice(2 + 5)]);
  log(`🔍 [진단] saleReg에 넣는 inDs 크기: ${inDsRenamed.length}바이트 (0에 가까우면 진짜 문제가 여기예요)`);
  const paramDs = buildDataset(
    "paramDs",
    ["sale_dt", "pos_no", "sale_gb", "reg_gb"],
    [["P1", null, targetDateDash.replace(/-/g, ""), "02"]],
    [0, 1, 0, 0xff, 0, 1]
  );

  const kvList = commonKv("saleReg", "FSSUSL0020");
  const body = compress(buildRequestBody(3, kvList, [inDsRenamed, paramDs]));

  const res = await httpRequest("POST", "/fs/susl/Susl0020.do", body);
  const d = decompress(res.body);
  const errCode = getErrorCode(d);
  log(`🔍 [진단] saleReg 응답 status=${res.status}, ErrorCode=${errCode}, ErrorMsg="${getErrorMsg(d)}"`);
  if (errCode !== 0) throw new Error(`최종 저장 실패 (ErrorCode=${errCode}): ${getErrorMsg(d)}`);
}

// ---------- 외부에서 쓰는 함수 ----------
async function uploadToErp(rows) {
  if (!LOGIN_ID || !LOGIN_PW) throw new Error("SGERP_LOGIN_ID / SGERP_LOGIN_PW가 .env에 없습니다.");

  // MARK: 빈 행(바코드/일자가 비어있는 행)이 섞여 들어오면 그대로 보내지 말고 걸러냅니다.
  const before = rows.length;
  rows = rows.filter((r) => r.date && r.barcode && r.channel);
  if (before !== rows.length) log(`⚠ 빈 값이 있는 행 ${before - rows.length}건을 걸러냈어요 (일자/바코드/채널 중 하나라도 비어있으면 제외).`);

  if (!rows.length) {
    log("업로드할 데이터가 없습니다.");
    return;
  }
  const targetDate = rows[0].date;
  const targetDateDash = `${targetDate.slice(0, 4)}-${targetDate.slice(4, 6)}-${targetDate.slice(6, 8)}`;

  await login();
  await initMenuContext();
  await visitScreen("FSSUSL0020", "FSSUSL");
  const { outDsBytes, matchedCount } = await getExcelListP03(rows, targetDateDash);
  if (matchedCount === 0) {
    log("❌ 매칭된 상품이 0건이라 저장할 게 없어요 — saleReg는 건너뜁니다. (바코드가 실제 상품마스터에 있는지 확인해주세요)");
    return;
  }
  await saleReg(outDsBytes, targetDateDash);
  log(`✅ 최종적으로 ${matchedCount ?? "?"}건 저장 완료!`);
}

module.exports = { uploadToErp };

// ---------- 단독 실행(테스트용) ----------
if (require.main === module) {
  (async () => {
    const path = require("path");
    const os = require("os");
    const fs = require("fs");
    const XLSX = require("xlsx");

    const desktop = path.join(os.homedir(), "Desktop");
    const files = fs
      .readdirSync(desktop)
      .filter((f) => f.startsWith("인샵매출") && f.endsWith(".xlsx"))
      .sort()
      .reverse();
    if (!files.length) {
      console.error("바탕화면에 '인샵매출...' 파일을 못 찾았어요.");
      process.exit(1);
    }
    const filePath = path.join(desktop, files[0]);
    log(`파일 사용: ${filePath}`);
    const wb = XLSX.readFile(filePath);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const raw = XLSX.utils.sheet_to_json(ws, { defval: "" });
    const rows = raw.map((r) => ({
      date: String(r["일자"]),
      pos: String(r["POS"]),
      channel: String(r["채널"]),
      barcode: String(r["바코드"]),
      qty: Number(r["수량"]),
      price: Number(r["단가"]),
      source: String(r["출처"] || ""),
    }));

    try {
      await uploadToErp(rows);
    } catch (err) {
      console.error("⚠ 실패:", err.message || err);
      process.exit(1);
    }
  })();
}
