; 테스트용: sgerp-login-only.exe로 ERP 로그인부터 딱 하고 → 성공 확인되면 → 이어서
; 파워오토메이트(erp_daily) 실행까지 한 번에 진행합니다.
;
; PA 흐름 자체에서 "ERP 켜고 로그인하는" 단계를 빼신 다음(그 단계가 새벽에 잘 안 됐던
; 부분), 이 스크립트로 "로그인은 우리가 미리 해두고 PA는 그 다음부터"가 실제로 잘
; 이어지는지 테스트해보세요.
;
; 준비물: sgerp-login-only.exe가 이 파일과 같은 폴더에 있어야 합니다
; (sgerp-login-only.au3를 Compile Script로 먼저 만들어두세요).
;
; MARK 2026-09-21 — 사고 원인 파악 + 재설계 (2026-09-20 새벽 2:25/3:35 흐름 삭제 팝업 사고):
; 실제로 화면을 열어서 직접 재현해봤습니다. 그동안 쓰던 절대좌표(검색창 x=1673 등)는
; 이 PC의 실제 창 너비(약 1456px)보다 커서 애초에 창 밖을 클릭하고 있었습니다 — 그래서
; 검색창이 포커스를 못 받았고, 포커스가 흐름 목록 자체에 남은 채로 Ctrl+A(=전체 선택)
; → Delete(=선택 삭제)가 그대로 먹혀서 "흐름 삭제" 확인 팝업이 뜬 거였습니다(다행히
; 기본 포커스가 "아니요"라 실제 삭제는 안 됐음).
;
; 이번에 두 가지를 고쳤습니다:
;   1. 절대좌표 대신 "흐름 실행" 확인 팝업 처리에서 이미 쓰던 것과 같은 방식 — 창 크기
;      대비 비율(%)로 좌표를 계산합니다. 해상도/DPI/이 PC 화면에 같이 떠있는 다른 창
;      배치가 달라져도 항상 창 안의 같은 상대 위치를 클릭하게 됩니다.
;   2. "목록에서 줄 클릭 → 툴바의 실행 버튼 클릭" 2단계를, 검색으로 필터링된 흐름 자체의
;      "▷ 실행" 아이콘을 바로 1번 클릭하는 걸로 단순화했습니다. 체크박스 선택 상태에
;      의존하지 않아서, 여러 개가 선택된 채 엉뚱한 툴바(삭제 버튼 등)를 누르게 될
;      위험 자체가 없어집니다.
; 그리고 혹시 모를 상황 대비로 "흐름 삭제" 팝업 감지 안전장치는 그대로 남겨뒀습니다.

#include <MsgBoxConstants.au3>
#include <ScreenCapture.au3>

; ===== 1단계: ERP 로그인만 먼저 실행 (끝날 때까지 기다림) =====
ConsoleWrite("===== 1단계: ERP 로그인 시작 =====" & @CRLF)
Local $sLoginExePath = @ScriptDir & "\sgerp-login-only.exe"
If Not FileExists($sLoginExePath) Then
    ConsoleWrite("⚠ sgerp-login-only.exe를 못 찾았어요. 먼저 sgerp-login-only.au3를 Compile Script로 .exe 만들어주세요. 찾던 경로: " & $sLoginExePath & @CRLF)
    Exit 1
EndIf

Local $iLoginExitCode = RunWait($sLoginExePath, @ScriptDir)
ConsoleWrite("로그인 스크립트 종료코드: " & $iLoginExitCode & @CRLF)

If $iLoginExitCode <> 0 Then
    ConsoleWrite("⚠ ERP 로그인이 실패한 것 같아요(종료코드 " & $iLoginExitCode & "). 파워오토메이트는 실행하지 않고 여기서 멈춥니다." & @CRLF)
    Exit 1
EndIf
ConsoleWrite("✅ ERP 로그인 성공 확인! 이어서 파워오토메이트를 실행합니다..." & @CRLF)
Sleep(1000)

; ===== 2단계: 파워오토메이트 실행 =====
ConsoleWrite("===== 2단계: 파워오토메이트 실행 시작 =====" & @CRLF)

Local $sFlowName = "erp_daily"
; MARK 2026-09-21: 절대좌표 대신 창 크기 대비 비율(2026-09-21 실측: 1456x819 창에서
; 검색창 중심 (1300,120), 필터링된 흐름의 자체 "실행" 아이콘 (505,200) 기준으로 계산).
Local $fSearchRatioX = 0.893, $fSearchRatioY = 0.1465 ; 검색창
Local $fRunIconRatioX = 0.347, $fRunIconRatioY = 0.244 ; 필터링된 흐름 줄의 자체 "실행"(▷) 아이콘

ConsoleWrite("Power Automate Desktop 앱 실행 중..." & @CRLF)
Run("explorer.exe shell:AppsFolder\Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Console")

ConsoleWrite("창 뜨는 중 기다리는 중..." & @CRLF)
Local $hWin = WinWait("Power Automate", "", 30)
If $hWin = 0 Then
    ConsoleWrite("⚠ Power Automate 창을 30초 안에 못 찾았어요." & @CRLF)
    Exit 1
EndIf

ConsoleWrite("창이 완전히 뜰 때까지 여유있게 기다리는 중..." & @CRLF)
Sleep(3000)

; MARK: 예전엔 여기서 WinSetState(@SW_MAXIMIZE)로 직접 최대화시켰는데, 이 동작 자체가
; 파워오토메이트(WPF 기반) 앱을 내부 오류로 죽이는 원인이었던 것으로 확인됐습니다. 파워
; 오토메이트는 마지막 창 크기/상태를 기억하기 때문에, 사용자가 손으로 한 번 최대화해두면
; 그다음부턴 항상 최대화된 채로 뜹니다 — 그래서 프로그램으로 최대화시키지 않습니다.
ConsoleWrite("창 위치 확인 중 (최대화는 사용자가 미리 설정해두신 상태를 그대로 씁니다)..." & @CRLF)
WinActivate($hWin)
Sleep(1000)

Local $aWinPos = WinGetPos($hWin)
If Not IsArray($aWinPos) Then
    ConsoleWrite("⚠ 창 위치를 못 가져왔어요." & @CRLF)
    Exit 1
EndIf
ConsoleWrite("🔍 [진단] 창 위치: " & $aWinPos[0] & "," & $aWinPos[1] & " 크기: " & $aWinPos[2] & "x" & $aWinPos[3] & @CRLF)

Local $iSearchX = $aWinPos[0] + Int($aWinPos[2] * $fSearchRatioX)
Local $iSearchY = $aWinPos[1] + Int($aWinPos[3] * $fSearchRatioY)
Local $iRunIconX = $aWinPos[0] + Int($aWinPos[2] * $fRunIconRatioX)
Local $iRunIconY = $aWinPos[1] + Int($aWinPos[3] * $fRunIconRatioY)
ConsoleWrite("🔍 [진단] 계산된 좌표 — 검색창: " & $iSearchX & "," & $iSearchY & " / 실행아이콘: " & $iRunIconX & "," & $iRunIconY & @CRLF)

ConsoleWrite("검색창 클릭 후 '" & $sFlowName & "' 입력 중..." & @CRLF)
; MARK 2026-09-21: 싱글클릭만으로는 가끔 검색창이 포커스를 못 받는 걸 실측으로 확인해서,
; 더블클릭으로 한 번 더 확실하게 포커스를 잡습니다.
MouseClick("left", $iSearchX, $iSearchY, 2)
Sleep(500)
Send("^a")
Send("{DEL}")
Sleep(200)
Send($sFlowName)
Sleep(1000) ; 필터링 결과 뜰 시간

; MARK 2026-09-21: 목록에서 줄을 따로 클릭해서 선택한 다음 툴바의 실행 버튼을 누르는 대신,
; 필터링된 흐름 자체의 "▷ 실행" 아이콘을 바로 클릭합니다. 체크박스/다중선택 상태와
; 무관하게 그 흐름 하나만 실행되고, 다른 흐름이 선택된 채 엉뚱한 툴바 버튼(삭제 등)을
; 누르게 될 위험이 구조적으로 없습니다.
ConsoleWrite("필터링된 흐름의 '실행'(▷) 아이콘 클릭 중..." & @CRLF)
MouseMove($iRunIconX, $iRunIconY, 5) ; MARK: 마우스를 올려야 아이콘이 나타나는 행일 수 있어 먼저 살짝 이동
Sleep(300)
MouseClick("left", $iRunIconX, $iRunIconY, 1)
Sleep(1500)

; ===== 위험한 "흐름 삭제" 팝업부터 최우선으로 확인 (안전장치) =====
; MARK 2026-09-21: 혹시 모를 상황(흐름 이름이 바뀌었거나, 검색이 예상과 다르게 동작하는
; 등)에 대비한 이중 안전장치입니다. 이 팝업이 뜨면 절대 그냥 넘어가지 않고, 즉시
; ESC(=취소, 기본 포커스인 "아니요"와 동일한 효과)를 눌러 취소한 뒤 실패로 중단합니다.
ConsoleWrite("🔍 위험한 '흐름 삭제' 팝업이 떴는지부터 확인 중..." & @CRLF)
Local $hDangerWin = WinWait("흐름 삭제", "", 3)
If $hDangerWin <> 0 Then
    ConsoleWrite("🚨 [위험] '흐름 삭제' 확인 팝업 감지! 즉시 취소합니다." & @CRLF)
    WinActivate($hDangerWin)
    Sleep(300)
    Send("{ESC}") ; MARK: ESC는 표준 Windows 대화상자에서 항상 "취소"와 동일 — 기본 포커스가 뭐든 안전
    Sleep(500)
    Local $sDangerPath = @DesktopDir & "\위험_흐름삭제팝업_" & @YEAR & @MON & @MDAY & "_" & @HOUR & @MIN & @SEC & ".png"
    _ScreenCapture_Capture($sDangerPath)
    ConsoleWrite("🔍 [진단] 위험 상황 스크린샷 저장: " & $sDangerPath & @CRLF)
    ConsoleWrite("⚠ 파워오토메이트 흐름은 실행되지 않았습니다. 좌표 재측정이 필요합니다 — 수동으로 확인해주세요." & @CRLF)
    Exit 2
EndIf
ConsoleWrite("위험한 팝업 없음 — 정상 진행합니다." & @CRLF)

; ===== "흐름 실행" 확인 팝업 처리 =====
; MARK: 앱 안에서 "실행"을 눌러도 이 흐름은 "외부 원본" 확인 팝업이 매번 뜨는 걸로
; 확인돼서, 뜨면 "계속" 버튼을 클릭합니다(비율 계산 방식 — 이 부분은 원래부터 비율
; 기반이라 이번 사고와 무관하게 잘 동작했습니다).
ConsoleWrite("'흐름 실행' 확인 팝업 뜨는지 확인 중..." & @CRLF)
Local $hConfirmWin = WinWait("흐름 실행", "", 8)
If $hConfirmWin <> 0 Then
    ConsoleWrite("확인 팝업 떴어요 — '계속' 버튼 클릭 시도..." & @CRLF)
    WinActivate($hConfirmWin)
    Sleep(500)
    Local $aConfirmPos = WinGetPos($hConfirmWin)
    If IsArray($aConfirmPos) Then
        Local $iContinueX = $aConfirmPos[0] + Int($aConfirmPos[2] * 0.74)
        Local $iContinueY = $aConfirmPos[1] + Int($aConfirmPos[3] * 0.80)
        MouseClick("left", $iContinueX, $iContinueY, 1)
        Sleep(1000)
    Else
        ConsoleWrite("⚠ 팝업 위치를 못 가져와서 Enter로 대신 시도합니다..." & @CRLF)
        Send("{ENTER}")
        Sleep(1000)
    EndIf
Else
    ConsoleWrite("확인 팝업 안 떴어요 — 그대로 진행합니다." & @CRLF)
EndIf

ConsoleWrite("✅ 완료! 로그인 → 파워오토메이트 실행까지 전부 진행됐어요. 실제로 흐름이 끝까지 잘 도는지 확인해주세요." & @CRLF)

; MARK: 디버그용 — 여기까지 진행된 화면 상태를 바탕화면에 스크린샷으로 남깁니다.
Local $sDebugPath = @DesktopDir & "\디버그_PA실행_" & @YEAR & @MON & @MDAY & "_" & @HOUR & @MIN & @SEC & ".png"
_ScreenCapture_Capture($sDebugPath)
ConsoleWrite("🔍 [디버그] 스크린샷 저장: " & $sDebugPath & @CRLF)
