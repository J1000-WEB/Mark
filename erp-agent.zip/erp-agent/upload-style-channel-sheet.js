// 스타일별 채널별 입고/판매/재고현황(금액) 엑셀 파일을 MARK 대시보드에 자동 업로드하는 스크립트
//
// 파워오토메이트가 다운받아둔 "PIP업데이트YYYYMMDD.xlsx"(C:\Users\User\Documents)를 읽어서,
// /api/upload-style-channel-sheet API를 start → chunk(여러 번) → finish 순서로 호출해서
// 대시보드(재고CTRL 화면)에 있는 "업로드" 버튼을 누른 것과 똑같은 결과를 만듭니다.
// 브라우저 화면 자동화가 아니라 API를 직접 호출하는 방식이라 훨씬 간단하고 빨라요.
//
// 준비물: npm install xlsx (이미 다른 스크립트에서 설치했으면 또 안 해도 됨)
//
// 실행: node upload-style-channel-sheet.js
//   (오늘 날짜 기준으로 파일명을 자동으로 찾습니다. 다른 날짜 파일을 쓰려면
//    node upload-style-channel-sheet.js 20260824 처럼 날짜를 인자로 줄 수 있어요)

const path = require("path");
const fs = require("fs");

const API_BASE = "https://mark-khaki.vercel.app";
const DOCS_DIR = "C:\\Users\\User\\Documents";
const CHUNK_SIZE = 1000; // 한 번에 보낼 행 수 — 너무 크면 요청이 실패할 수 있어서 적당히 나눔

// MARK: lib/styleChannelCompact.ts(대시보드 브라우저 업로드가 쓰는 압축 로직)를 그대로
// Node.js로 옮겼습니다. 594열짜리 원본을, 앞의 29개 "마스터" 열은 그대로 두고 그
// 뒤(채널별 5열씩 반복되는 블록)는 "값이 있는 것만" JSON 하나로 압축해서 31~32열로
// 줄입니다. 서버(expandStyleChannelRows)가 이 형태를 그대로 다시 원본 모양으로
// 복원해서 읽으므로, 이렇게 압축해서 올려야 대시보드가 예전처럼 정상적으로 읽습니다.
const STYLE_CHANNEL_MASTER_END = 29;
const STYLE_CHANNEL_METRICS = ["일간", "일간금액", "주간", "누적", "재고"];
const METRIC_COUNT = STYLE_CHANNEL_METRICS.length;
const HEADER_ROWS = 3;

function isEmptyCell(v) {
  return v === null || v === undefined || v === "" || v === 0 || v === "0";
}

function compactStyleChannelRows(rows) {
  if (!rows || rows.length <= HEADER_ROWS) return rows || [];

  const headerRows = rows.slice(0, HEADER_ROWS);
  const dataRows = rows.slice(HEADER_ROWS);

  const compactHeaders = headerRows.map((r) => {
    const master = r.slice(0, STYLE_CHANNEL_MASTER_END);
    const channelPart = r.slice(STYLE_CHANNEL_MASTER_END);
    return [...master, channelPart.length, JSON.stringify(channelPart)];
  });

  const compactData = dataRows.map((r) => {
    const master = r.slice(0, STYLE_CHANNEL_MASTER_END);
    const totalCols = r.length;
    const nChannels = Math.floor((totalCols - STYLE_CHANNEL_MASTER_END) / METRIC_COUNT);

    const detail = [];
    for (let ci = 0; ci < nChannels; ci++) {
      const base = STYLE_CHANNEL_MASTER_END + ci * METRIC_COUNT;
      const vals = r.slice(base, base + METRIC_COUNT);
      if (vals.every(isEmptyCell)) continue;
      const entry = {};
      STYLE_CHANNEL_METRICS.forEach((m, mi) => {
        if (!isEmptyCell(vals[mi])) entry[m] = vals[mi];
      });
      if (Object.keys(entry).length) detail.push([ci, entry]);
    }

    return [...master, totalCols, JSON.stringify(detail)];
  });

  return [...compactHeaders, ...compactData];
}

function log(...args) {
  console.log(`[스타일채널업로드] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
}

async function postJson(mode, body) {
  const res = await fetch(`${API_BASE}/api/upload-style-channel-sheet`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ mode, ...body }),
  });
  const text = await res.text();
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error(`[${mode}] 응답이 JSON이 아니에요 (status=${res.status}): ${text.slice(0, 500)}`);
  }
  if (!res.ok || json.ok === false) {
    throw new Error(`[${mode}] 실패: ${json.error || text.slice(0, 300)}`);
  }
  return json;
}

async function main() {
  const dateArg = process.argv[2] || todayString();
  const filePath = path.join(DOCS_DIR, `PIP업데이트${dateArg}.xlsx`);

  if (!fs.existsSync(filePath)) {
    console.error(`⚠ 파일이 없어요: ${filePath}`);
    process.exit(1);
  }
  log(`파일 읽는 중: ${filePath}`);

  const XLSX = require("xlsx");
  const wb = XLSX.readFile(filePath);
  const sheet = wb.Sheets[wb.SheetNames[0]];
  // header:1 → 2차원 배열(행 배열의 배열)로, 시트에 보이는 그대로 가져옵니다(첫 행도 포함).
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: "" });

  const totalRows = rows.length;
  const totalCols = rows.reduce((max, r) => Math.max(max, r.length), 0);
  log(`원본 ${totalRows}행 x ${totalCols}열.`);

  const compactRows = compactStyleChannelRows(rows);
  const compactTotalCols = compactRows.reduce((max, r) => Math.max(max, r.length), 0);
  const origCells = rows.reduce((sum, r) => sum + r.length, 0);
  const compactCells = compactRows.reduce((sum, r) => sum + r.length, 0);
  log(`압축 완료: ${totalCols}열 → ${compactTotalCols}열 (셀 수 ${origCells.toLocaleString()} → ${compactCells.toLocaleString()}, ${(origCells / compactCells).toFixed(1)}배 절감)`);
  log(`${CHUNK_SIZE}행씩 나눠서 업로드합니다.`);

  // ---- start: 첫 청크 ----
  const firstChunk = compactRows.slice(0, CHUNK_SIZE);
  log(`시작(start) — 기존 시트 삭제 후 새로 만들고 첫 ${firstChunk.length}행 씀...`);
  const startRes = await postJson("start", { rows: firstChunk, totalRows: compactRows.length, totalCols: compactTotalCols });
  const liveSheetName = startRes.liveSheetName;
  log(`✅ 시작 완료 (시트명: ${liveSheetName}, ${startRes.written}행 씀)`);

  // ---- chunk: 나머지 ----
  let written = firstChunk.length;
  while (written < compactRows.length) {
    const chunk = compactRows.slice(written, written + CHUNK_SIZE);
    const startRow = written + 1; // 1-indexed
    log(`업로드 중... (${written}/${compactRows.length}행)`);
    await postJson("chunk", { rows: chunk, liveSheetName, startRow });
    written += chunk.length;
  }
  log(`✅ 전체 업로드 완료 (${written}행)`);

  // ---- finish: 검증 ----
  log("검증 중...");
  const finishRes = await postJson("finish", { liveSheetName, expectedTotalRows: compactRows.length });
  log(`✅ 완료! 최종 확인된 행수: ${finishRes.totalRows} (품목 ${finishRes.totalRows - HEADER_ROWS}개)`);
}

main().catch((err) => {
  console.error("⚠ 실패:", err.message || err);
  process.exit(1);
});
