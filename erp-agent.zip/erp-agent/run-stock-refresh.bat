@echo off
REM MARK ERP Agent - 재고(SL4010) 15분마다 갱신
cd /d "%~dp0"

echo ============================================
echo  MARK 재고 실시간 갱신 (15분 주기) - 실행중
echo  (이 창을 닫으면 멈춥니다)
echo ============================================
echo.

node run-loop-interval.js stock-refresh.js 15

echo.
echo (멈췄습니다. 아무 키나 누르면 창이 닫힙니다)
pause >nul
