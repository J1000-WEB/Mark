// MARK ERP Agent — 매출목표 자동 갱신 스케줄러 (MARK 6.74)
//
// run-daily-schedule.js(매일 새벽 4시)와 같은 패턴이지만, 이건 "월요일 아침에만" 실행합니다.
// 이 창을 계속 켜두시면(최소화만 하고 닫지 않으면), 소천님이 버튼을 안 눌러도 매주 월요일
// 아침에 자동으로 target-refresh.js가 돌아서 매출목표를 갱신합니다.
//
// 실행: node erp-agent/run-monday-schedule.js
// (또는 run-target-refresh.bat 더블클릭)
//
// 테스트하고 싶으면: set TARGET_RUN_NOW=1 (요일 상관없이 지금 즉시 한 번 실행하고 스케줄로 넘어감)

const path = require("path");
const { spawn } = require("child_process");

const RUN_HOUR = Number(process.env.TARGET_RUN_HOUR || 7); // 월요일 몇 시에 실행할지 (기본 오전 7시)
const CHECK_INTERVAL_MS = 30 * 60 * 1000; // 30분마다 "지금 실행할 시간인가" 체크

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" })}]`, ...args);
}

function runScript() {
  return new Promise((resolve, reject) => {
    const child = spawn("node", [path.join(__dirname, "target-refresh.js")], {
      cwd: __dirname,
      stdio: "inherit",
      env: process.env,
    });
    child.on("error", reject);
    child.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`target-refresh.js 종료 코드 ${code}`))));
  });
}

function nowKST() {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Seoul" }));
}
function todayKeyKST() {
  const d = nowKST();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

async function loop() {
  log(`매출목표 월요일 자동 갱신 스케줄 시작 (매주 월요일 ${RUN_HOUR}시경 실행, 30분마다 체크)`);
  let lastRunDateKey = null;

  if (process.env.TARGET_RUN_NOW === "1") {
    log("TARGET_RUN_NOW=1 — 지금 즉시 한 번 실행합니다.");
    try {
      await runScript();
      lastRunDateKey = todayKeyKST();
    } catch (err) {
      log(`⚠ 실행 실패: ${err.message || err}`);
    }
  }

  while (true) {
    const d = nowKST();
    const isMonday = d.getDay() === 1;
    const pastRunHour = d.getHours() >= RUN_HOUR;
    const dateKey = todayKeyKST();

    if (isMonday && pastRunHour && lastRunDateKey !== dateKey) {
      log("===== 월요일 매출목표 갱신 실행 =====");
      try {
        await runScript();
        lastRunDateKey = dateKey;
        log("이번 주는 완료 — 다음 주 월요일까지 대기합니다.");
      } catch (err) {
        log(`⚠ 실행 실패: ${err.message || err} (30분 뒤 다시 시도합니다)`);
      }
    }

    await new Promise((r) => setTimeout(r, CHECK_INTERVAL_MS));
  }
}

loop();
