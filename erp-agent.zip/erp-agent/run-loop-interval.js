// MARK ERP Agent — 범용 반복 실행 래퍼 (MARK 6.71)
//
// run-loop.js(스크래핑 전용, scrape.js+parse-and-upload.js 고정)와 달리, 이건 아무
// 스크립트나 원하는 주기로 반복 실행할 수 있는 범용 버전입니다.
//
// 실행:
//   node erp-agent/run-loop-interval.js <스크립트파일명> <주기(분)>
//   예) node erp-agent/run-loop-interval.js stock-refresh.js 15
//   예) node erp-agent/run-loop-interval.js sales-refresh.js 40
//
// 이 창을 계속 켜두시면(최소화만 하고 닫지 않으면) 알아서 계속 갱신됩니다.

const { spawn } = require("child_process");
const path = require("path");

const scriptName = process.argv[2];
const intervalMinutes = Number(process.argv[3]);

if (!scriptName || !intervalMinutes || intervalMinutes <= 0) {
  console.error("사용법: node run-loop-interval.js <스크립트파일명> <주기(분)>");
  console.error("예) node run-loop-interval.js stock-refresh.js 15");
  process.exit(1);
}

const INTERVAL_MS = intervalMinutes * 60 * 1000;

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" })}]`, ...args);
}

function runScript() {
  return new Promise((resolve, reject) => {
    const child = spawn("node", [path.join(__dirname, scriptName)], {
      cwd: __dirname,
      stdio: "inherit",
      env: process.env,
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${scriptName} 종료 코드 ${code}`));
    });
  });
}

async function loop() {
  log(`${scriptName} 반복 실행 시작 (주기: ${intervalMinutes}분)`);
  while (true) {
    log(`===== ${scriptName} 실행 =====`);
    try {
      await runScript();
    } catch (err) {
      log(`⚠ 실행 실패: ${err.message || err}`);
    }
    log(`다음 실행까지 ${intervalMinutes}분 대기...`);
    await new Promise((r) => setTimeout(r, INTERVAL_MS));
  }
}

loop();
