// 스타일별 채널별 입고/판매/재고현황 업로드를 매일 오전 4시에 자동 실행하는 스케줄러.
// 파워오토메이트(2시50분)가 파일을 다 받아놓을 시간을 넉넉히 두고 4시로 잡았습니다.

const { spawn } = require("child_process");
const path = require("path");

const TARGET_HOUR = 4;
const TARGET_MINUTE = 50;
const CHECK_INTERVAL_MS = 60 * 1000;

function log(...args) {
  console.log(`[스타일채널업로드-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

let lastRunDate = null;

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function runUpload() {
  log("오전 4시가 되어 스타일별채널별 업로드를 시작합니다...");
  const child = spawn("node", [path.join(__dirname, "upload-style-channel-sheet.js")], { stdio: "inherit" });
  child.on("exit", (code) => {
    log(`업로드 스크립트 종료 (코드 ${code}).`);
  });
}

function tick() {
  const now = new Date();
  const today = todayString();
  if (now.getHours() === TARGET_HOUR && now.getMinutes() === TARGET_MINUTE && lastRunDate !== today) {
    lastRunDate = today;
    runUpload();
  }
}

log(`시작합니다. 매일 오전 ${TARGET_HOUR}시에 스타일별채널별 업로드를 자동 실행합니다.`);
setInterval(tick, CHECK_INTERVAL_MS);
tick();
