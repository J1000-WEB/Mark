// MARK ERP Agent — 일일 재고 스냅샷 + 전일 매출 확정 스크립트
//
// 하는 일 (04시 실행을 목표로 설계, 지금은 수동 테스트용):
//   1) Product360(gi-board)에서 "재고 > 0"인 전체 품번의 스타일+컬러 조합을 뽑음 (3안)
//   2) ERP에 로그인 (브라우저 없이 순수 HTTP — Playwright 불필요, 훨씬 빠름)
//   3) 오프라인 매장 목록을 ERP에서 가져와서 (SHOP_GB 2/3/4/5 = 로드샵/백화점/아울렛/쇼핑몰)
//   4) 스타일+컬러 조합 x 채널(로드샵/백화점/아울렛/쇼핑몰) 4번씩 재고 조회 (SL4010)
//      → 매장별 현재고(TOT_QTY) 수집
//   5) 어제 날짜로 오프라인 매장별 매출을 다시 조회 (SL1010, 확정치 — 이미 하루가 다 지났으므로
//      이 시점에 조회하면 그날 최종 매출 그대로임, 별도 델타 계산 필요 없음)
//   6) 결과를 JSON 파일 2개(재고 스냅샷 / 전일 확정매출)로 저장 + 실행 로그 출력
//
// 실행 방법:
//   node erp-agent/daily-snapshot.js
//   (erp-agent/.env 에 ERP_USER, ERP_PASS, PRODUCT360_TOKEN_OBT 가 있어야 함)
//
// 주의: 이 스크립트는 ERP에 수천 번의 요청을 보냅니다. 동시성(CONCURRENCY)과
// 간격(REQUEST_DELAY_MS)을 너무 낮추지 마세요 — ERP 서버에 부담을 줄 수 있어요.

const fs = require("fs");
const path = require("path");
const https = require("https");
const querystring = require("querystring");

function loadEnvFile() {
  const envPath = path.join(__dirname, ".env");
  if (!fs.existsSync(envPath)) return;
  const lines = fs.readFileSync(envPath, "utf8").split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const idx = trimmed.indexOf("=");
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    if (!process.env[key]) process.env[key] = value;
  }
}
loadEnvFile();

const ERP_USER = process.env.ERP_USER;
const ERP_PASS = process.env.ERP_PASS;
const ERP_HOST = "gim.sgerp.com";
const COMP_CD = process.env.ERP_COMP_CD || "GI001";
const PRODUCT360_TOKEN = process.env.PRODUCT360_TOKEN_OBT;

// 오프라인으로 취급할 채널 그룹 (common/getGiCfCode.do, GBN_CD=SL008 기준)
// 2=로드샵, 3=백화점, 4=아울렛, 5=쇼핑몰
const OFFLINE_SHOP_GB = ["2", "3", "4", "5"];

const CONCURRENCY = Number(process.env.ERP_CONCURRENCY || 6); // 동시에 몇 개씩 호출할지
const REQUEST_DELAY_MS = Number(process.env.ERP_DELAY_MS || 50); // 각 배치 사이 살짝 쉬는 시간

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR", { timeZone: "Asia/Seoul" })}]`, ...args);
}

// MARK 6.69: SL4010(재고)/SL1010(매출) 응답에 사이즈 필드가 실제로 어떤 키 이름으로
// 오는지 확실치 않아서, 흔히 쓰이는 후보들을 순서대로 시도합니다. 아래 diagnostic 로그로
// 첫 실행 때 원본 필드를 확인하고, 후보에 없는 이름이면 이 배열에 추가해주세요.
const SIZE_FIELD_CANDIDATES = ["SIZE_NM", "SIZE_CD", "SZ_NM", "SZ_CD", "SIZE", "SIZE_NO"];
function extractSizeField(row) {
  for (const key of SIZE_FIELD_CANDIDATES) {
    const v = row?.[key];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim();
  }
  return "";
}
let stockDiagnosticLogged = false;
let salesDiagnosticLogged = false;

function todayKST(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  // en-CA 로케일은 YYYY-MM-DD 형식으로 나옴
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Seoul" }).format(d).replace(/-/g, "");
}

// ERP는 sale_dt 파라미터로 YYYYMMDD(하이픈 없음)를 쓰지만,
// MARK 업로드 API(/api/erp-daily-sales-import)는 YYYY-MM-DD(하이픈 있음)만 받음 — 변환 필요.
function toIsoDate(yyyymmdd) {
  return `${yyyymmdd.slice(0, 4)}-${yyyymmdd.slice(4, 6)}-${yyyymmdd.slice(6, 8)}`;
}

// ---------- 아주 작은 쿠키 저장소 (세션 유지용) ----------
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }
  update(setCookieHeaders) {
    if (!setCookieHeaders) return;
    for (const raw of setCookieHeaders) {
      const pair = raw.split(";")[0];
      const idx = pair.indexOf("=");
      if (idx === -1) continue;
      this.cookies.set(pair.slice(0, idx).trim(), pair.slice(idx + 1).trim());
    }
  }
  header() {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }
}

const jar = new CookieJar();

function erpRequest(pathName, formData) {
  return new Promise((resolve, reject) => {
    const body = querystring.stringify(formData);
    const headers = {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json, text/javascript, */*; q=0.01",
      "X-Requested-With": "XMLHttpRequest",
      "Content-Length": Buffer.byteLength(body),
      Cookie: jar.header(),
    };
    const req = https.request(
      { hostname: ERP_HOST, path: pathName, method: "POST", headers },
      (res) => {
        if (res.headers["set-cookie"]) jar.update(res.headers["set-cookie"]);
        let data = "";
        res.on("data", (c) => (data += c));
        res.on("end", () => {
          try {
            resolve(JSON.parse(data));
          } catch (err) {
            reject(new Error(`JSON 파싱 실패 (${pathName}): ${data.slice(0, 200)}`));
          }
        });
      }
    );
    req.on("error", reject);
    req.write(body);
    req.end();
  });
}

function httpsGetJson(hostname, pathName, headers) {
  return new Promise((resolve, reject) => {
    const req = https.request({ hostname, path: pathName, method: "GET", headers }, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => {
        try {
          resolve(JSON.parse(data));
        } catch (err) {
          reject(new Error(`JSON 파싱 실패 (${pathName}): ${data.slice(0, 200)}`));
        }
      });
    });
    req.on("error", reject);
    req.end();
  });
}

// ---------- 아주 작은 동시성 제한 실행기 ----------
async function runWithConcurrency(items, worker, concurrency) {
  const results = [];
  let idx = 0;
  async function runner() {
    while (idx < items.length) {
      const cur = idx++;
      try {
        results[cur] = await worker(items[cur], cur);
      } catch (err) {
        results[cur] = { error: err.message || String(err) };
      }
      if (REQUEST_DELAY_MS) await new Promise((r) => setTimeout(r, REQUEST_DELAY_MS));
    }
  }
  await Promise.all(Array.from({ length: concurrency }, runner));
  return results;
}

// ---------- 1) ERP 로그인 ----------
async function login() {
  log("ERP 로그인 중...");
  const res = await erpRequest("/login/loginChkGI.do", {
    COMP_ID: COMP_CD,
    EMPL_ID: ERP_USER,
    PASSWORD: ERP_PASS,
  });
  if (res.RESULT_CODE !== "SUCCESS") {
    throw new Error(`로그인 실패: ${JSON.stringify(res)}`);
  }
  log("로그인 성공.");
}

// ---------- 2) Product360에서 활성 스타일+컬러 조합 뽑기 (3안: 재고>0 전체) ----------
async function getActiveCombos() {
  log("Product360에서 상품 목록 가져오는 중...");
  const data = await httpsGetJson("gi-board.vercel.app", "/api/archive/product360", {
    "x-archive-token": PRODUCT360_TOKEN,
  });
  if (!data.products) throw new Error(`Product360 응답 이상: ${JSON.stringify(data).slice(0, 300)}`);

  const combos = [];
  const colorNameMap = new Map(); // styCd__colCd -> 컬러명 (Product360 기준, ERP 매출 응답엔 컬러명이 없어서 여기서 채움)
  for (const p of data.products) {
    if (!p.stockQty || p.stockQty <= 0) continue;
    const colorStock = new Map();
    const colorNames = new Map();
    for (const c of p.colors || []) {
      colorStock.set(c.color, (colorStock.get(c.color) || 0) + (c.stock || 0));
      if (c.colorName) colorNames.set(c.color, c.colorName);
    }
    for (const [color, stock] of colorStock) {
      if (stock > 0) {
        combos.push({ styCd: p.code, colCd: color, styNm: p.name });
        colorNameMap.set(`${p.code}__${color}`, colorNames.get(color) || color);
      }
    }
  }
  log(`활성 스타일+컬러 조합 ${combos.length}개 (품번 ${data.products.length}개 중 재고>0 필터링 후)`);
  return { combos, colorNameMap };
}

// MARK 6.74: SHOP_GB 2~5로만 걸러도 "오프라인_송도"처럼 실제 관리 대상이 아닌 위탁/특수
// 채널까지 같이 딸려옵니다. lib/dataBuilder.ts의 isCoreOfflineSalesStore()와 같은 규칙을
// 그대로 옮겨서, 진짜 매장만 남깁니다 (erp-core.js의 동일 함수와 같은 로직).
function isCoreOfflineStoreName(storeName) {
  const raw = String(storeName || "").trim();
  const lower = raw.toLowerCase();
  if (!raw || raw === "합계" || raw === "채널명") return false;
  if (
    lower.startsWith("온라인") || lower.includes("29cm") || lower.includes("ssf") ||
    lower.includes("네이버") || lower.includes("지그재그") || lower.includes("w컨셉") ||
    lower.includes("wconcept") || lower.includes("eql") || lower.includes("한섬")
  ) return false;
  if (
    raw.includes("포시즌") || raw.startsWith("글로벌_") || raw.startsWith("기타_") ||
    lower.startsWith("global_") || lower.startsWith("etc_") || raw === "기타" ||
    raw.startsWith("기타") || raw.includes("글로벌")
  ) return false;
  if (
    raw.startsWith("오프라인_") || lower.includes("위탁") || lower.includes("면세") ||
    lower.includes("한컬렉션") || lower.includes("han collection") ||
    lower.includes("hancollection") || lower.includes("무신사")
  ) return false;
  return true;
}

// ---------- 3) 오프라인 매장 목록 ----------
async function getOfflineShops() {
  log("매장 목록 가져오는 중...");
  const res = await erpRequest("/GI/SL/SL1010/getMainShopList.do", {
    comp_cd: COMP_CD,
    sale_dt: todayKST(),
    day_div: "2",
    shop_gb: "",
    shop_tp: "",
  });
  if (res.RESULT_CODE !== "SUCCESS") throw new Error(`매장 목록 조회 실패: ${JSON.stringify(res)}`);

  const byShopGb = res.RESULT_DATA.filter((s) => OFFLINE_SHOP_GB.includes(String(s.SHOP_GB)));
  const offline = byShopGb.filter((s) => isCoreOfflineStoreName(s.SHOP_NM));
  log(`오프라인 매장 ${offline.length}개 확인됨. (SHOP_GB 기준 ${byShopGb.length}개 중 위탁/특수채널 ${byShopGb.length - offline.length}개 제외)`);
  return offline; // { SHOP_CD, SHOP_NM, SHOP_GB, ... }
}

// MARK 6.70: SL4010(재고) 응답의 SIZE_1~SIZE_18은 사이즈명이 아니라 "전사 사이즈코드를
// 알파벳순으로 정렬했을 때의 자리 번호"인 것으로 실측 확인됐습니다 (2026-08-04, 소천님이
// PC ERP "Style 채널별 재고현황" 화면과 대조).
//   - GF1LPT501/BK/성수·한남 플래그십: 실제 S=1,M=10,L=6,XL=3개인데 API는
//     SIZE_2=6(L), SIZE_3=10(M), SIZE_4=1(S), SIZE_5=3(XL) → L<M<S<XL 알파벳순과 일치.
//   - GF2UCP103(캡, F사이즈 전용): API가 SIZE_1에만 값이 들어있고 나머지는 전부 null
//     → 슬롯1=F 확정.
// 슬롯 1~5(F,L,M,S,XL)는 실측 확인 완료 — 대부분의 상품은 이걸로 커버됩니다.
// 슬롯 6 이후(신발 사이즈 등, 숫자라서 알파벳 정렬 규칙이 그대로 이어질지 불확실)는
// 아직 실측 데이터가 없어서 맵에 안 넣어뒀습니다. 그런 값이 나오면 추측해서 이름
// 붙이지 않고 "??"로 표시해서, 눈에 띄면 그때 실측해서 채워넣는 방식으로 갑니다.
const SIZE_SLOT_MAP = {
  1: "F", // 실측 확인 (GF2UCP103)
  2: "L", // 실측 확인 (성수/한남 플래그십)
  3: "M", // 실측 확인
  4: "S", // 실측 확인 (2개 매장)
  5: "XL", // 실측 확인
  // 6 이후는 일부러 비워둠 — unpivotSizeRow가 "??"로 표시
};

// SIZE_1~SIZE_18로 넓게 펼쳐진(pivot) 한 행을, 사이즈별 낱개 행(long format)으로 풀어줍니다.
function unpivotSizeRow(row) {
  const out = [];
  for (let i = 1; i <= 18; i++) {
    const raw = row[`SIZE_${i}`];
    if (raw === null || raw === undefined || raw === "") continue;
    const qty = Number(raw);
    if (!Number.isFinite(qty)) continue;
    out.push({ size: SIZE_SLOT_MAP[i] || "??", qty });
  }
  return out;
}

// ---------- 4) 재고 스냅샷 (SL4010) ----------
async function fetchStockSnapshot(combos) {
  log(`재고 조회 시작: 조합 ${combos.length}개 x 채널 ${OFFLINE_SHOP_GB.length}개 = 총 ${combos.length * OFFLINE_SHOP_GB.length}회 호출`);
  const jobs = [];
  for (const combo of combos) {
    for (const shopGb of OFFLINE_SHOP_GB) {
      jobs.push({ ...combo, shopGb });
    }
  }

  let done = 0;
  const startedAt = Date.now();
  const results = await runWithConcurrency(
    jobs,
    async (job) => {
      const res = await erpRequest("/GI/SL/SL4010/getMainList2.do", {
        comp_cd: COMP_CD,
        sty_cd: job.styCd,
        col_cd: job.colCd,
        shop_gb: job.shopGb,
      });
      done++;
      if (done % 500 === 0) log(`  ...진행 ${done}/${jobs.length}`);
      if (res.RESULT_CODE !== "SUCCESS") return [];
      if (!stockDiagnosticLogged && (res.RESULT_DATA || []).length) {
        stockDiagnosticLogged = true;
        log("🔍 [진단] SL4010 재고 응답 원본 필드:", JSON.stringify(res.RESULT_DATA[0]));
      }
      return (res.RESULT_DATA || []).flatMap((row) => {
        const sizes = unpivotSizeRow(row);
        const base = { styCd: job.styCd, styNm: job.styNm, colCd: job.colCd, shopCd: row.SHOP_CD, shopNm: row.SHOP_NM };
        if (!sizes.length) {
          // SIZE_1~18이 전부 비어있으면(드문 케이스) 컬러 단위로만 반영
          return [{ ...base, size: "", totQty: Number(row.TOT_QTY || 0) }];
        }
        return sizes.map((s) => ({ ...base, size: s.size, totQty: s.qty }));
      });
    },
    CONCURRENCY
  );

  const flat = results.flat().filter((r) => r && !r.error);
  const durationSec = ((Date.now() - startedAt) / 1000).toFixed(1);
  log(`재고 조회 완료. ${flat.length}건 수집, ${durationSec}초 소요.`);
  return flat;
}

// ---------- 5) 전일 매출 확정 (SL1010) — 스타일+컬러 단위로 합산 ----------
async function fetchFinalizedSalesYesterday(offlineShops) {
  const yDate = todayKST(-1);
  log(`전일(${yDate}) 매출 확정 조회 시작: 오프라인 매장 ${offlineShops.length}개`);

  const results = await runWithConcurrency(
    offlineShops,
    async (shop) => {
      const res = await erpRequest("/GI/SL/SL1010/getMainDetailList.do", {
        comp_cd: COMP_CD,
        sale_dt: yDate,
        shop_cd: shop.SHOP_CD,
      });
      if (res.RESULT_CODE !== "SUCCESS") return [];
      if (!salesDiagnosticLogged && (res.RESULT_DATA || []).length) {
        salesDiagnosticLogged = true;
        log("🔍 [진단] SL1010 매출 응답 원본 필드 (사이즈 필드명 확인용):", JSON.stringify(res.RESULT_DATA[0]));
      }

      // MARK 6.69: 이전엔 스타일+컬러 단위로 합산해서 재고 쪽과 granularity를 맞췄는데,
      // 이제 재고 쪽도 사이즈를 살리기로 해서 매출도 스타일+컬러+사이즈 단위로 합산합니다.
      const agg = new Map(); // key: styCd__colCd__size
      for (const row of res.RESULT_DATA || []) {
        const size = extractSizeField(row);
        const key = `${row.STY_CD}__${row.COL_CD}__${size}`;
        if (!agg.has(key)) {
          agg.set(key, {
            shopCd: shop.SHOP_CD,
            shopNm: shop.SHOP_NM,
            styCd: row.STY_CD,
            styNm: row.STY_NM,
            colCd: row.COL_CD,
            colNm: row.COL_CD, // ERP가 컬러명을 따로 안 주면 코드로 대체 (필요시 나중에 매핑 보강)
            size,
            qty: 0,
            amount: 0,
          });
        }
        const bucket = agg.get(key);
        bucket.qty += Number(row.SALES_QTY || 0);
        bucket.amount += Number(row.SALES_TAMT || 0);
      }
      return Array.from(agg.values());
    },
    CONCURRENCY
  );

  const flat = results.flat().filter((r) => r && !r.error);
  log(`전일 매출 확정 조회 완료. ${flat.length}건 수집 (스타일+컬러 단위 합산).`);
  return { date: yDate, records: flat };
}

// ---------- 6) 재고 + 매출을 (매장, 스타일, 컬러) 키로 병합 ----------
// MARK 업로드 API(/api/erp-daily-sales-import)는 그 날짜의 기존 행을 통째로 교체하므로,
// 매출만 올리면 stock이 0으로 덮어써짐. 반드시 재고를 같이 합쳐서 완성된 행으로 만들어야 함.
function mergeStockAndSales(stockSnapshot, finalizedSales, colorNameMap) {
  const isoDate = toIsoDate(finalizedSales.date);
  const mergeRunAt = new Date().toISOString();

  // MARK 6.69: 사이즈를 키에 포함시켜서 컬러 단위로 뭉개지지 않게 합니다.
  // 재고와 매출을 "합집합"으로 병합 — 매출이 0건이라도 재고가 있으면 반드시 행이 생기도록
  const rows = new Map(); // key: shopCd__styCd__colCd__size

  function ensureRow(shopCd, shopNm, styCd, styNm, colCd, size) {
    const key = `${shopCd}__${styCd}__${colCd}__${size || ""}`;
    if (!rows.has(key)) {
      rows.set(key, {
        date: isoDate,
        storeName: shopNm, // 업로드 API는 매장 "이름" 문자열을 기대함 (shop_cd 아님)
        styleCode: styCd,
        productName: styNm || "",
        colorCode: colCd,
        colorName: colorNameMap.get(`${styCd}__${colCd}`) || colCd, // Product360 기준 실제 컬러명
        size: size || "", // ERP 응답에 사이즈 필드가 안 잡히면 빈 값 — store-stock-lookup이
        // looksLikeRealSize()로 걸러서 컬러 단위로만 취급하니 안전함
        qty: 0,
        amount: 0,
        stock: 0,
        stockUpdatedAt: mergeRunAt, // MARK 6.72: 재고 갱신 시각 (화면에 "마지막 갱신" 표시용)
      });
    }
    return rows.get(key);
  }

  // 1) 재고 스냅샷 먼저 전부 반영 (매출 유무와 무관하게 재고 있는 조합은 다 행을 가짐)
  for (const s of stockSnapshot) {
    const row = ensureRow(s.shopCd, s.shopNm, s.styCd, s.styNm, s.colCd, s.size);
    row.stock += s.totQty;
  }

  // 2) 매출을 얹음 (재고 스냅샷에 없던 조합이면 새 행이 생기고, stock은 0으로 남음 —
  //    ERP가 재고 0인 매장/조합은 응답에서 아예 생략하는 경우와 일치하는 정상 케이스)
  for (const r of finalizedSales.records) {
    const row = ensureRow(r.shopCd, r.shopNm, r.styCd, r.styNm, r.colCd, r.size);
    row.qty += r.qty;
    row.amount += r.amount;
    if (!row.productName) row.productName = r.styNm || "";
  }

  const merged = Array.from(rows.values());
  const stockOnlyCount = merged.filter((m) => m.qty === 0 && m.amount === 0).length;
  const salesOnlyNoStockCount = merged.filter((m) => m.stock === 0 && (m.qty !== 0 || m.amount !== 0)).length;
  log(
    `병합 완료: 총 ${merged.length}건 (매출 0·재고만 있는 행 ${stockOnlyCount}건 포함, ` +
      `매출은 있는데 재고 매칭 안 된 행 ${salesOnlyNoStockCount}건 — 대부분 마지막 재고가 그날 팔린 정상 케이스로 추정)`
  );

  return merged;
}

async function main() {
  if (!ERP_USER || !ERP_PASS) {
    console.error("ERP_USER / ERP_PASS가 .env에 없습니다.");
    process.exit(1);
  }
  if (!PRODUCT360_TOKEN) {
    console.error("PRODUCT360_TOKEN_OBT가 .env에 없습니다.");
    process.exit(1);
  }

  const overallStart = Date.now();
  try {
    await login();
    const [{ combos, colorNameMap }, offlineShops] = await Promise.all([getActiveCombos(), getOfflineShops()]);

    const stockSnapshot = await fetchStockSnapshot(combos);
    const finalizedSales = await fetchFinalizedSalesYesterday(offlineShops);
    const mergedRows = mergeStockAndSales(stockSnapshot, finalizedSales, colorNameMap);

    const todayStr = todayKST();
    const stockPath = path.join(__dirname, `stock-snapshot-${todayStr}.json`);
    const mergedPath = path.join(__dirname, `merged-daily-rows-${finalizedSales.date}.json`);

    fs.writeFileSync(
      stockPath,
      JSON.stringify(
        { generatedAt: new Date().toISOString(), comboCount: combos.length, rowCount: stockSnapshot.length, data: stockSnapshot },
        null,
        2
      )
    );
    // 이 파일이 바로 /api/erp-daily-sales-import 로 보낼 { date, rows } 형태 (parse-and-upload.js와 동일한 계약)
    fs.writeFileSync(mergedPath, JSON.stringify({ date: mergedRows[0]?.date || toIsoDate(finalizedSales.date), rows: mergedRows }, null, 2));

    const totalSec = ((Date.now() - overallStart) / 1000).toFixed(1);
    log(`✅ 전체 완료 (${totalSec}초).`);
    log(`재고 스냅샷 저장 (참고용): ${stockPath}`);
    log(`병합된 업로드용 데이터 저장: ${mergedPath}`);
    log(`(아직 MARK로 실제 업로드는 안 함 — 파일 확인 후 다음 단계에서 업로드 로직 붙일 예정)`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
