// 인샵매출 통합 스크립트 — 한컬렉션 + 롯데면세 둘 다 완전자동으로 조회해서
// 하나의 업로드 포맷("일자/POS/채널/바코드/수량/단가")으로 합쳐서 바탕화면에 저장합니다.
// (무신사는 OTP 때문에 나중에 — 지금은 한컬렉션+롯데면세만)
//
// 채널코드는 MARK 6.8 당시 코드에 있던 값을 그대로 씁니다:
//   한컬렉션 = 81026, 롯데면세점 = 81028
//
// 준비물(.env):
//   HANKOL_USER_ID=v00011
//   HANKOL_PASSWORD=실제비밀번호
//   LOTTE_DFS_USER_ID=400125218532
//   LOTTE_DFS_PASSWORD=실제비밀번호
//
// 설치(처음 한 번만):
//   npm install puppeteer xlsx dotenv
//
// 실행:
//   node build-inshop-upload.js 20260819
//   (날짜 생략하면 어제 하루치)
//
// 결과: 바탕화면에 "인샵매출20260819(면세,한컬).xlsx" 같은 이름으로 저장됩니다.
// (어느 한쪽이 실패하면 성공한 채널 이름만 괄호 안에 들어갑니다)

const https = require("https");
const puppeteer = require("puppeteer");
const path = require("path");
const os = require("os");
const fs = require("fs");
require("dotenv").config();

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

const CHANNEL_CODE = {
  hancollection: "81026",
  lotte: "81028",
};

// MARK: COLORCODE 시트(칼라코드↔칼라명, 81개)를 그대로 가져왔습니다 — S/W로 시작하는 구품번의
// 사이즈+컬러 순서가 뒤집힌 경우를 검증할 때 씁니다.
const COLOR_CODES = new Set([
  "AK","CR","GN","MG","BK","BR","NA","BE","GR","BL","CH","NV","WH","MI","DB","LB","SB","IV",
  "LK","LG","KH","ER","RE","ME","BT","PI","PC","AP","DN","TP","CA","BC","ID","SI","LE","MO",
  "BU","DG","OA","PM","OB","TG","DE","PU","DR","CS","OL","VI","LI","LA","LY","BP","MD","SM",
  "TO","RO","YE","WI","AV","CC","PP","WL","WR","WT","LD","ST","MU","SD","PE","PL","CK","CO",
  "VC","MT","OR","WC","PR","PK","YL",
]);
const SIZE_CODES = ["XXL", "XL", "XS", "S", "M", "L", "F"]; // 긴 것부터 확인해야 오매칭 안 남

// MARK: 한컬렉션 원본에 칼라명이 코드 대신 풀네임으로 잘못 들어간 경우가 있어요
// (예: GF1UJK009BLACKL — "BLACK"이 코드 "BK" 대신 그대로 들어감). COLORCODE 시트
// (81개, 코드+이름) 그대로 가져와서, 풀네임을 찾아 코드로 바꿔주는 예전 MARK 6.13
// tryAutoFixBarcode() 로직을 재현합니다. 긴 이름부터 확인해야 "WHITE"가 "WHITE TOMATO"
// 안에서 먼저 오매칭되는 걸 피할 수 있어요.
const COLOR_NAME_TO_CODE = [
  ["ASH KHAKI", "AK"], ["CREAM", "CR"], ["GREEN", "GN"], ["MELANGE GRAY", "MG"], ["BLACK", "BK"],
  ["BROWN", "BR"], ["NAVY", "NA"], ["BEIGE", "BE"], ["GREY", "GR"], ["BLUE", "BL"], ["CHARCOAL", "CH"],
  ["WHITE", "WH"], ["MINT", "MI"], ["DEEP BLUE", "DB"], ["LIGHT BLUE", "LB"], ["SKY BLUE", "SB"],
  ["IVORY", "IV"], ["LIGHT KHAKI", "LK"], ["LIGHT GREY", "LG"], ["KHAKI", "KH"], ["ECRU", "ER"],
  ["RED", "RE"], ["MELON", "ME"], ["BUTTER", "BT"], ["PINK", "PI"], ["PISTACHIO", "PC"],
  ["ASH PINK", "AP"], ["DARK NAVY", "DN"], ["TAUPE", "TP"], ["CAMEL", "CA"], ["BRICK", "BC"],
  ["INDIGO", "ID"], ["SILVER", "SI"], ["LEMON", "LE"], ["MOCHA", "MO"], ["BURGUNDY", "BU"],
  ["DEEP GREEN", "DG"], ["OATMEAL", "OA"], ["PUMPKIN", "PM"], ["OCEAN BLUE", "OB"], ["TEAL GREEN", "TG"],
  ["DARK BEIGE", "DE"], ["PURPLE", "PU"], ["DARK BROWN", "DR"], ["CHARCOAL STRIPE", "CS"], ["OLIVE", "OL"],
  ["VIOLET", "VI"], ["LIME", "LI"], ["LAVENDER", "LA"], ["LIGHT YELLOW", "LY"], ["BLOSSOM PINK", "BP"],
  ["MUD", "MD"], ["SAGE MINT", "SM"], ["TOMATO", "TO"], ["ROSE", "RO"], ["YELLOW", "YE"], ["WINE", "WI"],
  ["AVOCADO", "AV"], ["COCOA", "CC"], ["PITCH PINK", "PP"], ["WHITE LEMON", "WL"], ["WHITE CHERRY", "WR"],
  ["WHITE TOMATO", "WT"], ["LEOPARD", "LD"], ["STRIPE", "ST"], ["MUSTARD", "MU"], ["SAND", "SD"],
  ["PEACH", "PE"], ["PLUM", "PL"], ["CHECK", "CK"], ["COMBI", "CO"], ["VINTAGE CHARCOAL", "VC"],
  ["MULTI", "MT"], ["ORANGE", "OR"], ["WHITE COMBI", "WC"], ["PINK CHERRY", "PR"], ["LIGHT GREEN", "LG"],
]
  .map(([name, code]) => ({ name, code }))
  .sort((a, b) => b.name.length - a.name.length); // 긴 이름 먼저 매칭

function fixFullColorNameToCode(barcode) {
  const upper = barcode.toUpperCase();
  for (const { name, code } of COLOR_NAME_TO_CODE) {
    const idx = upper.indexOf(name);
    if (idx >= 0) {
      const fixed = barcode.slice(0, idx) + code + barcode.slice(idx + name.length);
      return { fixed, changed: true, matchedName: name };
    }
  }
  return { fixed: barcode, changed: false };
}

// MARK: S/W로 시작하는 구품번체계는 스타일코드(10자 고정) 뒤에 [사이즈][컬러] 순서로 붙는데,
// 한컬렉션 쪽 데이터에 가끔 [컬러][사이즈]로 뒤집혀서 들어오는 경우가 있어서(예:
// WBD2L43545BKXL_G5 → 원래는 WBD2L43545XLBK 이어야 함) 업로드가 안 됩니다.
// 컬러코드 목록으로 "진짜 컬러가 어디 붙어있는지" 검증해서 뒤집힌 것만 바로잡습니다.
function fixOldStyleSizeColorOrder(barcode) {
  if (!(barcode.startsWith("S") || barcode.startsWith("W"))) return { fixed: barcode, changed: false };
  if (barcode.length < 12) return { fixed: barcode, changed: false };
  const style = barcode.slice(0, 10);
  const suffix = barcode.slice(10);

  // 이미 [사이즈][컬러] 순서로 정상이면 그대로 둡니다.
  for (const size of SIZE_CODES) {
    if (suffix.startsWith(size)) {
      const remainder = suffix.slice(size.length);
      if (COLOR_CODES.has(remainder)) return { fixed: barcode, changed: false };
    }
  }
  // [컬러][사이즈]로 뒤집힌 경우를 찾아서 [사이즈][컬러]로 바로잡습니다.
  for (const size of SIZE_CODES) {
    if (suffix.endsWith(size)) {
      const remainder = suffix.slice(0, suffix.length - size.length);
      if (COLOR_CODES.has(remainder)) return { fixed: style + size + remainder, changed: true };
    }
  }
  return { fixed: barcode, changed: false };
}

// MARK: 무신사는 한컬렉션/롯데면세와 다르게 매장마다 채널코드가 달라서, MARK 6.8 당시
// consignmentUpload.ts에 있던 매핑표(FALLBACK_STORE_CODES)를 그대로 가져왔습니다.
// 목록에 없는 매장이 나오면 채널코드를 비워두고 "확인필요"로 표시합니다.
const MUSINSA_STORE_CODES = {
  "무신사 스토어 성수": "81008",
  "무신사 스토어 강남": "81027",
  "무신사 스토어 홍대": "81009",
  "무신사 아울렛 & 유즈드 롯데몰 은평점": "81033",
  "무신사 스토어 대구": "86001",
  "무신사 스토어 AK플라자 수원점": "92001",
  "무신사 백 & 캡클럽 서울숲": "91001",
  "무신사 스토어 트리플스트리트 송도점": "92002",
};

function xmlUnescape(s) {
  return String(s ?? "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function parseSalesRows(xmlText) {
  const rows = [];
  const rowMatches = xmlText.match(/<Row>[\s\S]*?<\/Row>/g) || [];
  for (const rowXml of rowMatches) {
    const row = {};
    const colMatches = rowXml.matchAll(/<Col id="([^"]+)">([^<]*)<\/Col>/g);
    for (const m of colMatches) row[m[1]] = xmlUnescape(m[2]);
    if (Object.keys(row).length) rows.push(row);
  }
  return rows;
}

async function waitMs(ms) {
  await new Promise((r) => setTimeout(r, ms));
}

// =========================================================
// 한컬렉션 (완전 자동)
// =========================================================
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }
  update(setCookieHeaders) {
    if (!setCookieHeaders) return;
    const arr = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
    for (const raw of arr) {
      const first = raw.split(";")[0];
      const eq = first.indexOf("=");
      if (eq < 0) continue;
      this.cookies.set(first.slice(0, eq).trim(), first.slice(eq + 1).trim());
    }
  }
  header() {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }
}

function httpsRequest(host, port, method, urlPath, body, extraHeaders, jar, bearerToken) {
  return new Promise((resolve, reject) => {
    const bodyBuf = body ? Buffer.from(body, "utf8") : null;
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
      "Accept-Encoding": "identity",
      Cookie: jar.header(),
      ...extraHeaders,
    };
    if (bearerToken) headers["Authorization"] = `bearer ${bearerToken}`;
    if (bodyBuf) headers["Content-Length"] = bodyBuf.length;

    const req = https.request({ host, port, path: urlPath, method, headers }, (res) => {
      jar.update(res.headers["set-cookie"]);
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () =>
        resolve({ status: res.statusCode, body: Buffer.concat(chunks).toString("utf8"), location: res.headers["location"] || null })
      );
    });
    req.on("error", reject);
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

function makeWebId() {
  return Math.floor(Math.random() * 4294967296) - 2147483648;
}

async function fetchHancollection(fromDate, toDate) {
  const USER_ID = process.env.HANKOL_USER_ID;
  const PASSWORD = process.env.HANKOL_PASSWORD;
  if (!USER_ID || !PASSWORD) {
    log("⚠ HANKOL_USER_ID/HANKOL_PASSWORD가 없어서 한컬렉션은 건너뜁니다.");
    return [];
  }

  const jar = new CookieJar();
  const HOST = "dtir.good-md.com";
  const PORT = 5180;

  // MARK: 새벽 스케줄 실행 중 302 리다이렉트 응답을 받는 일시적 문제가 있었어요(낮에는
  // 잘 되던 게 밤에만 그럼 — 야간 서버 점검/세션 초기화 등으로 추정). 최대 3번까지
  // 재시도하도록 만들었고, 실패 시 실제 상태코드/응답을 자세히 로그로 남깁니다.
  let loginRes;
  let webId;
  let lastErr;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      log(`[한컬렉션] 로그인 중... (시도 ${attempt}/3)`);
      await httpsRequest(HOST, PORT, "GET", "/fashion/index.html", null, {}, jar);
      webId = makeWebId();
      const loginBody = `SSV:utf-8\x1e_xm_webid_1_=${webId}\x1ecom_cd=DTIR\x1euser_id=${USER_ID}\x1epasswd=${PASSWORD}\x1elocale=ko_KR\x1eisDevLogin=true\x1e`;
      loginRes = await httpsRequest(HOST, PORT, "POST", "/oauth/bridge", loginBody, { "Content-Type": "text/plain;charset=utf-8" }, jar);

      log(`🔍 [진단] [한컬렉션] 로그인 응답 status=${loginRes.status}${loginRes.location ? `, 리다이렉트 위치=${loginRes.location}` : ""}`);
      const errorCodeMatch = loginRes.body.match(/ErrorCode:int=(-?\d+)/);
      if (!errorCodeMatch || Number(errorCodeMatch[1]) !== 0) {
        throw new Error(`status=${loginRes.status}: ${loginRes.body.slice(0, 300)}`);
      }
      lastErr = null;
      break; // 성공
    } catch (err) {
      lastErr = err;
      log(`⚠ [한컬렉션] 로그인 시도 ${attempt}번째 실패: ${err.message}`);
      if (attempt < 3) {
        log("[한컬렉션] 10초 후 재시도합니다...");
        await waitMs(10000);
      }
    }
  }
  if (lastErr) throw new Error(`[한컬렉션] 로그인 실패(3번 재시도 후에도 실패): ${lastErr.message}`);

  const tokenIdx = loginRes.body.indexOf("accessToken");
  const afterToken = tokenIdx >= 0 ? loginRes.body.slice(tokenIdx) : "";
  const tokenMatch = afterToken.match(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/i);
  const bearerToken = tokenMatch ? tokenMatch[0] : null;
  log("[한컬렉션] 로그인 성공.");

  log(`[한컬렉션] 매출 조회 중: ${fromDate} ~ ${toDate}`);
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Root xmlns="http://www.nexacroplatform.com/platform/dataset">
	<Parameters>
		<Parameter id="_xm_webid_1_">${webId}</Parameter>
		<Parameter id="class">fs.service.sale.Sale_05</Parameter>
		<Parameter id="method">listSale</Parameter>
	</Parameters>
	<Dataset id="DS_COND">
		<ColumnInfo>
			<Column id="from_date" type="STRING" size="256"  />
			<Column id="to_date" type="STRING" size="256"  />
			<Column id="grp_cd" type="STRING" size="256"  />
			<Column id="sto_cd" type="STRING" size="256"  />
			<Column id="sale_gbn" type="STRING" size="256"  />
			<Column id="ret_gbn" type="STRING" size="256"  />
			<Column id="s_manager" type="STRING" size="256"  />
		</ColumnInfo>
		<Rows>
			<Row>
				<Col id="from_date">${fromDate}</Col>
				<Col id="to_date">${toDate}</Col>
				<Col id="grp_cd" />
				<Col id="sto_cd" />
				<Col id="sale_gbn" />
				<Col id="ret_gbn">3</Col>
				<Col id="s_manager" />
			</Row>
		</Rows>
	</Dataset>
</Root>`;

  const res = await httpsRequest(
    HOST,
    PORT,
    "POST",
    "/fashionsvr/service",
    xml,
    { "Content-Type": "text/xml", Accept: "application/xml, text/xml, */*", "X-Requested-With": "XMLHttpRequest" },
    jar,
    bearerToken
  );

  const qErrMatch = res.body.match(/ErrorCode"\s+type="int">(-?\d+)</);
  const qErrCode = qErrMatch ? Number(qErrMatch[1]) : null;
  if (qErrCode !== 0) throw new Error(`[한컬렉션] 조회 실패: ${res.body.slice(0, 500)}`);

  const raw = parseSalesRows(res.body);
  log(`[한컬렉션] ${raw.length}건 조회됨.`);

  // MARK: 실제 확인된 필드 매핑 — gds_cd2가 원본 파일 K열(매입거래처상품코드)과 정확히 일치함(_뒤 접미사 포함).
  let orderFixedCount = 0;
  let colorNameFixedCount = 0;
  const mapped = raw
    .map((r) => {
      let barcode = String(r.gds_cd2 || "").trim();
      if (barcode.includes("_")) barcode = barcode.split("_")[0];

      // 1) 칼라명이 코드 대신 풀네임으로 들어간 경우 자동 수정 (예: BLACK → BK)
      if (barcode.length >= 13) {
        const { fixed, changed } = fixFullColorNameToCode(barcode);
        if (changed) {
          colorNameFixedCount++;
          barcode = fixed;
        }
      }

      // 2) S/W로 시작하는 구품번의 사이즈+컬러 순서가 뒤집힌 경우 자동 수정
      const { fixed: fixedOrder, changed: orderChanged } = fixOldStyleSizeColorOrder(barcode);
      if (orderChanged) {
        orderFixedCount++;
        barcode = fixedOrder;
      }

      return {
        date: r.sale_date || fromDate,
        pos: "P1",
        channel: CHANNEL_CODE.hancollection,
        barcode,
        qty: Number(r.sale_cnt || 0),
        price: Number(r.cur_price || r.real_amt || 0),
        flagged: barcode.length >= 15,
        source: "한컬렉션",
      };
    })
    .filter((r) => r.barcode);

  if (colorNameFixedCount) log(`[한컬렉션] 칼라명이 풀네임으로 들어가있던 ${colorNameFixedCount}건을 코드로 자동 수정했어요.`);
  if (orderFixedCount) log(`[한컬렉션] 사이즈/컬러 순서가 뒤집혀있던 ${orderFixedCount}건을 자동으로 바로잡았어요.`);
  return mapped;
}

// =========================================================
// 롯데면세 (완전 자동 — 로그인/메뉴/날짜/조회 전부 자동 클릭+타이핑)
// =========================================================
async function clickById(page, id) {
  const clicked = await page.evaluate((id) => {
    const el = document.getElementById(id);
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: window, clientX: rect.x + rect.width / 2, clientY: rect.y + rect.height / 2 };
    el.dispatchEvent(new MouseEvent("mouseover", opts));
    el.dispatchEvent(new MouseEvent("mouseenter", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.dispatchEvent(new MouseEvent("click", opts));
    return true;
  }, id);
  if (!clicked) throw new Error(`요소를 못 찾았어요: ${id}`);
}

async function typeIntoById(page, id, text) {
  const handle = await page.evaluateHandle((id) => document.getElementById(id), id);
  const el = handle.asElement();
  if (!el) throw new Error(`입력칸을 못 찾았어요: ${id}`);
  await el.click({ clickCount: 3 });
  await page.keyboard.type(text, { delay: 30 });
  await handle.dispose();
}

async function typeDateRobustly(page, id, digits, expectedDash) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    const handle = await page.evaluateHandle((id) => document.getElementById(id), id);
    const el = handle.asElement();
    if (!el) throw new Error(`날짜 입력칸을 못 찾았어요: ${id}`);
    await el.click();
    await page.keyboard.down("Control");
    await page.keyboard.press("KeyA");
    await page.keyboard.up("Control");
    for (let i = 0; i < 12; i++) await page.keyboard.press("Backspace");
    await waitMs(150);
    for (const ch of digits) {
      await page.keyboard.type(ch, { delay: 0 });
      await waitMs(80);
    }
    await page.keyboard.press("Tab");
    await waitMs(300);
    await handle.dispose();

    const value = await page.evaluate((id) => document.getElementById(id)?.value, id);
    if (String(value).includes(expectedDash)) return value;
    log(`⚠ 날짜 입력 시도 ${attempt}번째 실패(값=${value}) — 다시 시도합니다.`);
  }
  throw new Error(`날짜(${expectedDash})를 3번 시도해도 제대로 못 넣었어요.`);
}

async function findInputIdBySuffix(page, suffix) {
  return page.evaluate((suffix) => {
    const el = Array.from(document.querySelectorAll("input")).find((e) => e.id.endsWith(suffix));
    return el ? el.id : null;
  }, suffix);
}

async function selectComboOption(page, comboInputId, optionText) {
  await clickById(page, comboInputId);
  await waitMs(600);
  const optionId = await page.evaluate((optionText) => {
    const all = document.querySelectorAll("div, span, li");
    for (const el of all) {
      const ownText = Array.from(el.childNodes)
        .filter((n) => n.nodeType === 3)
        .map((n) => n.textContent.trim())
        .join("")
        .trim();
      if (ownText === optionText && el.offsetWidth > 0 && el.offsetHeight > 0) return el.id || null;
    }
    return null;
  }, optionText);
  if (!optionId) throw new Error(`콤보박스에서 "${optionText}" 항목을 못 찾았어요 (입력칸: ${comboInputId})`);
  await clickById(page, optionId);
  await waitMs(400);
}

async function fetchLotte(fromDate, toDate) {
  const USER_ID = process.env.LOTTE_DFS_USER_ID;
  const PASSWORD = process.env.LOTTE_DFS_PASSWORD;
  if (!USER_ID || !PASSWORD) {
    log("⚠ LOTTE_DFS_USER_ID/LOTTE_DFS_PASSWORD가 없어서 롯데면세는 건너뜁니다.");
    return [];
  }
  const BASE = "https://srm.lottedfs.co.kr";
  const fromDateDash = `${fromDate.slice(0, 4)}-${fromDate.slice(4, 6)}-${fromDate.slice(6, 8)}`;
  const toDateDash = `${toDate.slice(0, 4)}-${toDate.slice(4, 6)}-${toDate.slice(6, 8)}`;

  log("[롯데면세] 브라우저 여는 중...");
  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  const client = await page.target().createCDPSession();
  await client.send("Network.enable");
  let capturedRows = null;
  const pending = new Map();
  client.on("Network.requestWillBeSent", (params) => {
    if (params.request.url.includes("SrmSalesStckInqryController/inqrySrmSalesStck")) {
      pending.set(params.requestId, true);
    }
  });
  client.on("Network.loadingFinished", (params) => {
    if (!pending.has(params.requestId)) return;
    pending.delete(params.requestId);
    (async () => {
      try {
        const body = await client.send("Network.getResponseBody", { requestId: params.requestId });
        const text = body.base64Encoded ? Buffer.from(body.body, "base64").toString("utf8") : body.body;
        const rows = parseSalesRows(text);
        if (rows.length) {
          capturedRows = rows;
          log(`[롯데면세] 조회 결과 감지: ${rows.length}건`);
        }
      } catch (err) {
        log(`⚠ [롯데면세] 결과 처리 중 오류: ${err.message || err}`);
      }
    })();
  });

  try {
    log("[롯데면세] 페이지 초기화 중...");
    await page.goto(`${BASE}/ui/ldfs_ui/index.html`, { waitUntil: "networkidle2" });
    await waitMs(2000);

    log("[롯데면세] 아이디/비밀번호 입력 중...");
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userId:input", USER_ID);
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userPwd:input", PASSWORD);
    log("[롯데면세] 로그인 시도 중 (Enter)...");
    await page.keyboard.press("Enter");
    await waitMs(4000);

    log("[롯데면세] 환영 패널 닫는 중(있으면)...");
    const closeBtnId = await page.evaluate(() => {
      const all = document.querySelectorAll("div, span");
      for (const el of all) {
        const ownText = Array.from(el.childNodes)
          .filter((n) => n.nodeType === 3)
          .map((n) => n.textContent.trim())
          .join("")
          .trim();
        const idOrClass = `${el.id || ""} ${el.className || ""}`.toLowerCase();
        if (
          el.offsetWidth > 0 &&
          el.offsetHeight > 0 &&
          (ownText === "X" || ownText === "×" || idOrClass.includes("close") || idOrClass.includes("btnclose"))
        ) {
          return el.id || null;
        }
      }
      return null;
    });
    if (closeBtnId) {
      await clickById(page, closeBtnId);
      await waitMs(1500);
    }

    log("[롯데면세] '매출재고조회' 검색 중...");
    await typeIntoById(page, "mainFrame.vFrameSet1.frameTop.form.edt_search:input", "매출재고조회");
    await waitMs(800);
    await page.keyboard.press("Enter"); // 1차: 추천 메뉴 드롭다운
    await waitMs(1000);
    await page.keyboard.press("Enter"); // 2차: 실제 진입
    await waitMs(2500);

    const menuFound = await page.evaluate(() => document.body.innerText.includes("매출재고조회내역") || document.body.innerText.includes("Ref No"));
    if (!menuFound) throw new Error("[롯데면세] 매출재고조회 화면으로 진입 못 했어요.");
    log("[롯데면세] 화면 진입 확인됨.");
    await waitMs(3000);

    log("[롯데면세] 조회 조건(날짜) 설정 중...");
    const startId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_start.calendaredit:input");
    const endId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_end.calendaredit:input");
    if (!startId || !endId) throw new Error("[롯데면세] 날짜 입력칸을 못 찾았어요.");
    await typeDateRobustly(page, startId, fromDate, fromDateDash);
    await typeDateRobustly(page, endId, toDate, toDateDash);

    log("[롯데면세] 집계구분→SKU, 금액구분→원화금액 설정 중...");
    const agrgDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_agrgDvs.comboedit:input");
    const amtDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_amtDvs.comboedit:input");
    if (agrgDvsId) await selectComboOption(page, agrgDvsId, "SKU");
    if (amtDvsId) await selectComboOption(page, amtDvsId, "원화금액");

    log("[롯데면세] 조회 버튼 클릭 중...");
    const searchBtnTextId = await page.evaluate(() => {
      const all = document.querySelectorAll(".nexatextitem");
      for (const el of all) {
        const ownText = (el.textContent || "").trim();
        if (ownText === "조회" && el.parentElement?.id?.includes("btn_comSearch")) return el.parentElement.id;
      }
      return null;
    });
    if (!searchBtnTextId) throw new Error("[롯데면세] 조회 버튼을 못 찾았어요.");
    await clickById(page, searchBtnTextId);

    log("[롯데면세] 결과 기다리는 중...");
    for (let i = 0; i < 20 && !capturedRows; i++) await waitMs(1000);
    if (!capturedRows) throw new Error("[롯데면세] 조회 결과를 못 받았어요.");

    const raw = capturedRows;
    // MARK: refno = 원본 파일 H열(Ref No.)과 동일한 바코드 필드로 실제 확인됨.
    // MARK: salesamt는 "그 줄 전체(수량 전부 합친) 총액"이라서, 수량이 2 이상인데
    // 그대로 두면 나중에 수량×단가로 다시 곱해질 때 두 배로 뻥튀기됩니다(예:
    // 수량2·금액69586을 그대로 두면 2×69586=139172로 잘못 계산됨). 그래서 총액을
    // 수량으로 나눠서 "개당 단가"를 구하고, 수량만큼 1개씩 낱개 행으로 쪼갭니다
    // (수량2·금액69586 → 수량1·34793 두 줄). 총액이 0이면 계산이 안 되니 10원으로
    // 임시 설정합니다.
    const result = [];
    for (const r of raw) {
      const barcode = String(r.refno || "").trim();
      const qty = Number(r.salesQty || 0);
      const totalAmt = Number(r.salesamt || 0);
      if (!barcode || qty === 0) continue; // 판매수량 0인 SKU는 업로드 대상이 아니라서 제외

      const unitQty = qty > 0 ? 1 : -1; // 반품 등 마이너스 수량도 부호는 유지
      const qtyCount = Math.abs(qty);
      const unitPrice = totalAmt !== 0 ? Math.round(totalAmt / qtyCount) : 10;

      for (let i = 0; i < qtyCount; i++) {
        result.push({
          date: fromDate,
          pos: "P1",
          channel: CHANNEL_CODE.lotte,
          barcode,
          qty: unitQty,
          price: unitPrice,
          source: "롯데면세",
        });
      }
    }
    return result;
  } finally {
    await browser.close();
  }
}

// =========================================================
// 무신사 (완전 자동 — 로그인+OTP+정산조회)
// =========================================================
function getMusinsaOtpCode(secret) {
  const crypto = require("crypto");
  function base32Decode(base32) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let bits = "";
    for (const char of base32.replace(/=+$/, "").toUpperCase()) {
      const val = alphabet.indexOf(char);
      if (val === -1) continue;
      bits += val.toString(2).padStart(5, "0");
    }
    const bytes = [];
    for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
    return Buffer.from(bytes);
  }
  const key = base32Decode(secret);
  const counter = Math.floor(Date.now() / 1000 / 30);
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", key).update(counterBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
  return String(code % 10 ** 6).padStart(6, "0");
}

async function fetchMusinsa(fromDate, toDate) {
  const USER_ID = process.env.MUSINSA_USER_ID;
  const PASSWORD = process.env.MUSINSA_PASSWORD;
  const OTP_SECRET = process.env.MUSINSA_OTP_SECRET;
  if (!USER_ID || !PASSWORD || !OTP_SECRET) {
    log("⚠ MUSINSA_USER_ID/MUSINSA_PASSWORD/MUSINSA_OTP_SECRET가 없어서 무신사는 건너뜁니다.");
    return [];
  }
  const fromDateDash = `${fromDate.slice(0, 4)}-${fromDate.slice(4, 6)}-${fromDate.slice(6, 8)}`;
  const toDateDash = `${toDate.slice(0, 4)}-${toDate.slice(4, 6)}-${toDate.slice(6, 8)}`;

  log("[무신사] 브라우저 여는 중...");
  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  try {
    log("[무신사] 로그인 페이지 이동 중...");
    await page.goto("https://partner.musinsa.com/", { waitUntil: "networkidle2" });
    await waitMs(2000);

    log("[무신사] 아이디/비밀번호 입력 중...");
    await page.type('input[name="id"]', USER_ID, { delay: 30 });
    await page.type('input[name="password"]', PASSWORD, { delay: 30 });
    await page.click('button[type="submit"]');
    await waitMs(3500); // MARK: 비밀번호 재설정 직후라 화면이 평소보다 늦게 뜰 수도 있어서 여유 늘림

    log("[무신사] OTP 입력 중...");
    const otpInputSelector = await page.evaluate(() => {
      const candidates = Array.from(document.querySelectorAll("input")).filter((el) => {
        const type = (el.getAttribute("type") || "text").toLowerCase();
        return (type === "text" || type === "tel" || type === "number") && el.offsetWidth > 0 && el.offsetHeight > 0;
      });
      for (const el of candidates) {
        const attrs = `${el.name || ""} ${el.id || ""} ${el.placeholder || ""}`.toLowerCase();
        if (attrs.includes("otp") || attrs.includes("code") || attrs.includes("인증")) {
          el.setAttribute("data-mark-otp", "1");
          return 'input[data-mark-otp="1"]';
        }
      }
      return null;
    });
    if (!otpInputSelector) {
      // MARK: 원인을 정확히 보기 위해 실패 시 스크린샷+현재 URL+화면 텍스트를 남깁니다.
      const debugDir = path.join(os.homedir(), "Desktop");
      const debugPath = path.join(debugDir, `디버그_무신사_OTP못찾음_${Date.now()}.png`);
      try {
        await page.screenshot({ path: debugPath, fullPage: true });
      } catch {}
      const curUrl = page.url();
      const bodyText = await page.evaluate(() => document.body.innerText.slice(0, 500)).catch(() => "");
      log(`🔍 [진단] 현재 URL: ${curUrl}`);
      log(`🔍 [진단] 화면 텍스트(첫 500자): ${bodyText}`);
      log(`🔍 [진단] 스크린샷 저장: ${debugPath}`);
      throw new Error("[무신사] OTP 입력칸을 못 찾았어요. (디버그 스크린샷/로그 확인해주세요)");
    }

    const otpCode = getMusinsaOtpCode(OTP_SECRET);
    await page.type(otpInputSelector, otpCode, { delay: 50 });
    await waitMs(500);
    const otpSubmitClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll("button"));
      const btn = buttons.find((b) => (b.textContent || "").includes("확인") || (b.textContent || "").includes("인증") || b.type === "submit");
      if (btn) {
        btn.click();
        return true;
      }
      return false;
    });
    if (!otpSubmitClicked) throw new Error("[무신사] OTP 확인 버튼을 못 찾았어요.");

    await waitMs(4000);
    const loggedIn = await page.evaluate(() => !document.querySelector('input[name="password"]'));
    if (!loggedIn) throw new Error("[무신사] 로그인이 완료되지 않은 것 같아요.");
    log("[무신사] 로그인 성공.");

    log("[무신사] 정산 데이터 조회 중...");
    const dataPage = await browser.newPage();
    await dataPage.setUserAgent(realUA);
    await dataPage.goto("https://bizest.musinsa.com/po/order-group-admin/account/stt01?&LAYOUT_TYPE=popup", { waitUntil: "networkidle2" });
    await waitMs(2000);

    const result = await dataPage.evaluate(
      async (fromDateDash, toDateDash) => {
        const body = `PAGE=1&S_SDATE=${fromDateDash}&S_EDATE=${toDateDash}&S_SHOP_LIST=&LIMIT=1000`;
        const res = await fetch("https://bizest.musinsa.com/po/order-group-admin/account/stt01/search", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" },
          body,
          credentials: "include",
        });
        return { status: res.status, text: await res.text() };
      },
      fromDateDash,
      toDateDash
    );
    if (result.status !== 200) throw new Error(`[무신사] 조회 실패 (status=${result.status})`);
    const data = JSON.parse(result.text);
    if (data.result !== "success") throw new Error(`[무신사] 조회 실패: ${JSON.stringify(data).slice(0, 300)}`);

    const raw = data.data || [];
    log(`[무신사] ${raw.length}건 조회됨.`);

    const unmatchedStores = new Set();
    const mapped = raw
      .map((r) => {
        const storeName = r.shopName || "";
        const channel = MUSINSA_STORE_CODES[storeName] || "";
        if (!channel) unmatchedStores.add(storeName);
        return {
          date: (r.date || "").slice(0, 10).replace(/-/g, ""),
          pos: "P1",
          channel,
          barcode: String(r.barcode || "").trim(),
          qty: Number(r.quantity || 0),
          price: Number(r.saleAmount || 0),
          flagged: !channel,
          flagReason: !channel ? `매장코드 매핑 안됨(${storeName})` : undefined,
          source: "무신사",
        };
      })
      .filter((r) => r.barcode);

    if (unmatchedStores.size) {
      log(`⚠ [무신사] 채널코드를 못 찾은 매장: ${Array.from(unmatchedStores).join(", ")}`);
    }
    return mapped;
  } finally {
    await browser.close();
  }
}


function saveMerged(allRows, fromDate, toDate, successSources) {
  const XLSX = require("xlsx");
  const mapped = allRows.map((r) => ({
    일자: r.date,
    POS: r.pos,
    채널: r.channel,
    바코드: r.barcode,
    수량: r.qty,
    단가: r.price,
    출처: r.source,
    확인필요: r.flagged ? "Y (바코드 15자 이상)" : "",
  }));
  const ws = XLSX.utils.json_to_sheet(mapped);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "INSHOP업로드");

  const dateLabel = fromDate === toDate ? fromDate : `${fromDate}_${toDate}`;
  const desktopDir = path.join(os.homedir(), "Desktop");
  // MARK: 예전엔 파일명에 "그때까지 성공한 채널 목록"을 넣었는데, 채널이 하나씩 늦게
  // 성공할 때마다 파일명이 달라져서 바탕화면에 여러 개가 쌓이는 문제가 있었어요
  // (예: "인샵매출20260822(한컬,무신사).xlsx" 다음에 "...(한컬,무신사,면세).xlsx"가 또 생김).
  // 헷갈리니까 날짜만으로 고정된 파일명 하나만 쓰고, 매번 같은 파일을 덮어씁니다.
  const outPath = path.join(desktopDir, `인샵매출${dateLabel}.xlsx`);

  // 예전 방식(채널목록 붙은 이름)으로 남아있는 파일이 있으면 헷갈리니까 같이 정리합니다.
  try {
    const leftovers = fs
      .readdirSync(desktopDir)
      .filter((f) => f.startsWith(`인샵매출${dateLabel}(`) && f.endsWith(".xlsx"));
    for (const f of leftovers) fs.unlinkSync(path.join(desktopDir, f));
  } catch {
    // 정리 실패해도 무시(핵심 기능 아님)
  }
  XLSX.writeFile(wb, outPath);
  return outPath;
}

async function main() {
  let fromDate = process.argv[2];
  let toDate = process.argv[3] || fromDate;
  if (!fromDate) {
    const y = new Date();
    y.setDate(y.getDate() - 1);
    fromDate = `${y.getFullYear()}${String(y.getMonth() + 1).padStart(2, "0")}${String(y.getDate()).padStart(2, "0")}`;
    toDate = fromDate;
  }

  const allRows = [];
  const successSources = [];
  let hankolOk = false;

  try {
    const hankolRows = await fetchHancollection(fromDate, toDate);
    if (hankolRows.length) {
      successSources.push("한컬렉션");
      hankolOk = true;
    }
    allRows.push(...hankolRows);
  } catch (err) {
    console.error("⚠ 한컬렉션 실패:", err.message || err);
  }

  try {
    const lotteRows = await fetchLotte(fromDate, toDate);
    if (lotteRows.length) successSources.push("롯데면세");
    allRows.push(...lotteRows);
  } catch (err) {
    console.error("⚠ 롯데면세 실패:", err.message || err);
  }

  try {
    const musinsaRows = await fetchMusinsa(fromDate, toDate);
    if (musinsaRows.length) successSources.push("무신사");
    allRows.push(...musinsaRows);
  } catch (err) {
    console.error("⚠ 무신사 실패:", err.message || err);
  }

  if (!allRows.length) {
    log("합칠 데이터가 없습니다.");
    process.exitCode = hankolOk ? 0 : 2;
    return;
  }

  const flaggedCount = allRows.filter((r) => r.flagged).length;
  const outPath = saveMerged(allRows, fromDate, toDate, successSources);
  log(`✅ 완료! 총 ${allRows.length}건 저장: ${outPath}`);
  if (flaggedCount) log(`⚠ 바코드 15자 이상이라 확인이 필요한 행이 ${flaggedCount}건 있어요 (엑셀의 "확인필요" 열 참고).`);

  // MARK: 새벽 시간대에 한컬렉션 쪽 정기점검과 겹치면 계속 실패해서, 스케줄러가
  // "한컬렉션만 다음 시간에 재시도할지"를 판단할 수 있도록 종료코드로 신호를 줍니다.
  // 0 = 한컬렉션까지 전부 성공, 2 = 한컬렉션만 실패(다른 채널은 성공했을 수 있음)
  process.exitCode = hankolOk ? 0 : 2;
}

module.exports = {
  fetchHancollection,
  fetchLotte,
  fetchMusinsa,
  saveMerged,
  CHANNEL_CODE,
  log,
  fixFullColorNameToCode,
  fixOldStyleSizeColorOrder,
  // MARK: 롯데면세 기간 백필(download-lotte-range.js)에서 "로그인은 한 번만, 날짜만
  // 바꿔가며 반복 조회"하려고 재사용하는 저수준 헬퍼들. fetchLotte 자체는 새벽 자동화가
  // 그대로 쓰고 있어서 건드리지 않고, 필요한 조각들만 추가로 내보냅니다.
  waitMs,
  parseSalesRows,
  clickById,
  typeIntoById,
  typeDateRobustly,
  findInputIdBySuffix,
  selectComboOption,
};

if (require.main === module) {
  main().catch((err) => {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  });
}
