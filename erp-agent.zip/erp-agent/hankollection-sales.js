// 한컬렉션(good-md) 매출 자동 조회 스크립트
//
// 로그인(/oauth/bridge) → 매출조회(fs.service.sale.Sale_05/listSale)를 자동으로 호출해서
// 결과를 엑셀(.xlsx)로 저장합니다.
//
// 준비물(.env 파일에 추가):
//   HANKOL_USER_ID=v00011
//   HANKOL_PASSWORD=실제비밀번호
//
// 설치(처음 한 번만, 이 폴더에서):
//   npm install xlsx dotenv
//
// 실행:
//   node hankollection-sales.js 20260819           (하루치)
//   node hankollection-sales.js 20260801 20260819  (기간)
//   (날짜 생략하면 어제 하루치)

const https = require("https");
const path = require("path");
require("dotenv").config();

const BASE_HOST = "dtir.good-md.com";
const BASE_PORT = 5180;
const USER_ID = process.env.HANKOL_USER_ID;
const PASSWORD = process.env.HANKOL_PASSWORD;
const COM_CD = "DTIR";

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

// ---------- 쿠키 저장소 ----------
class CookieJar {
  constructor() {
    this.cookies = new Map();
  }
  update(setCookieHeaders) {
    if (!setCookieHeaders) return;
    const arr = Array.isArray(setCookieHeaders) ? setCookieHeaders : [setCookieHeaders];
    for (const raw of arr) {
      const first = raw.split(";")[0];
      const eq = first.indexOf("=");
      if (eq < 0) continue;
      this.cookies.set(first.slice(0, eq).trim(), first.slice(eq + 1).trim());
    }
  }
  header() {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join("; ");
  }
}
const jar = new CookieJar();
let bearerToken = null; // /oauth/bridge 응답에서 얻을 수도 있어서 준비만 해둡니다.

// ---------- HTTP 요청 ----------
function request(method, urlPath, body, extraHeaders = {}) {
  return new Promise((resolve, reject) => {
    const bodyBuf = body ? Buffer.from(body, "utf8") : null;
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36",
      "Accept-Encoding": "identity",
      Cookie: jar.header(),
      ...extraHeaders,
    };
    if (bearerToken) headers["Authorization"] = `bearer ${bearerToken}`;
    if (bodyBuf) headers["Content-Length"] = bodyBuf.length;

    const req = https.request(
      { host: BASE_HOST, port: BASE_PORT, path: urlPath, method, headers },
      (res) => {
        jar.update(res.headers["set-cookie"]);
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => {
          resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString("utf8") });
        });
      }
    );
    req.on("error", reject);
    if (bodyBuf) req.write(bodyBuf);
    req.end();
  });
}

function xmlUnescape(s) {
  return String(s ?? "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function parseSalesRows(xmlText) {
  const rows = [];
  const rowMatches = xmlText.match(/<Row>[\s\S]*?<\/Row>/g) || [];
  for (const rowXml of rowMatches) {
    const row = {};
    const colMatches = rowXml.matchAll(/<Col id="([^"]+)">([^<]*)<\/Col>/g);
    for (const m of colMatches) row[m[1]] = xmlUnescape(m[2]);
    if (Object.keys(row).length) rows.push(row);
  }
  return rows;
}

function makeWebId() {
  // 캡처에서 -2^31~2^31 사이의 랜덤한 정수로 관찰됨(예: -1797175248, 855695973)
  return Math.floor(Math.random() * 4294967296) - 2147483648;
}

// ---------- 로그인 ----------
async function login() {
  log("페이지 초기화 중...");
  await request("GET", "/fashion/index.html", null);

  log("로그인 중...");
  const webId = makeWebId();
  const body = `SSV:utf-8\x1e_xm_webid_1_=${webId}\x1ecom_cd=${COM_CD}\x1euser_id=${USER_ID}\x1epasswd=${PASSWORD}\x1elocale=ko_KR\x1eisDevLogin=true\x1e`;

  const res = await request("POST", "/oauth/bridge", body, {
    "Content-Type": "text/plain;charset=utf-8",
  });

  // MARK: 응답이 SSV 형식(예: "SSV:UTF-8ErrorCode:int=0Dataset:authDs..._accessToken:...")이라
  // "ErrorCode:int=0"인지로 성공 여부를 확인합니다. (예전엔 "error"라는 글자가 포함됐는지로
  // 체크했는데, "ErrorCode" 자체에 "error"가 들어있어서 항상 실패로 잘못 판정했었습니다.)
  const errorCodeMatch = res.body.match(/ErrorCode:int=(-?\d+)/);
  const errorCode = errorCodeMatch ? Number(errorCodeMatch[1]) : null;
  if (res.status !== 200 || errorCode !== 0) {
    console.error(`🔍 [진단] 로그인 응답 status=${res.status}`);
    console.error(`🔍 [진단] 응답 헤더: ${JSON.stringify(res.headers, null, 2)}`);
    console.error(`🔍 [진단] 응답 본문(첫 1000자):\n${res.body.slice(0, 1000)}`);
    throw new Error("로그인 실패 — 위 진단 로그를 확인해주세요.");
  }

  // 응답 안에 실제 accessToken이 들어있어서, 이후 요청에 Authorization 헤더로 실어줍니다.
  const tokenIdx = res.body.indexOf("accessToken");
  const afterToken = tokenIdx >= 0 ? res.body.slice(tokenIdx) : "";
  const tokenMatch = afterToken.match(/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/i);
  if (tokenMatch) {
    bearerToken = tokenMatch[0];
    log(`🔍 [진단] accessToken 확보: ${bearerToken}`);
  } else {
    log("🔍 [진단] accessToken을 응답에서 못 찾았어요 — 쿠키(JSESSIONID)만으로 계속 진행해봅니다.");
  }

  log("로그인 성공.");
  log(`🔍 [진단] 쿠키: ${jar.header()}`);
  return webId;
}

// ---------- 매출 조회 ----------
async function querySales(webId, fromDate, toDate) {
  log(`매출 조회 중: ${fromDate} ~ ${toDate}`);

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Root xmlns="http://www.nexacroplatform.com/platform/dataset">
	<Parameters>
		<Parameter id="_xm_webid_1_">${webId}</Parameter>
		<Parameter id="class">fs.service.sale.Sale_05</Parameter>
		<Parameter id="method">listSale</Parameter>
	</Parameters>
	<Dataset id="DS_COND">
		<ColumnInfo>
			<Column id="from_date" type="STRING" size="256"  />
			<Column id="to_date" type="STRING" size="256"  />
			<Column id="grp_cd" type="STRING" size="256"  />
			<Column id="sto_cd" type="STRING" size="256"  />
			<Column id="sale_gbn" type="STRING" size="256"  />
			<Column id="ret_gbn" type="STRING" size="256"  />
			<Column id="s_manager" type="STRING" size="256"  />
		</ColumnInfo>
		<Rows>
			<Row>
				<Col id="from_date">${fromDate}</Col>
				<Col id="to_date">${toDate}</Col>
				<Col id="grp_cd" />
				<Col id="sto_cd" />
				<Col id="sale_gbn" />
				<Col id="ret_gbn">3</Col>
				<Col id="s_manager" />
			</Row>
		</Rows>
	</Dataset>
</Root>`;

  const res = await request("POST", "/fashionsvr/service", xml, {
    "Content-Type": "text/xml",
    Accept: "application/xml, text/xml, */*",
    "X-Requested-With": "XMLHttpRequest",
  });

  const errorCodeMatch = res.body.match(/ErrorCode"\s+type="int">(-?\d+)</);
  const errorCode = errorCodeMatch ? Number(errorCodeMatch[1]) : null;
  if (errorCode !== 0) {
    console.error(`🔍 [진단] 조회 응답 status=${res.status}`);
    console.error(`🔍 [진단] 응답 본문(첫 1000자):\n${res.body.slice(0, 1000)}`);
    throw new Error(`조회 실패 (ErrorCode=${errorCode})`);
  }

  // MARK: 원본 파일의 "매입거래처상품코드"(진짜 바코드, 예: GF2UKC017BKM_G5)에 해당하는
  // 필드를 API 응답에서 아직 못 찾아서, 첫 행의 모든 필드를 그대로 찍어봅니다.
  const parsedRows = parseSalesRows(res.body);
  if (parsedRows.length) {
    console.error(`🔍 [진단] 첫 번째 결과 행의 모든 필드:\n${JSON.stringify(parsedRows[0], null, 2)}`);
  }
  return parsedRows;
}

function saveToExcel(rows, outPath) {
  const XLSX = require("xlsx");
  const mapped = rows.map((r) => ({
    매장그룹: r.grp_nm || "",
    매장명: r.st_nm || "",
    판매일자: r.sale_date || "",
    품번: r.style_cd || "",
    상품명: r.style_nm || "",
    컬러코드: r.color_cd || "",
    컬러명: r.color_nm || "",
    사이즈: r.sz_nm || "",
    판매수량: Number(r.sale_cnt || 0),
    판매금액: Number(r.sale_amt || 0),
    실판매금액: Number(r.real_amt || 0),
  }));
  const ws = XLSX.utils.json_to_sheet(mapped);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "한컬렉션매출");
  XLSX.writeFile(wb, outPath);
  return mapped;
}

async function main() {
  if (!USER_ID || !PASSWORD) {
    console.error("HANKOL_USER_ID / HANKOL_PASSWORD가 .env에 없습니다.");
    process.exit(1);
  }

  let fromDate = process.argv[2];
  let toDate = process.argv[3] || fromDate;
  if (!fromDate) {
    const y = new Date();
    y.setDate(y.getDate() - 1);
    fromDate = `${y.getFullYear()}${String(y.getMonth() + 1).padStart(2, "0")}${String(y.getDate()).padStart(2, "0")}`;
    toDate = fromDate;
  }

  try {
    const webId = await login();
    const rows = await querySales(webId, fromDate, toDate);
    log(`조회 완료: ${rows.length}건`);

    if (!rows.length) {
      log("데이터가 없습니다.");
      return;
    }

    const outPath = path.join(process.cwd(), `한컬렉션_매출_${fromDate}_${toDate}.xlsx`);
    saveToExcel(rows, outPath);
    log(`✅ 저장 완료: ${outPath}`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
