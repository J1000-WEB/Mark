; 테스트용: sgerp-login-only.exe로 ERP 로그인부터 딱 하고 → 성공 확인되면 → 이어서
; 파워오토메이트(erp_daily) 실행까지 한 번에 진행합니다. (run-power-automate.au3 v3와
; 같은 방식: 창은 최대화만 하고, 검색창으로 흐름 이름을 필터링해서 찾습니다 — 팝업 없이
; 조용히 진행되어서 파워오토메이트 실행을 방해하지 않습니다.)
;
; PA 흐름 자체에서 "ERP 켜고 로그인하는" 단계를 빼신 다음(그 단계가 새벽에 잘 안 됐던
; 부분), 이 스크립트로 "로그인은 우리가 미리 해두고 PA는 그 다음부터"가 실제로 잘
; 이어지는지 테스트해보세요.
;
; 준비물: sgerp-login-only.exe가 이 파일과 같은 폴더에 있어야 합니다
; (sgerp-login-only.au3를 Compile Script로 먼저 만들어두세요).

#include <MsgBoxConstants.au3>

; ===== 1단계: ERP 로그인만 먼저 실행 (끝날 때까지 기다림) =====
ConsoleWrite("===== 1단계: ERP 로그인 시작 =====" & @CRLF)
Local $sLoginExePath = @ScriptDir & "\sgerp-login-only.exe"
If Not FileExists($sLoginExePath) Then
    ConsoleWrite("⚠ sgerp-login-only.exe를 못 찾았어요. 먼저 sgerp-login-only.au3를 Compile Script로 .exe 만들어주세요. 찾던 경로: " & $sLoginExePath & @CRLF)
    Exit
EndIf

Local $iLoginExitCode = RunWait($sLoginExePath, @ScriptDir)
ConsoleWrite("로그인 스크립트 종료코드: " & $iLoginExitCode & @CRLF)

If $iLoginExitCode <> 0 Then
    ConsoleWrite("⚠ ERP 로그인이 실패한 것 같아요(종료코드 " & $iLoginExitCode & "). 파워오토메이트는 실행하지 않고 여기서 멈춥니다." & @CRLF)
    Exit
EndIf
ConsoleWrite("✅ ERP 로그인 성공 확인! 이어서 파워오토메이트를 실행합니다..." & @CRLF)
Sleep(1000)

; ===== 2단계: 파워오토메이트 실행 (run-power-automate.au3 v3와 같은 로직: 최대화 + 검색필터링) =====
ConsoleWrite("===== 2단계: 파워오토메이트 실행 시작 =====" & @CRLF)

Local $sFlowName = "erp_daily"
Local $iSearchOffsetX = 1673, $iSearchOffsetY = 162
Local $iRowOffsetX = 256, $iRowOffsetY = 280
Local $iRunOffsetX = 669, $iRunOffsetY = 270

ConsoleWrite("Power Automate Desktop 앱 실행 중..." & @CRLF)
Run("explorer.exe shell:AppsFolder\Microsoft.PowerAutomateDesktop_8wekyb3d8bbwe!PAD.Console")

ConsoleWrite("창 뜨는 중 기다리는 중..." & @CRLF)
Local $hWin = WinWait("Power Automate", "", 30)
If $hWin = 0 Then
    ConsoleWrite("⚠ Power Automate 창을 30초 안에 못 찾았어요." & @CRLF)
    Exit
EndIf

ConsoleWrite("창이 완전히 뜰 때까지 여유있게 기다리는 중..." & @CRLF)
Sleep(3000)

ConsoleWrite("창 최대화 중..." & @CRLF)
WinActivate($hWin)
Sleep(1000)
WinSetState($hWin, "", @SW_MAXIMIZE)
Sleep(1500)

Local $aWinPos = WinGetPos($hWin)
If Not IsArray($aWinPos) Then
    ConsoleWrite("⚠ 창 위치를 못 가져왔어요." & @CRLF)
    Exit
EndIf
ConsoleWrite("🔍 [진단] 최대화된 창 위치: " & $aWinPos[0] & "," & $aWinPos[1] & " 크기: " & $aWinPos[2] & "x" & $aWinPos[3] & @CRLF)

ConsoleWrite("검색창 클릭 후 '" & $sFlowName & "' 입력 중..." & @CRLF)
MouseClick("left", $aWinPos[0] + $iSearchOffsetX, $aWinPos[1] + $iSearchOffsetY, 1)
Sleep(500)
Send("^a")
Send("{DEL}")
Sleep(200)
Send($sFlowName)
Sleep(1000)

ConsoleWrite("필터링된 흐름 선택 중..." & @CRLF)
MouseClick("left", $aWinPos[0] + $iRowOffsetX, $aWinPos[1] + $iRowOffsetY, 1)
Sleep(800)

ConsoleWrite("실행 버튼 클릭 중..." & @CRLF)
MouseClick("left", $aWinPos[0] + $iRunOffsetX, $aWinPos[1] + $iRunOffsetY, 1)
Sleep(1000)

ConsoleWrite("✅ 완료! 로그인 → 파워오토메이트 실행까지 전부 진행됐어요. 실제로 흐름이 끝까지 잘 도는지 확인해주세요." & @CRLF)
