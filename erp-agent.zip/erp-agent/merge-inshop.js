// 각 채널 스케줄러(schedule-hankollection.js 등)가 성공할 때마다 만들어두는 캐시 파일들을
// 주기적으로 모아서, 그 시점까지 성공한 채널만으로 최종 "인샵매출YYYYMMDD(...).xlsx"
// 파일을 (다시) 만드는 스케줄러입니다. 늦게 성공한 채널이 있으면 다음 병합 때 자동으로
// 반영됩니다 — 그래서 최종 파일은 시간이 지날수록 채널이 하나씩 채워지는 식으로 갱신됩니다.

const fs = require("fs");
const path = require("path");
const { saveMerged } = require("./build-inshop-upload.js");
const { hasCache, cacheFilePath, yesterdayString, CACHE_DIR } = require("./channel-scheduler.js");

const MERGE_TIMES = [
  { hour: 1, minute: 15 }, // 한컬렉션/무신사(1시) 끝난 뒤 여유
  { hour: 2, minute: 15 }, // 면세(2시) 끝난 뒤 여유 — ERP업로드(2시30분) 전에 확실히 반영되도록
];
const CHANNELS = [
  { key: "hankollection", name: "한컬렉션" },
  { key: "lotte", name: "롯데면세" },
  // MARK: 무신사는 보안 문제로 자동화 중단(2026-08-30) — 목록에서 빼서, 병합할 때마다
  // "무신사 아직 안 모임"이라고 계속 알려주는 걸 멈춥니다.
];

function log(...args) {
  console.log(`[병합] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
}

function loadCache(channelKey, dateStr) {
  const p = cacheFilePath(channelKey, dateStr);
  if (!fs.existsSync(p)) return null;
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function doMerge() {
  const dateStr = yesterdayString();
  const allRows = [];
  const successSources = [];

  for (const ch of CHANNELS) {
    const rows = loadCache(ch.key, dateStr);
    if (rows && rows.length) {
      allRows.push(...rows);
      successSources.push(ch.name);
    }
  }

  if (!allRows.length) {
    log("아직 성공한 채널이 하나도 없어서, 만들 게 없어요.");
    return;
  }

  const outPath = saveMerged(allRows, dateStr, dateStr, successSources);
  log(`✅ 지금까지 성공한 채널(${successSources.join(",")})로 파일 갱신: ${outPath}`);

  if (successSources.length === CHANNELS.length) {
    log("🎉 세 채널 다 모였어요 — 오늘 병합은 이걸로 완료.");
  } else {
    const missing = CHANNELS.filter((c) => !successSources.includes(c.name)).map((c) => c.name);
    log(`아직 안 모인 채널: ${missing.join(", ")} — 다음 병합 시간에 다시 확인합니다.`);
  }
}

let lastAttemptedSlot = null;
function tick() {
  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();
  const match = MERGE_TIMES.find((t) => t.hour === hour && t.minute === minute);
  if (!match) return;
  const slotKey = `${todayString()}-${hour}-${minute}`;
  if (lastAttemptedSlot === slotKey) return;
  lastAttemptedSlot = slotKey;
  doMerge();
}

log(`시작합니다. 매일 [${MERGE_TIMES.map((t) => `${t.hour}시${t.minute}분`).join(", ")}]마다 그때까지 성공한 채널들로 파일을 갱신합니다.`);
setInterval(tick, 60 * 1000);
tick();
