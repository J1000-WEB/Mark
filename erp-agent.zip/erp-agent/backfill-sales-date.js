// MARK ERP Agent — 특정 날짜 매출 백필 (MARK 6.102)
//
// sales-refresh.js는 "오늘"만 조회하는 구조라서, 업로드가 며칠 실패했거나(2026-08-15~18
// 1000만 셀 사고처럼) 놓친 과거 날짜는 못 채웁니다. 이 스크립트는 날짜를 지정해서 그날의
// SL1010 매출을 다시 통째로 가져와 Daily_Sales_History에 채워 넣습니다.
//
// sales-refresh.js(upsert)와 다르게 "replace" 모드를 씁니다 — 이미 지난 날은 ERP가 주는
// 값이 그날의 최종 확정치라서, 기존에 부분적으로만 들어간 데이터가 있어도 통째로 덮어써서
// 깔끔하게 맞추는 게 더 정확합니다.
//
// 실행 방법:
//   node erp-agent/backfill-sales-date.js 20260816
//   node erp-agent/backfill-sales-date.js 20260816 20260817   (여러 날짜 한번에, 공백으로 구분)

const {
  log,
  login,
  getOfflineShops,
  erpRequest,
  runWithConcurrency,
  extractSizeField,
  uploadRowsChunked,
  COMP_CD,
  ERP_USER,
  ERP_PASS,
} = require("./erp-core");

let salesDiagnosticLogged = false;

async function fetchSalesForDate(offlineShops, ymd) {
  log(`${ymd} 매출 조회 시작: 오프라인 매장 ${offlineShops.length}개`);

  const results = await runWithConcurrency(offlineShops, async (shop) => {
    const res = await erpRequest("/GI/SL/SL1010/getMainDetailList.do", {
      comp_cd: COMP_CD,
      sale_dt: ymd,
      shop_cd: shop.SHOP_CD,
    });
    if (res.RESULT_CODE !== "SUCCESS") return [];
    if (!salesDiagnosticLogged && (res.RESULT_DATA || []).length) {
      salesDiagnosticLogged = true;
      log("🔍 [진단] SL1010 매출 응답 원본 필드:", JSON.stringify(res.RESULT_DATA[0]));
    }

    const agg = new Map();
    for (const row of res.RESULT_DATA || []) {
      const size = extractSizeField(row);
      const key = `${row.STY_CD}__${row.COL_CD}__${size}`;
      if (!agg.has(key)) {
        agg.set(key, {
          shopCd: shop.SHOP_CD,
          shopNm: shop.SHOP_NM,
          styCd: row.STY_CD,
          styNm: row.STY_NM,
          colCd: row.COL_CD,
          size,
          qty: 0,
          amount: 0,
        });
      }
      const bucket = agg.get(key);
      bucket.qty += Number(row.SALES_QTY || 0);
      bucket.amount += Number(row.SALES_TAMT || 0);
    }
    return Array.from(agg.values());
  });

  const flat = results.flat().filter((r) => r && !r.error);
  log(`${ymd} 매출 조회 완료. ${flat.length}건 수집.`);
  return flat;
}

function toRows(salesRecords, isoDate) {
  return salesRecords.map((r) => ({
    date: isoDate,
    storeName: r.shopNm,
    styleCode: r.styCd,
    productName: r.styNm || "",
    colorCode: r.colCd,
    colorName: r.colCd,
    size: r.size || "",
    qty: r.qty,
    amount: r.amount,
  }));
}

async function backfillOneDate(offlineShops, ymd) {
  const isoDate = ymd.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
  const salesRecords = await fetchSalesForDate(offlineShops, ymd);
  const rows = toRows(salesRecords, isoDate);

  log(`${isoDate} — ${rows.length}건 replace(그날 전체 교체) 업로드 중...`);
  if (!rows.length) {
    log(`⚠ ${isoDate}에 매출 데이터가 0건입니다 — ERP에 그날 데이터가 없거나 휴무일일 수 있어요. 건너뜁니다(기존 데이터를 건드리지 않기 위해 업로드 자체를 생략).`);
    return;
  }
  const { totalNew, totalUpdated } = await uploadRowsChunked(isoDate, rows, { mode: "replace" });
  log(`✅ ${isoDate} 완료. 신규 ${totalNew}건, 갱신 ${totalUpdated}건`);
}

async function main() {
  if (!ERP_USER || !ERP_PASS) {
    console.error("ERP_USER / ERP_PASS가 .env에 없습니다.");
    process.exit(1);
  }

  const dates = process.argv.slice(2);
  if (!dates.length) {
    console.error("사용법: node backfill-sales-date.js <YYYYMMDD> [YYYYMMDD ...]");
    console.error("예) node backfill-sales-date.js 20260816 20260817");
    process.exit(1);
  }
  for (const d of dates) {
    if (!/^\d{8}$/.test(d)) {
      console.error(`날짜 형식이 잘못됐습니다: ${d} (YYYYMMDD 형식이어야 함, 예: 20260816)`);
      process.exit(1);
    }
  }

  const overallStart = Date.now();
  try {
    await login();
    const offlineShops = await getOfflineShops();

    for (const ymd of dates) {
      await backfillOneDate(offlineShops, ymd);
    }

    const totalSec = ((Date.now() - overallStart) / 1000).toFixed(1);
    log(`✅ 전체 완료 (${totalSec}초). ${dates.length}개 날짜 처리함.`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
