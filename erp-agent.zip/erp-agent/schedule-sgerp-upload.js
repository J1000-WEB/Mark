// ERP 업로드(sgerp-login.exe)를 매일 오전 2시 30분에 자동 실행하는 스케줄러
//
// run-all.js랑 같은 창에서 같이 돌리기 위해 만든 파일입니다. 인샵매출업로드(한컬/무신사=1시,
// 면세=2시)가 다 끝난 뒤 여유를 두고 2시 30분으로 잡았습니다. 이 스크립트가 부르는 건
// sgerp-login.au3를 컴파일한 sgerp-login.exe입니다(AutoIt 스크립트를 .exe로 미리
// 컴파일해두셔야 해요 — .au3 파일 우클릭 → Compile Script).

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const iconv = require("iconv-lite");

const TARGET_HOUR = 2;
const TARGET_MINUTE = 20;
const CHECK_INTERVAL_MS = 60 * 1000;

const SGERP_EXE = path.join(__dirname, "sgerp-login.exe");

function log(...args) {
  console.log(`[ERP업로드-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

let lastRunDate = null;

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function runErpUpload() {
  if (!fs.existsSync(SGERP_EXE)) {
    log(`⚠ ${SGERP_EXE}가 없어요. sgerp-login.au3를 먼저 Compile Script로 .exe 만들어주세요.`);
    return;
  }
  log("오전 2시 30분이 되어 ERP 업로드를 시작합니다...");
  // MARK: AutoIt 컴파일 exe의 콘솔 출력은 한글 Windows 기본 코드페이지(cp949)라서,
  // stdio:"inherit"로 그냥 통과시키면 글자가 깨져 보였습니다. 직접 받아서 cp949→UTF-8로
  // 바꿔서 출력합니다.
  const child = spawn(SGERP_EXE, [], { stdio: ["inherit", "pipe", "pipe"] });
  child.stdout.on("data", (buf) => process.stdout.write(iconv.decode(buf, "cp949")));
  child.stderr.on("data", (buf) => process.stderr.write(iconv.decode(buf, "cp949")));
  child.on("error", (err) => {
    log(`⚠ ERP 업로드 실행 실패: ${err.message}`);
  });
  child.on("exit", (code) => {
    log(`ERP 업로드 스크립트 종료 (코드 ${code}).`);
  });
}

function tick() {
  const now = new Date();
  const today = todayString();
  if (now.getHours() === TARGET_HOUR && now.getMinutes() === TARGET_MINUTE && lastRunDate !== today) {
    lastRunDate = today;
    runErpUpload();
  }
}

log(`시작합니다. 매일 오전 ${TARGET_HOUR}시 ${TARGET_MINUTE}분에 ERP 업로드를 자동 실행합니다.`);
setInterval(tick, CHECK_INTERVAL_MS);
tick();
