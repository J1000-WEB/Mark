// 파워오토메이트(2시50분) 실행 5분 전, 2시45분에 ERP를 무조건 강제 종료하는 안전장치.
//
// 원래는 sgerp-login.au3가 끝날 때(OnAutoItExitRegister) 항상 ERP를 닫도록 되어있지만,
// 만에 하나 그 스크립트 자체가 도중에 죽거나 멈춰서 종료 처리가 안 될 경우를 대비한
// 이중 안전장치입니다. 파워오토메이트 흐름이 "ERP를 새로 켜는 것"부터 시작하기 때문에,
// 이전에 ERP가 이상한 상태로 남아있으면 파워오토메이트도 같이 꼬일 수 있어서 넣었습니다.
//
// 단순히 "이름으로 프로그램 강제 종료"만 하면 되는 작업이라 AutoIt 없이 Windows 기본
// 명령어(taskkill)로 바로 처리합니다.

const { exec } = require("child_process");

const TARGET_HOUR = 2;
const TARGET_MINUTE = 22;
const CHECK_INTERVAL_MS = 60 * 1000;

function log(...args) {
  console.log(`[ERP강제종료-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

let lastRunDate = null;

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function forceCloseErp() {
  log("오전 2시 45분이 되어 ERP를 강제로 닫습니다 (파워오토메이트가 깨끗한 상태에서 시작할 수 있도록)...");
  exec("taskkill /F /IM MiPlatform320U.exe", (err) => {
    // MARK: ERP가 이미 안 켜져 있으면 taskkill이 "그런 프로세스 없음" 에러를 내는데,
    // 이건 정상적인 상황(이미 잘 꺼져있던 것)이라 에러여도 조용히 넘어갑니다.
    if (err) {
      log("ERP가 이미 꺼져있었거나, 종료 시도를 완료했어요.");
    } else {
      log("✅ ERP 강제 종료 완료.");
    }
  });
}

function tick() {
  const now = new Date();
  const today = todayString();
  if (now.getHours() === TARGET_HOUR && now.getMinutes() === TARGET_MINUTE && lastRunDate !== today) {
    lastRunDate = today;
    forceCloseErp();
  }
}

log(`시작합니다. 매일 오전 ${TARGET_HOUR}시 ${TARGET_MINUTE}분에 ERP를 강제 종료합니다(파워오토메이트 전 안전장치).`);
setInterval(tick, CHECK_INTERVAL_MS);
tick();
