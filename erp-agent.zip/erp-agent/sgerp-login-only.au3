; SG ERP 로그인 전용 스크립트 — 로그인만 하고 메인 화면 뜨는 것까지 확인한 다음
; "ERP는 켜둔 채로" 종료합니다. sgerp-login.exe(전체 업로드까지 하는 버전)와 다르게
; 여기서는 ERP를 끄지 않습니다 — 파워오토메이트가 이 로그인 상태를 그대로 이어받아서
; 나머지 작업(메뉴이동, 다운로드 등)을 하도록 하기 위해서입니다.
;
; 배경: 파워오토메이트 자체에도 "ERP 켜고 로그인하는" 단계가 들어있는데, 새벽에 그
; 단계에서 키보드 입력이 잘 안 먹혀서 계속 실패하는 문제가 있었습니다(ERP 창만 켜진 채로
; 멈춤). 저희 AutoIt 로그인은 안정적으로 잘 되니까, 이 스크립트로 로그인까지만 미리 딱
; 해두고, 파워오토메이트 흐름에서는 "로그인" 단계를 빼고 "이미 로그인된 화면에서 이어서
; 하기"로 바꾸면 될 것 같습니다.

#include <MsgBoxConstants.au3>

; MARK: 새벽에 모니터가 절전으로 꺼져있으면 자동화 입력이 잘 안 먹힐 수 있어서, 화면을 깨웁니다.
MouseMove(100, 100, 0)
Sleep(200)
MouseMove(300, 300, 0)
Sleep(200)
Send("{SHIFT}")
Sleep(2000)

DllCall("user32.dll", "bool", "SetProcessDPIAware")

Func _EscapeForSend($sText)
    $sText = StringReplace($sText, "{", "{{}")
    $sText = StringReplace($sText, "}", "{}}")
    $sText = StringReplace($sText, "!", "{!}")
    $sText = StringReplace($sText, "+", "{+}")
    $sText = StringReplace($sText, "^", "{^}")
    $sText = StringReplace($sText, "#", "{#}")
    Return $sText
EndFunc

; ===== 설정 =====
Local $sExePath = 'C:\Windows\SysWOW64\MiUpdater321.exe -L TRUE -R FALSE -D WIN32U -V 3.2 -K GENERAL_ERP -X http://general.sgerp.com/mi/erp_general.xml -Wd 1024 -Ht 768'
Local $sLoginId = "sjc"
Local $sLoginPw = "1031thwocjs!"

Func _FindRealLoginWindow($iTimeoutSec)
    Local $iElapsed = 0
    While $iElapsed < $iTimeoutSec
        Local $aWinList = WinList("[CLASS:#32770]")
        For $i = 1 To $aWinList[0][0]
            Local $hCandidate = $aWinList[$i][1]
            If Not IsHWnd($hCandidate) And $hCandidate = 0 Then ContinueLoop
            Local $aPos = ControlGetPos($hCandidate, "", "EditTobe3")
            If IsArray($aPos) Then
                Local $aWinSize = WinGetPos($hCandidate)
                If IsArray($aWinSize) And $aWinSize[2] > 400 And $aWinSize[2] < 800 Then
                    ConsoleWrite("🔍 [진단] 진짜 로그인창 찾음! 핸들=" & $hCandidate & ", 크기=" & $aWinSize[2] & "x" & $aWinSize[3] & @CRLF)
                    Return $hCandidate
                EndIf
            EndIf
        Next
        Sleep(1000)
        $iElapsed += 1
    WEnd
    Return 0
EndFunc

; ===== 1단계: 프로그램 실행 (이미 켜져 있으면 건너뜀) =====
ConsoleWrite("프로그램 실행 중..." & @CRLF)
If Not ProcessExists("MiPlatform320U.exe") Then
    Run($sExePath)
    Sleep(5000)
EndIf

; ===== 2단계: 로그인 창 찾기 =====
ConsoleWrite("로그인 창 기다리는 중..." & @CRLF)
Local $hLoginWin = _FindRealLoginWindow(45)
If $hLoginWin = 0 Then
    ConsoleWrite("⚠ 진짜 로그인 창을 45초 안에 못 찾았어요." & @CRLF)
    Exit 1
EndIf

; ===== 3단계: 준비완료(아이디 자동입력) 대기 =====
ConsoleWrite("앱 준비되는 중 — 아이디 칸에 '" & $sLoginId & "'가 나타날 때까지 최대 60초 기다립니다..." & @CRLF)
Local $bReady = False
For $i = 1 To 60
    If ControlGetText($hLoginWin, "", "EditTobe3") = $sLoginId Then
        $bReady = True
        ExitLoop
    EndIf
    Sleep(1000)
Next
If Not $bReady Then
    ConsoleWrite("⚠ 60초를 기다렸는데도 아이디 칸에 '" & $sLoginId & "'가 안 나타났어요." & @CRLF)
    Exit 1
EndIf
ConsoleWrite("✅ 준비 완료 확인됨!" & @CRLF)
Sleep(500)

; ===== 4단계: 비밀번호 입력 (클릭 없이, 최대 3번 재시도) =====
ConsoleWrite("비밀번호 입력 중..." & @CRLF)
Local $sCheckPw = ""
For $iAttempt = 1 To 3
    WinActivate($hLoginWin)
    Sleep(200)
    If Not WinActive($hLoginWin) Then
        WinSetOnTop($hLoginWin, "", 1)
        Sleep(200)
        WinSetOnTop($hLoginWin, "", 0)
        WinActivate($hLoginWin)
        Sleep(300)
    EndIf

    Send(_EscapeForSend($sLoginPw))
    Sleep(500)
    $sCheckPw = ControlGetText($hLoginWin, "", "EditTobe2")
    ConsoleWrite("🔍 비밀번호 입력 시도 " & $iAttempt & "번째 — 칸 길이: " & StringLen($sCheckPw) & "자" & @CRLF)
    If $sCheckPw <> "" Then ExitLoop
    Sleep(500)
Next
If $sCheckPw = "" Then
    ConsoleWrite("⚠ 비밀번호 칸이 3번 시도해도 계속 비어있어요!" & @CRLF)
    Exit 1
EndIf

; ===== 5단계: 엔터로 로그인 =====
ConsoleWrite("엔터로 로그인 시도..." & @CRLF)
Send("{ENTER}")
Sleep(1500)

If WinExists($hLoginWin) Then
    ConsoleWrite("⚠ 로그인 창이 아직 안 닫혔어요 — 로그인이 실패했을 수 있어요." & @CRLF)
    Exit 1
EndIf
ConsoleWrite("로그인 창 닫힘 확인." & @CRLF)

; ===== 6단계: 메인 화면 뜰 때까지 대기 (여기서 끝, ERP는 켜둔 채로 종료) =====
ConsoleWrite("메인 화면 기다리는 중..." & @CRLF)
Sleep(2000)
Local $hMainWin = WinWait("GENERAL ERP", "", 20)
If $hMainWin = 0 Then
    ConsoleWrite("⚠ 로그인 후 메인 화면을 20초 안에 못 찾았어요." & @CRLF)
    Exit 1
EndIf
WinActivate($hMainWin)
Sleep(1000)
ConsoleWrite("✅ 로그인 성공! 메인 화면 진입 확인됨. ERP는 켜둔 채로 종료합니다(파워오토메이트가 이어받으세요)." & @CRLF)
Exit 0
