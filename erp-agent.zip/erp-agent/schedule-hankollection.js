// 한컬렉션 전용 — 새벽 1시에 성공하는 것으로 확인됨(실측). 딱 그 시간에만 시도합니다.
const { runChannelScheduler } = require("./channel-scheduler.js");
const { fetchHancollection } = require("./build-inshop-upload.js");

runChannelScheduler({
  channelKey: "hankollection",
  channelName: "한컬렉션",
  retryHours: [1],
  fetchFn: fetchHancollection,
});
