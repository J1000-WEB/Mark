// 과거 인샵매출 엑셀 파일들의 바코드를, build-inshop-upload.js에 이미 있는 자동수정
// 로직(컬러 풀네임→코드, 사이즈/컬러 순서 뒤바뀜)으로 일괄 정리하는 스크립트입니다.
//
// 지금 새벽 자동화가 매일 만드는 파일이랑 똑같은 형식(일자/POS/채널/바코드/수량/단가/
// 출처/확인필요, 바코드=D열)을 그대로 씁니다.
//
// 사용법:
//   node fix-old-barcodes.js 파일1.xlsx 파일2.xlsx ... (여러 개 한번에 가능)
//   또는: node fix-old-barcodes.js 폴더경로   (그 폴더 안의 .xlsx 파일 전부 처리)
//
// 안전하게, 원본은 "파일명.xlsx.bak"으로 백업해두고 나서 같은 파일에 덮어씁니다.

const fs = require("fs");
const path = require("path");
const XLSX = require("xlsx");
const { fixFullColorNameToCode, fixOldStyleSizeColorOrder } = require("./build-inshop-upload.js");

const BARCODE_COL_INDEX = 3; // D열(0-indexed) — 인샵매출 파일(일자,POS,채널,바코드,...) 기본값
const BARCODE_HEADER_NAMES = ["바코드", "매입거래처\n상품코드", "매입거래처상품코드"];
const MAX_HEADER_SEARCH_ROWS = 15; // 이 안에서 헤더 행을 찾음 (매출일보 원본은 10번째 줄에 헤더가 있음)

function log(...args) {
  console.log(`[바코드정리] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

// 헤더가 항상 0번째 줄에 있는 게 아니라서(원본 "매출일보" 파일은 9번째 줄), 앞의 몇 줄
// 안에서 바코드 관련 헤더 이름이 들어있는 행을 찾아 그 행을 헤더로, 그다음 줄부터를
// 데이터로 봅니다. 못 찾으면 예전처럼 0번째 줄을 헤더로 보고 기본 컬럼(D열)을 씁니다.
function findHeaderRowAndCol(rows) {
  for (let r = 0; r < Math.min(MAX_HEADER_SEARCH_ROWS, rows.length); r++) {
    const row = rows[r];
    for (let c = 0; c < row.length; c++) {
      const cell = String(row[c] || "").trim();
      if (BARCODE_HEADER_NAMES.some((name) => cell.replace(/\s/g, "") === name.replace(/\s/g, ""))) {
        return { headerRowIndex: r, colIndex: c };
      }
    }
  }
  return { headerRowIndex: 0, colIndex: BARCODE_COL_INDEX };
}

function fixBarcode(barcode) {
  let b = String(barcode || "").trim();
  if (!b) return { fixed: b, changed: false };
  let changed = false;

  // 밑줄 뒤 접미사(예: "WBE1L04506BL00L_F5") 제거 — 한컬렉션 처리 때와 같은 규칙
  if (b.includes("_")) {
    b = b.split("_")[0];
    changed = true;
  }

  if (b.length >= 13) {
    const r1 = fixFullColorNameToCode(b);
    if (r1.changed) {
      b = r1.fixed;
      changed = true;
    }
  }
  const r2 = fixOldStyleSizeColorOrder(b);
  if (r2.changed) {
    b = r2.fixed;
    changed = true;
  }
  return { fixed: b, changed };
}

function processFile(filePath) {
  log(`처리 중: ${filePath}`);
  const wb = XLSX.readFile(filePath);
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true, defval: "" });

  if (!rows.length) {
    log(`  ⚠ 빈 파일이라 건너뜁니다.`);
    return;
  }

  const { headerRowIndex, colIndex: barcodeCol } = findHeaderRowAndCol(rows);
  const headerLabel = String(rows[headerRowIndex]?.[barcodeCol] || "").trim() || "헤더 없음, 기본값 사용";
  log(`  바코드 열: ${barcodeCol}번째 (${headerLabel}), 데이터는 ${headerRowIndex + 1}번째 줄부터`);

  let changedCount = 0;
  let checkedCount = 0;
  for (let i = headerRowIndex + 1; i < rows.length; i++) {
    const original = rows[i][barcodeCol];
    if (!original) continue; // 이 열이 비어있는 행은 건드리지 않음(정상적인 경우일 수 있음)
    checkedCount++;
    const { fixed, changed } = fixBarcode(original);
    if (changed) {
      rows[i][barcodeCol] = fixed;
      changedCount++;
    }
  }

  if (changedCount === 0) {
    log(`  수정할 바코드 없음 (값 있는 ${checkedCount}건 확인).`);
    return;
  }

  // 원본 백업
  const backupPath = `${filePath}.bak`;
  if (!fs.existsSync(backupPath)) {
    fs.copyFileSync(filePath, backupPath);
  }

  // 같은 파일에 덮어쓰기
  const newSheet = XLSX.utils.aoa_to_sheet(rows);
  wb.Sheets[sheetName] = newSheet;
  XLSX.writeFile(wb, filePath);

  log(`  ✅ ${changedCount}건 수정 완료 (원본은 ${path.basename(backupPath)}로 백업됨).`);
}

function main() {
  const args = process.argv.slice(2);
  if (!args.length) {
    console.error("사용법: node fix-old-barcodes.js 파일1.xlsx [파일2.xlsx ...] 또는 폴더경로");
    process.exit(1);
  }

  let files = [];
  for (const arg of args) {
    const stat = fs.statSync(arg);
    if (stat.isDirectory()) {
      const allFiles = fs.readdirSync(arg);
      const inDir = allFiles.filter((f) => {
        const lower = f.toLowerCase();
        return (lower.endsWith(".xlsx") || lower.endsWith(".xls")) && !lower.endsWith(".bak");
      });
      if (!inDir.length) {
        log(`⚠ "${arg}" 폴더에서 엑셀 파일을 못 찾았어요. 이 폴더 안의 파일 목록: ${allFiles.join(", ") || "(비어있음)"}`);
      }
      files.push(...inDir.map((f) => path.join(arg, f)));
    } else {
      files.push(arg);
    }
  }

  log(`총 ${files.length}개 파일 처리 시작...`);
  for (const f of files) {
    try {
      processFile(f);
    } catch (err) {
      log(`  ⚠ 실패: ${f} — ${err.message}`);
    }
  }
  log("✅ 전체 완료.");
}

main();
