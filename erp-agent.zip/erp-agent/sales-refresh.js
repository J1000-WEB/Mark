// MARK ERP Agent — 매출 실시간 갱신 (MARK 6.71)
//
// 하는 일:
//   1) 오프라인 매장 목록 조회
//   2) 오늘 날짜로 SL1010(매출 상세)을 매장별로 조회 — daily-snapshot.js가 "어제"로
//      호출하던 것과 완전히 같은 API, sale_dt만 오늘로 바꿔서 씁니다.
//   3) "오늘" 날짜로, qty/amount 필드만 upsert(부분 갱신)해서 업로드 — 재고(stock)는
//      건드리지 않습니다 (그건 stock-refresh.js가 따로 담당).
//
// 예전 scrape.js(Playwright 브라우저 자동화)보다 훨씬 가볍고 빠릅니다 — 화면을 직접
// 클릭하고 다니는 대신 daily-snapshot.js와 같은 방식으로 API를 순수 HTTP로 호출해요.
//
// 실행 방법:
//   node erp-agent/sales-refresh.js

const {
  log,
  todayKST,
  login,
  getOfflineShops,
  erpRequest,
  runWithConcurrency,
  extractSizeField,
  uploadRowsChunked,
  COMP_CD,
  ERP_USER,
  ERP_PASS,
} = require("./erp-core");

let salesDiagnosticLogged = false;

// MARK 2026-09-10: 실시간 탭이 매장 1곳(현대커넥트 청주점)만 계속 보여주는 문제를
// 조사하다가, fetchTodaySales가 매장별 응답이 "성공인데 0건"인지 "아예 실패(세션
// 만료/오류)"인지 구분 없이 전부 조용히 빈 배열로 넘겨버리는 걸 발견했습니다 — 그래서
// 지금까지는 로그만 봐서는 "정말 매출이 없는 매장"과 "조회 자체가 실패한 매장"을
// 구분할 수 없었습니다. 매장별 응답 상태를 모아뒀다가 사이클 끝에 요약으로 남깁니다
// (다음 매출 라벨 로그에서 바로 확인 가능 — 코드 동작 자체는 그대로입니다).
async function fetchTodaySales(offlineShops, ymd) {
  log(`오늘(${ymd}) 매출 조회 시작: 오프라인 매장 ${offlineShops.length}개`);

  const shopStatus = [];

  const results = await runWithConcurrency(offlineShops, async (shop) => {
    let res;
    try {
      res = await erpRequest("/GI/SL/SL1010/getMainDetailList.do", {
        comp_cd: COMP_CD,
        sale_dt: ymd,
        shop_cd: shop.SHOP_CD,
      });
    } catch (err) {
      shopStatus.push({ shop: shop.SHOP_NM, ok: false, reason: err.message || String(err) });
      throw err;
    }
    if (res.RESULT_CODE !== "SUCCESS") {
      shopStatus.push({ shop: shop.SHOP_NM, ok: false, reason: res.RESULT_CODE || "응답없음" });
      return [];
    }
    if (!salesDiagnosticLogged && (res.RESULT_DATA || []).length) {
      salesDiagnosticLogged = true;
      log("🔍 [진단] SL1010 매출 응답 원본 필드:", JSON.stringify(res.RESULT_DATA[0]));
    }

    const agg = new Map(); // key: styCd__colCd__size
    for (const row of res.RESULT_DATA || []) {
      const size = extractSizeField(row);
      const key = `${row.STY_CD}__${row.COL_CD}__${size}`;
      if (!agg.has(key)) {
        agg.set(key, {
          shopCd: shop.SHOP_CD,
          shopNm: shop.SHOP_NM,
          styCd: row.STY_CD,
          styNm: row.STY_NM,
          colCd: row.COL_CD,
          size,
          qty: 0,
          amount: 0,
        });
      }
      const bucket = agg.get(key);
      bucket.qty += Number(row.SALES_QTY || 0);
      bucket.amount += Number(row.SALES_TAMT || 0);
    }
    shopStatus.push({ shop: shop.SHOP_NM, ok: true, rows: (res.RESULT_DATA || []).length });
    return Array.from(agg.values());
  });

  const flat = results.flat().filter((r) => r && !r.error);

  const failedShops = shopStatus.filter((s) => !s.ok);
  const zeroRowShops = shopStatus.filter((s) => s.ok && s.rows === 0);
  const dataShops = shopStatus.filter((s) => s.ok && s.rows > 0);
  log(
    `매장별 응답 — 매출있음 ${dataShops.length}개 / 매출없음(정상) ${zeroRowShops.length}개 / 조회실패 ${failedShops.length}개` +
      (dataShops.length ? ` [매출있음: ${dataShops.map((s) => s.shop).join(", ")}]` : "")
  );
  if (failedShops.length) {
    log(`⚠ 조회 실패한 매장: ${failedShops.map((s) => `${s.shop}(${s.reason})`).join(", ")}`);
  }

  log(`오늘 매출 조회 완료. ${flat.length}건 수집.`);
  return flat;
}

function toRows(salesRecords, isoDate) {
  return salesRecords.map((r) => ({
    date: isoDate,
    storeName: r.shopNm,
    styleCode: r.styCd,
    productName: r.styNm || "",
    colorCode: r.colCd,
    colorName: r.colCd, // ERP 매출 응답엔 컬러명이 없음 — stock-refresh가 Product360 기준
    // 컬러명으로 이미 채워둔 행이 있으면 upsert가 stock 필드만 건드리니 그대로 남아있음
    size: r.size || "",
    qty: r.qty,
    amount: r.amount,
  }));
}

async function main() {
  if (!ERP_USER || !ERP_PASS) {
    console.error("ERP_USER / ERP_PASS가 .env에 없습니다.");
    process.exit(1);
  }

  const overallStart = Date.now();
  try {
    await login();
    const offlineShops = await getOfflineShops();

    const ymd = todayKST();
    const isoDate = ymd.replace(/(\d{4})(\d{2})(\d{2})/, "$1-$2-$3");
    const salesRecords = await fetchTodaySales(offlineShops, ymd);
    const rows = toRows(salesRecords, isoDate);

    log(`${isoDate} — ${rows.length}건 upsert(매출만 갱신) 업로드 중...`);
    const { totalNew, totalUpdated } = await uploadRowsChunked(isoDate, rows, {
      mode: "upsert",
      onlyFields: ["qty", "amount"],
    });

    const totalSec = ((Date.now() - overallStart) / 1000).toFixed(1);
    log(`✅ 완료 (${totalSec}초). 신규 ${totalNew}건, 갱신 ${totalUpdated}건`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    process.exit(1);
  }
}

main();
