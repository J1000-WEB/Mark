// 인샵매출업로드(build-inshop-upload.js)를 매일 새벽 3시에 자동으로 한 번 실행하는 스케줄러
//
// run-all.js(재고/매출/목표)랑 같은 CMD 창에서 같이 돌리기 위해 만든 별도 파일입니다.
// run-all.js의 다른 작업들처럼 "계속 재시작"하는 방식이 아니라, "매일 새벽 3시가 되면
// 딱 한 번 실행"하는 방식이라 별도 스케줄러로 분리했습니다.

const { spawn } = require("child_process");
const path = require("path");

const TARGET_HOUR = 3; // 새벽 3시
const CHECK_INTERVAL_MS = 60 * 1000; // 1분마다 시간 확인

function log(...args) {
  console.log(`[인샵업로드-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

let lastRunDate = null; // "2026-08-21" 형태 — 오늘 이미 실행했는지 확인용

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function runInshopUpload() {
  log("새벽 3시가 되어 인샵매출업로드를 시작합니다...");
  const child = spawn("node", [path.join(__dirname, "build-inshop-upload.js")], {
    stdio: "inherit", // 이 스크립트의 로그(로그인 진행상황 등)가 같은 창에 그대로 보이게
  });
  child.on("exit", (code) => {
    log(`인샵매출업로드 종료 (코드 ${code}).`);
  });
}

function tick() {
  const now = new Date();
  const today = todayString();
  if (now.getHours() === TARGET_HOUR && lastRunDate !== today) {
    lastRunDate = today;
    runInshopUpload();
  }
}

log(`시작합니다. 매일 새벽 ${TARGET_HOUR}시에 자동으로 실행됩니다. (이 창을 닫으면 스케줄도 멈춥니다)`);
setInterval(tick, CHECK_INTERVAL_MS);
tick(); // 혹시 스크립트를 새벽 3시대에 막 켰다면 바로 한 번 확인
