// Power Automate 흐름(erp_daily)을 매일 오전 2시25분, 3시35분 — 하루 두 번 자동 실행하는
// 스케줄러.
//
// MARK: 원래는 하루 한 번(2:50)만 실행했는데, 그 시간대에 파워오토메이트가 유독 잘 안
// 되는 경우가 있어서(정확한 원인은 불명), 시간을 앞당기고 한 번 더 재시도하도록
// 두 번 도는 구조로 바꿨습니다(2:25 시도 → 안 됐어도 3:35에 한 번 더).
//
// run-all.js랑 같은 창에서 같이 돌리기 위해 만든 파일입니다.
// 준비물: AutoIt이 설치되어 있어야 하고, login-then-pa.au3, sgerp-login-only.exe를
// 같은 폴더에 둬야 합니다.
// (AutoIt3.exe 경로가 다르면 아래 AUTOIT_EXE 값을 실제 경로로 수정해주세요)

const { spawn } = require("child_process");
const path = require("path");
const fs = require("fs");
const iconv = require("iconv-lite");

const RUN_TIMES = [
  { hour: 2, minute: 25 },
  { hour: 3, minute: 35 },
];
const CHECK_INTERVAL_MS = 60 * 1000;

// AutoIt3.exe의 흔한 설치 경로들을 순서대로 확인해서 존재하는 걸 씁니다.
const AUTOIT_CANDIDATES = ["C:\\Program Files (x86)\\AutoIt3\\AutoIt3.exe", "C:\\Program Files\\AutoIt3\\AutoIt3.exe"];
const AUTOIT_EXE = AUTOIT_CANDIDATES.find((p) => fs.existsSync(p)) || AUTOIT_CANDIDATES[0];

function log(...args) {
  console.log(`[파워오토메이트-스케줄러] [${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function todayString() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function runPowerAutomate(hour, minute) {
  log(`오전 ${hour}시 ${minute}분이 되어 파워오토메이트 흐름을 실행합니다...`);
  // MARK: 파워오토메이트 흐름(erp_daily)에서 자체 ERP 로그인 단계를 빼고, 대신 이
  // login-then-pa.au3(우리 로그인 → 성공 확인 → PA 실행)로 대체했습니다. PA 자체
  // 로그인이 새벽에 잘 안 되는 문제가 있어서, 안정적인 우리 로그인을 먼저 하고
  // 넘겨주는 방식으로 바꿨습니다.
  const scriptPath = path.join(__dirname, "login-then-pa.au3");
  // MARK: AutoIt 콘솔 출력이 cp949라서 stdio:"inherit"로 그냥 통과시키면 한글이
  // 깨져 보였습니다. 직접 받아서 cp949→UTF-8로 바꿔서 출력합니다.
  const child = spawn(AUTOIT_EXE, [scriptPath], { stdio: ["inherit", "pipe", "pipe"] });
  child.stdout.on("data", (buf) => process.stdout.write(iconv.decode(buf, "cp949")));
  child.stderr.on("data", (buf) => process.stderr.write(iconv.decode(buf, "cp949")));
  child.on("error", (err) => {
    log(`⚠ AutoIt 실행 실패: ${err.message} (AutoIt이 설치되어 있는지, 경로가 맞는지 확인해주세요: ${AUTOIT_EXE})`);
  });
  child.on("exit", (code) => {
    log(`파워오토메이트 실행 스크립트 종료 (코드 ${code}).`);
  });
}

let lastRunSlot = null;
function tick() {
  const now = new Date();
  const hour = now.getHours();
  const minute = now.getMinutes();
  const match = RUN_TIMES.find((t) => t.hour === hour && t.minute === minute);
  if (!match) return;
  const slotKey = `${todayString()}-${hour}-${minute}`;
  if (lastRunSlot === slotKey) return;
  lastRunSlot = slotKey;
  runPowerAutomate(hour, minute);
}

log(`시작합니다. 매일 [${RUN_TIMES.map((t) => `${t.hour}시${t.minute}분`).join(", ")}]에 파워오토메이트 흐름을 자동 실행합니다.`);
setInterval(tick, CHECK_INTERVAL_MS);
tick();
