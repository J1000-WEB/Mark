// 롯데면세(SRM) 매출 자동 조회 스크립트 v3 — "가로채기" 방식
//
// 로그인과 조회 버튼 클릭은 소천님이 직접 브라우저에서 해주시고, 그 결과(매출재고조회
// 응답)를 스크립트가 자동으로 감지해서 엑셀로 저장합니다. 로그인/조회에 사이트 자체의
// 숨은 로직(화면 진입 기록, 토큰 등)이 있어서 직접 재현하는 게 계속 막혔기 때문에,
// 사이트 로직은 하나도 안 건드리고 "결과만 가로채는" 가장 확실한 방식으로 바꿨습니다.
//
// 설치(처음 한 번만):
//   npm install puppeteer xlsx
//
// 실행:
//   node lotte-dfs-sales.js
//
// 브라우저 창이 뜨면: 로그인 → 매출재고조회 화면 → 날짜 설정 → 조회 버튼 클릭
// 그러면 자동으로 엑셀 파일이 저장되고 안내가 뜹니다. (여러 번 조회하면 그때마다 저장됩니다)
// 끝나면 CMD 창에서 Ctrl+C로 종료하시면 됩니다.

const puppeteer = require("puppeteer");
const path = require("path");

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function xmlUnescape(s) {
  return String(s ?? "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function parseSalesRows(xmlText) {
  const rows = [];
  const rowMatches = xmlText.match(/<Row>[\s\S]*?<\/Row>/g) || [];
  for (const rowXml of rowMatches) {
    const row = {};
    const colMatches = rowXml.matchAll(/<Col id="([^"]+)">([^<]*)<\/Col>/g);
    for (const m of colMatches) row[m[1]] = xmlUnescape(m[2]);
    if (Object.keys(row).length) rows.push(row);
  }
  return rows;
}

function saveToExcel(rows) {
  const XLSX = require("xlsx");
  // MARK: 실제 캡처로 확인된 진짜 필드명으로 고쳤습니다 — 예전엔 한컬렉션 필드명이랑
  // 헷갈려서 존재하지 않는 필드명(style_cd, sale_date 등)을 썼던 실수가 있었어요.
  // 롯데면세 응답의 실제 컬럼: refno(=Ref No.=바코드), prdcd(품번코드), prodNm(상품명),
  // colorVal(컬러), sizeVal(사이즈), salesQty(판매수량), salesamt(판매금액), strNm(매장명).
  // 날짜별 항목이 따로 없고 조회기간 전체로 집계돼서 나와서(agrgDvs=S), 판매일자 칸은 못 채웁니다
  // (호출부에서 조회에 쓴 날짜를 알고 있으니, 필요하면 파일명에만 붙입니다).
  const mapped = rows.map((r) => ({
    매장명: r.strNm || "",
    품번: r.prdcd || r.itemcd || "",
    상품명: r.prodNm || "",
    컬러: r.colorVal || "",
    사이즈: r.sizeVal || "",
    Ref_No: r.refno || "",
    판매수량: Number(r.salesQty || 0),
    판매금액: Number(r.salesamt || 0),
  }));

  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const outPath = path.join(process.cwd(), `롯데면세_매출_(${stamp}).xlsx`);

  const ws = XLSX.utils.json_to_sheet(mapped);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "롯데면세매출");
  XLSX.writeFile(wb, outPath);
  return outPath;
}

async function main() {
  log("브라우저 여는 중...");
  const browser = await puppeteer.launch({
    headless: false,
    args: ["--disable-blink-features=AutomationControlled"],
  });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  const client = await page.target().createCDPSession();
  await client.send("Network.enable");
  const pending = new Map();

  client.on("Network.requestWillBeSent", (params) => {
    if (params.request.url.includes("SrmSalesStckInqryController/inqrySrmSalesStck")) {
      pending.set(params.requestId, true);
    }
  });

  // MARK: 예전엔 "Network.responseReceived"(응답 헤더만 도착한 시점)에서 바로 본문을
  // 가져오려고 해서 "No data found" 오류가 났습니다. 본문까지 다 받은 뒤에 뜨는
  // "Network.loadingFinished"를 기다린 다음에 가져오도록 고쳤습니다.
  client.on("Network.loadingFinished", async (params) => {
    if (!pending.has(params.requestId)) return;
    pending.delete(params.requestId);

    try {
      const body = await client.send("Network.getResponseBody", { requestId: params.requestId });
      const text = body.base64Encoded ? Buffer.from(body.body, "base64").toString("utf8") : body.body;
      const rows = parseSalesRows(text);
      if (!rows.length) {
        log("⚠ 조회 결과에 데이터가 없어요 (빈 조회였거나 파싱 실패). 다시 조회해보세요.");
        return;
      }
      const outPath = saveToExcel(rows);
      log(`✅ 조회 결과 감지! ${rows.length}건 저장 완료: ${outPath}`);
    } catch (err) {
      log("⚠ 결과 처리 중 오류:", err.message || err);
    }
  });

  await page.goto("https://srm.lottedfs.co.kr/ui/ldfs_ui/index.html", { waitUntil: "networkidle2" });

  console.log("\n============================================");
  console.log(" 브라우저 창에서 평소처럼:");
  console.log(" 로그인 → 매출재고조회 화면 → 날짜 설정 → 조회 버튼 클릭");
  console.log(" 하시면 자동으로 엑셀 파일이 저장됩니다.");
  console.log(" (여러 번 조회하면 그때마다 새 파일로 저장돼요)");
  console.log(" 다 끝나셨으면 이 창에서 Ctrl+C로 종료하세요.");
  console.log("============================================\n");

  // 사용자가 여러 번 조회할 수 있으니 프로세스를 계속 살려둡니다 (Ctrl+C로 직접 종료).
  await new Promise(() => {});
}

main().catch((err) => {
  console.error("⚠ 실패:", err.message || err);
  process.exit(1);
});
