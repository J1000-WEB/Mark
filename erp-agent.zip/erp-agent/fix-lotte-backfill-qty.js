// fix-lotte-backfill-qty.js
//
// 목적: 예전에 download-lotte-range.js (버그 수정 "전" 버전)로 받아둔 롯데면세 백필 파일은
// 다건 판매(수량 2개 이상)의 "단가" 칼럼에 실제로는 "합계금액"이 들어가 있어서,
// 나중에 매출 = 수량 x 단가 로 계산하는 곳에서 매출이 2배/3배로 뻥튀기됩니다.
//
// 이 스크립트는 재다운로드(재로그인+스크래핑) 없이, 이미 받아둔 파일 안에 있는
// "원래 수량"과 "원래 단가(=합계금액)"만으로 올바른 수량:1(또는 -1) 행들로 바로 재계산합니다.
// (build-inshop-upload.js의 fetchLotte() / download-lotte-range.js에 이미 적용된 것과 동일한 공식)
//
//   unitQty   = 원래 수량이 양수면 1, 음수면 -1
//   qtyCount  = abs(원래 수량)
//   unitPrice = 원래 단가(합계) !== 0 ? round(원래 단가 / qtyCount) : 10
//   → qtyCount 개의 행으로 확장, 각 행은 { 수량: unitQty, 단가: unitPrice }
//
// 안전장치: 원본은 절대 덮어쓰지 않고 원본 옆에 "_원본백업.xlsx"로 복사해두고,
// 고친 결과는 "_수정됨.xlsx"라는 새 파일로 따로 저장합니다.
//
// 사용법:
//   node fix-lotte-backfill-qty.js "롯데면세_20250820_20251231.xlsx"
//
// (엑셀 파일이 있는 폴더에서 실행하거나, 파일 전체 경로를 넣어주세요)

const path = require("path");
const fs = require("fs");
const XLSX = require("xlsx");

const LOTTE_CHANNEL_CODE = "81028";
const LOTTE_SOURCE_LABEL = "롯데면세";

function main() {
  const inputArg = process.argv[2];
  if (!inputArg) {
    console.error("사용법: node fix-lotte-backfill-qty.js <엑셀파일경로>");
    process.exit(1);
  }

  const inputPath = path.resolve(inputArg);
  if (!fs.existsSync(inputPath)) {
    console.error(`파일을 찾을 수 없습니다: ${inputPath}`);
    process.exit(1);
  }

  const dir = path.dirname(inputPath);
  const base = path.basename(inputPath, path.extname(inputPath));
  const ext = path.extname(inputPath);

  const backupPath = path.join(dir, `${base}_원본백업${ext}`);
  const outputPath = path.join(dir, `${base}_수정됨${ext}`);

  // 원본 백업 (이미 있으면 덮어쓰지 않음 - 여러 번 실행해도 원본이 안전하도록)
  if (!fs.existsSync(backupPath)) {
    fs.copyFileSync(inputPath, backupPath);
    console.log(`✅ 원본 백업 완료: ${backupPath}`);
  } else {
    console.log(`ℹ️  백업 파일이 이미 있어서 새로 만들지 않았습니다: ${backupPath}`);
  }

  const wb = XLSX.readFile(inputPath);
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

  console.log(`📄 원본 행 수: ${rows.length}`);

  // 실제 컬럼명 확인 (일자/POS/채널/바코드/수량/단가/출처/확인필요 형태로 가정)
  const sample = rows[0] || {};
  const cols = Object.keys(sample);
  console.log(`📋 컬럼: ${cols.join(", ")}`);

  const findCol = (candidates) => cols.find((c) => candidates.includes(c));
  const COL_DATE = findCol(["일자", "date"]);
  const COL_POS = findCol(["POS", "pos"]);
  const COL_CHANNEL = findCol(["채널", "channel"]);
  const COL_BARCODE = findCol(["바코드", "barcode"]);
  const COL_QTY = findCol(["수량", "qty"]);
  const COL_PRICE = findCol(["단가", "price"]);
  const COL_SOURCE = findCol(["출처", "source"]);
  const COL_FLAG = findCol(["확인필요"]);

  if (!COL_QTY || !COL_PRICE) {
    console.error("❌ 수량/단가 컬럼을 찾을 수 없습니다. 컬럼명을 확인해주세요:", cols);
    process.exit(1);
  }

  let splitCount = 0; // 몇 개의 원본 행이 쪼개졌는지
  let untouchedCount = 0; // 롯데가 아니거나 이미 정상(±1)이라 그대로 둔 행 수
  const outRows = [];

  for (const row of rows) {
    const channel = String(row[COL_CHANNEL] ?? "").trim();
    const source = String(row[COL_SOURCE] ?? "").trim();
    const isLotte = channel === LOTTE_CHANNEL_CODE || source === LOTTE_SOURCE_LABEL;

    const qty = Number(row[COL_QTY]);
    const price = Number(row[COL_PRICE]);

    if (!isLotte || !qty || Math.abs(qty) === 1) {
      // 롯데가 아니거나(다른 채널 행 그대로 유지), 이미 수량이 ±1이면 손대지 않음
      outRows.push(row);
      if (isLotte) untouchedCount++;
      continue;
    }

    // 다건 판매 행 → 쪼개기
    const unitQty = qty > 0 ? 1 : -1;
    const qtyCount = Math.abs(qty);
    const unitPrice = price !== 0 ? Math.round(price / qtyCount) : 10;

    for (let i = 0; i < qtyCount; i++) {
      const newRow = { ...row };
      newRow[COL_QTY] = unitQty;
      newRow[COL_PRICE] = unitPrice;
      outRows.push(newRow);
    }
    splitCount++;
  }

  const newSheet = XLSX.utils.json_to_sheet(outRows, { header: cols });
  const newWb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(newWb, newSheet, sheetName);
  XLSX.writeFile(newWb, outputPath);

  console.log("");
  console.log("=== 완료 ===");
  console.log(`쪼갠 원본 행 수 (수량 2개 이상이었던 행): ${splitCount}`);
  console.log(`손대지 않은 롯데 행 수 (이미 ±1): ${untouchedCount}`);
  console.log(`최종 행 수: ${outRows.length} (원본 ${rows.length}행에서 ${outRows.length - rows.length}행 증가)`);
  console.log(`✅ 수정된 파일 저장: ${outputPath}`);
}

main();
