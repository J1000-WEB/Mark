// 롯데면세(SRM) 완전자동화 스크립트
//
// 진단 결과로 찾은 실제 화면 요소를 바탕으로, 로그인 → 메뉴이동 → 날짜설정 → 조회버튼 클릭까지
// 전부 Puppeteer가 진짜로 타이핑/클릭해서 재현합니다. 결과는 기존에 검증된 방식(CDP로
// API 응답 가로채기)으로 받아서 엑셀로 저장합니다.
//
// 준비물(.env):
//   LOTTE_DFS_USER_ID=400125218532
//   LOTTE_DFS_PASSWORD=실제비밀번호
//
// 설치(처음 한 번만):
//   npm install puppeteer xlsx dotenv
//
// 실행:
//   node lotte-dfs-fullauto.js 20260819
//   (날짜 생략하면 어제 하루치)

const puppeteer = require("puppeteer");
const path = require("path");
require("dotenv").config();

const USER_ID = process.env.LOTTE_DFS_USER_ID;
const PASSWORD = process.env.LOTTE_DFS_PASSWORD;
const BASE = "https://srm.lottedfs.co.kr";

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

function xmlUnescape(s) {
  return String(s ?? "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code)));
}

function parseSalesRows(xmlText) {
  const rows = [];
  const rowMatches = xmlText.match(/<Row>[\s\S]*?<\/Row>/g) || [];
  for (const rowXml of rowMatches) {
    const row = {};
    const colMatches = rowXml.matchAll(/<Col id="([^"]+)">([^<]*)<\/Col>/g);
    for (const m of colMatches) row[m[1]] = xmlUnescape(m[2]);
    if (Object.keys(row).length) rows.push(row);
  }
  return rows;
}

function saveToExcel(rows) {
  const XLSX = require("xlsx");
  const mapped = rows.map((r) => ({
    매장명: r.strNm || "",
    품번: r.prdcd || r.itemcd || "",
    상품명: r.prodNm || "",
    컬러: r.colorVal || "",
    사이즈: r.sizeVal || "",
    Ref_No: r.refno || "",
    판매수량: Number(r.salesQty || 0),
    판매금액: Number(r.salesamt || 0),
  }));
  const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const outPath = path.join(process.cwd(), `롯데면세_매출_(${stamp}).xlsx`);
  const ws = XLSX.utils.json_to_sheet(mapped);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "롯데면세매출");
  XLSX.writeFile(wb, outPath);
  return outPath;
}

// ---------- 화면 조작 헬퍼 ----------
// MARK: Puppeteer의 기본 click()은 요소의 화면상 크기/좌표를 계산해서 그 위치를 누르는
// 방식인데, Nexacro가 그리는 일부 요소는 이 계산이 잘 안 맞아서 "not clickable" 에러가
// 났습니다. 반대로 el.click() 하나만 보내면(마우스가 실제로 지나가는 과정 없이 클릭 신호만
// 보내는 거라) "마우스가 실제로 올라와야(hover) 반응하는" 버튼은 못 눌렀습니다(조회 버튼이
// 그랬어요) — mouseover→mousedown→mouseup→click을 순서대로 다 보내서 진짜 클릭처럼 만듭니다.
async function clickById(page, id) {
  const clicked = await page.evaluate((id) => {
    const el = document.getElementById(id);
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const opts = { bubbles: true, cancelable: true, view: window, clientX: rect.x + rect.width / 2, clientY: rect.y + rect.height / 2 };
    el.dispatchEvent(new MouseEvent("mouseover", opts));
    el.dispatchEvent(new MouseEvent("mouseenter", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.dispatchEvent(new MouseEvent("click", opts));
    return true;
  }, id);
  if (!clicked) throw new Error(`요소를 못 찾았어요: ${id}`);
}

async function typeIntoById(page, id, text) {
  const handle = await page.evaluateHandle((id) => document.getElementById(id), id);
  const el = handle.asElement();
  if (!el) throw new Error(`입력칸을 못 찾았어요: ${id}`);
  await el.click({ clickCount: 3 }); // 기존 내용 전체선택
  await page.keyboard.type(text, { delay: 30 });
  await handle.dispose();
}

// MARK: 날짜 입력칸(달력 마스크)이 트리플클릭+타이핑으로는 계속 엉뚱한 값("02-02" 등)이
// 들어가서, 훨씬 확실하게: 클릭 → 전체선택(Ctrl+A) → 지우기(Backspace 여러 번) → 한 글자씩
// 느리게 입력 → 값 확인 → 틀리면 다시 처음부터, 이렇게 재시도까지 넣었습니다.
async function typeDateRobustly(page, id, digits, expectedDash) {
  for (let attempt = 1; attempt <= 3; attempt++) {
    const handle = await page.evaluateHandle((id) => document.getElementById(id), id);
    const el = handle.asElement();
    if (!el) throw new Error(`날짜 입력칸을 못 찾았어요: ${id}`);
    await el.click();
    await page.keyboard.down("Control");
    await page.keyboard.press("KeyA");
    await page.keyboard.up("Control");
    for (let i = 0; i < 12; i++) await page.keyboard.press("Backspace"); // 넉넉히 지우기
    await waitMs(150);
    for (const ch of digits) {
      await page.keyboard.type(ch, { delay: 0 });
      await waitMs(80); // 한 글자씩, 이 화면이 처리할 시간을 넉넉히 줍니다
    }
    await page.keyboard.press("Tab");
    await waitMs(300);
    await handle.dispose();

    const value = await page.evaluate((id) => document.getElementById(id)?.value, id);
    if (String(value).includes(expectedDash)) {
      return value; // 성공
    }
    log(`⚠ 날짜 입력 시도 ${attempt}번째 실패(값=${value}) — 다시 시도합니다.`);
  }
  throw new Error(`날짜(${expectedDash})를 3번 시도해도 제대로 못 넣었어요.`);
}

// id가 특정 문자열로 끝나는 첫 번째 <input> 요소의 실제 id를 찾습니다
// (Nexacro는 화면 인스턴스마다 id 중간에 랜덤 숫자가 붙어서, 끝부분만으로 찾아야 합니다).
async function findInputIdBySuffix(page, suffix) {
  return page.evaluate((suffix) => {
    const el = Array.from(document.querySelectorAll("input")).find((e) => e.id.endsWith(suffix));
    return el ? el.id : null;
  }, suffix);
}

// 화면 안에서 "자기 자신의 텍스트"가 target과 정확히 일치하는 요소의 id를 찾습니다.
async function findElementIdByExactText(page, target) {
  return page.evaluate((target) => {
    const all = document.querySelectorAll("div, span");
    for (const el of all) {
      const ownText = Array.from(el.childNodes)
        .filter((n) => n.nodeType === 3)
        .map((n) => n.textContent.trim())
        .join("")
        .trim();
      if (ownText === target) return el.id || null;
    }
    return null;
  }, target);
}

async function waitMs(ms) {
  await new Promise((r) => setTimeout(r, ms));
}

// MARK: 콤보박스(집계구분, 금액구분 같은 드롭다운)는 입력칸을 클릭하면 목록이 펼쳐지고,
// 그 목록에서 원하는 글자가 정확히 일치하는 항목을 클릭해야 선택됩니다.
async function selectComboOption(page, comboInputId, optionText) {
  await clickById(page, comboInputId); // 콤보박스 펼치기
  await waitMs(600);
  const optionId = await page.evaluate((optionText) => {
    const all = document.querySelectorAll("div, span, li");
    for (const el of all) {
      const ownText = Array.from(el.childNodes)
        .filter((n) => n.nodeType === 3)
        .map((n) => n.textContent.trim())
        .join("")
        .trim();
      if (ownText === optionText && el.offsetWidth > 0 && el.offsetHeight > 0) return el.id || null;
    }
    return null;
  }, optionText);
  if (!optionId) {
    throw new Error(`콤보박스에서 "${optionText}" 항목을 못 찾았어요 (입력칸: ${comboInputId})`);
  }
  await clickById(page, optionId);
  await waitMs(400);
}

async function main() {
  if (!USER_ID || !PASSWORD) {
    console.error("LOTTE_DFS_USER_ID / LOTTE_DFS_PASSWORD가 .env에 없습니다.");
    process.exit(1);
  }

  let fromDate = process.argv[2];
  let toDate = process.argv[3] || fromDate;
  if (!fromDate) {
    const y = new Date();
    y.setDate(y.getDate() - 1);
    fromDate = `${y.getFullYear()}${String(y.getMonth() + 1).padStart(2, "0")}${String(y.getDate()).padStart(2, "0")}`;
    toDate = fromDate;
  }
  const fromDateDash = `${fromDate.slice(0, 4)}-${fromDate.slice(4, 6)}-${fromDate.slice(6, 8)}`;
  const toDateDash = `${toDate.slice(0, 4)}-${toDate.slice(4, 6)}-${toDate.slice(6, 8)}`;

  log("브라우저 여는 중...");
  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  // CDP로 조회 결과를 가로챌 준비 (기존에 검증된 방식)
  const client = await page.target().createCDPSession();
  await client.send("Network.enable");
  let capturedRows = null;
  const pending = new Map();
  client.on("Network.requestWillBeSent", (params) => {
    if (params.request.url.includes("SrmSalesStckInqryController/inqrySrmSalesStck")) {
      pending.set(params.requestId, true);
    }
  });
  client.on("Network.loadingFinished", (params) => {
    if (!pending.has(params.requestId)) return;
    pending.delete(params.requestId);
    (async () => {
      try {
        const body = await client.send("Network.getResponseBody", { requestId: params.requestId });
        const text = body.base64Encoded ? Buffer.from(body.body, "base64").toString("utf8") : body.body;
        const rows = parseSalesRows(text);
        if (rows.length) {
          capturedRows = rows;
          log(`조회 결과 감지: ${rows.length}건`);
        }
      } catch (err) {
        log(`⚠ 결과 처리 중 오류: ${err.message || err}`);
      }
    })();
  });

  try {
    log("페이지 초기화 중...");
    await page.goto(`${BASE}/ui/ldfs_ui/index.html`, { waitUntil: "networkidle2" });
    await waitMs(2000);

    log("아이디/비밀번호 입력 중...");
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userId:input", USER_ID);
    await typeIntoById(page, "mainFrame.vFrameSet1.frameLogin.form.div_all.form.div_main.form.edt_userPwd:input", PASSWORD);

    log("로그인 시도 중 (Enter)...");
    await page.keyboard.press("Enter");
    await waitMs(4000);

    // MARK: 로그인 성공하면 "공지사항/To-Do" 같은 환영 패널이 화면을 덮어서 뜨는 경우가
    // 있어요(스크린샷으로 확인됨) — 이게 메뉴를 가리고 있어서, 닫기(X) 버튼을 찾아서 눌러줍니다.
    log("환영 패널 닫는 중(있으면)...");
    const closeBtnId = await page.evaluate(() => {
      // "X" 글자 하나짜리 요소, 또는 class/id에 close가 들어간 요소를 찾습니다.
      const all = document.querySelectorAll("div, span");
      for (const el of all) {
        const ownText = Array.from(el.childNodes)
          .filter((n) => n.nodeType === 3)
          .map((n) => n.textContent.trim())
          .join("")
          .trim();
        const idOrClass = `${el.id || ""} ${el.className || ""}`.toLowerCase();
        if (
          el.offsetWidth > 0 &&
          el.offsetHeight > 0 &&
          (ownText === "X" || ownText === "×" || idOrClass.includes("close") || idOrClass.includes("btnclose"))
        ) {
          return el.id || null;
        }
      }
      return null;
    });
    if (closeBtnId) {
      log(`환영 패널 닫기 버튼 찾음, 클릭: ${closeBtnId}`);
      await clickById(page, closeBtnId);
      await waitMs(1500);
    } else {
      log("환영 패널 닫기 버튼을 못 찾았어요 — 없는 경우일 수도 있으니 계속 진행합니다.");
    }

    log("메뉴에서 '매출재고조회' 찾는 중...");
    // MARK: 검색창에 타이핑하고 Enter를 누르면 "MD(상품) > 매출재고현황조회 > 매출재고조회"
    // 같은 추천 메뉴 경로가 드롭다운으로 먼저 뜨고(1차 Enter), 그 상태에서 Enter를 한 번 더
    // 눌러야(2차 Enter) 진짜 그 화면으로 들어가진다는 걸 확인했습니다 — Enter 두 번으로 고칩니다.
    await typeIntoById(page, "mainFrame.vFrameSet1.frameTop.form.edt_search:input", "매출재고조회");
    await waitMs(800);
    await page.keyboard.press("Enter"); // 1차: 추천 메뉴 드롭다운 뜸
    await waitMs(1000);
    await page.keyboard.press("Enter"); // 2차: 그 메뉴로 실제 진입
    await waitMs(2500);

    let menuFound = await page.evaluate(() => document.body.innerText.includes("매출재고조회내역") || document.body.innerText.includes("Ref No"));
    if (!menuFound) {
      await page.screenshot({ path: path.join(process.cwd(), "디버그_메뉴못찾음.png") });
      throw new Error("Enter 두 번을 눌러도 매출재고조회 화면으로 안 들어가진 것 같아요. (디버그_메뉴못찾음.png 확인해주세요)");
    }
    log("매출재고조회 화면 진입 확인됨.");
    log("메뉴 클릭함, 화면 로딩 대기 중...");
    await waitMs(3000);

    log("조회 조건(날짜) 설정 중...");
    const startId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_start.calendaredit:input");
    const endId = await findInputIdBySuffix(page, ".div_search.form.div_termDate.form.cal_end.calendaredit:input");
    if (!startId || !endId) throw new Error("날짜 입력칸을 못 찾았어요 — 화면 구조가 진단 때와 달라졌을 수 있어요.");

    const startVal = await typeDateRobustly(page, startId, fromDate, fromDateDash);
    log(`🔍 [진단] 시작일 입력 성공: ${startVal}`);
    const endVal = await typeDateRobustly(page, endId, toDate, toDateDash);
    log(`🔍 [진단] 종료일 입력 성공: ${endVal}`);

    log("집계구분을 SKU로, 금액구분을 원화금액으로 변경 중...");
    const agrgDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_agrgDvs.comboedit:input");
    const amtDvsId = await findInputIdBySuffix(page, ".div_search.form.cbo_amtDvs.comboedit:input");
    if (agrgDvsId) {
      await selectComboOption(page, agrgDvsId, "SKU");
      log("집계구분 → SKU 완료.");
    } else {
      log("⚠ 집계구분 입력칸을 못 찾았어요 — 건너뜁니다.");
    }
    if (amtDvsId) {
      await selectComboOption(page, amtDvsId, "원화금액");
      log("금액구분 → 원화금액 완료.");
    } else {
      log("⚠ 금액구분 입력칸을 못 찾았어요 — 건너뜁니다.");
    }

    log("조회 버튼 찾는 중...");
    const searchBtnTextId = await page.evaluate(() => {
      const all = document.querySelectorAll(".nexatextitem");
      for (const el of all) {
        const ownText = (el.textContent || "").trim();
        if (ownText === "조회" && el.parentElement?.id?.includes("btn_comSearch")) {
          return el.parentElement.id;
        }
      }
      return null;
    });
    if (!searchBtnTextId) throw new Error("조회 버튼을 못 찾았어요.");
    log("조회 버튼 클릭!");
    await clickById(page, searchBtnTextId);

    log("결과 기다리는 중...");
    for (let i = 0; i < 20 && !capturedRows; i++) {
      await waitMs(1000);
    }

    if (!capturedRows) {
      throw new Error("조회 결과를 못 받았어요 — 화면을 직접 확인해주세요(창을 닫지 마세요).");
    }

    const outPath = saveToExcel(capturedRows);
    log(`✅ 완료! ${capturedRows.length}건 저장: ${outPath}`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    console.error("   (화면을 직접 보시고 어디서 막혔는지 확인해주세요 — 브라우저 창은 안 닫았어요)");
    process.exitCode = 1;
    await waitMs(60000); // 실패 시 1분간 창을 열어둬서 무슨 상황인지 볼 수 있게 함
  } finally {
    await browser.close();
  }
}

main();
