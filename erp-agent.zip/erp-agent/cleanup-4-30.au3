; 새벽 4시30분 정리 스크립트 — 켜져있는 크롬/엑셀 창을 정리합니다.
;
; - 크롬: 강제종료(ProcessClose)로 꺼서 "나가시겠습니까?" 팝업 자체가 안 뜨게 합니다.
; - 엑셀: 오늘자 "PIP업데이트YYYYMMDD.xlsx" 파일이 이미 있으면(=ERP업로드 성공) 그냥 강제종료.
;         없으면(=업로드 실패했을 가능성) 엑셀에서 그 이름으로 먼저 저장한 다음 종료합니다.

#include <MsgBoxConstants.au3>

; MARK: 새벽에 모니터가 절전으로 꺼져있으면 자동화 입력이 잘 안 먹힐 수 있어서, 맨 처음에
; 마우스를 살짝 움직이고 무해한 키를 하나 눌러서 화면을 깨웁니다.
MouseMove(100, 100, 0)
Sleep(200)
MouseMove(300, 300, 0)
Sleep(200)
Send("{SHIFT}")
Sleep(2000)

Local $sTodayDate = @YEAR & StringFormat("%02d", Number(@MON)) & StringFormat("%02d", Number(@MDAY))
Local $sPipPath = "C:\Users\User\Documents\PIP업데이트" & $sTodayDate & ".xlsx"

ConsoleWrite("정리 시작. 오늘자 PIP 파일 확인: " & $sPipPath & @CRLF)

If FileExists($sPipPath) Then
    ConsoleWrite("✅ 오늘자 PIP 파일이 이미 있어요 (ERP 업로드 성공한 것으로 보임) — 엑셀은 저장 없이 바로 닫습니다." & @CRLF)
Else
    ConsoleWrite("⚠ 오늘자 PIP 파일이 없어요 — 엑셀 창을 찾아서 그 이름으로 먼저 저장합니다." & @CRLF)
    ; MARK: 엑셀 메인 창의 윈도우 클래스는 XLMAIN으로 고정되어 있습니다.
    Local $hExcelWin = WinGetHandle("[CLASS:XLMAIN]")
    If $hExcelWin = 0 Then
        ConsoleWrite("⚠ 열려있는 엑셀 창을 못 찾았어요. 저장 없이 넘어갑니다." & @CRLF)
    Else
        WinActivate($hExcelWin)
        Sleep(800)
        Send("{F12}") ; 엑셀의 "다른 이름으로 저장" 단축키 — 바로 저장 대화상자를 띄웁니다.
        Sleep(1000)

        ; 저장 대화상자 찾기 (제목이 "다른 이름으로 저장"일 수도, 영문일 수도 있어서 표준
        ; 대화상자 클래스로 넓게 찾습니다 — 열기 대화상자 때와 같은 방식입니다.
        Local $hSaveDlg = WinWait("[CLASS:#32770]", "", 10)
        If $hSaveDlg = 0 Then
            ConsoleWrite("⚠ 저장 대화상자를 못 찾았어요. 첫 시도라 구조가 다를 수 있어요 — 저장 없이 넘어갑니다." & @CRLF)
        Else
            WinActivate($hSaveDlg)
            Sleep(500)
            ; MARK: 파일선택창(열기)때 확인한 것과 같은 구조로 추정 — 파일명칸=Edit1, 저장버튼=Button2.
            ; 처음 시도라 버튼 번호가 다를 수 있어요 — 안 되면 스크린샷 주시면 바로 고칠게요.
            ControlSetText($hSaveDlg, "", "Edit1", $sPipPath)
            Sleep(500)
            ControlClick($hSaveDlg, "", "Button2")
            Sleep(1500)
            ; 파일 형식이 다르거나 이미 같은 이름의 파일이 있으면 "계속 이 형식 유지"/"덮어쓰시겠습니까"
            ; 같은 확인 팝업이 하나 더 뜰 수 있어서, Enter로 기본 선택(보통 '예'/'예')을 확정합니다.
            Send("{ENTER}")
            Sleep(1500)
            ConsoleWrite("✅ 저장 시도 완료." & @CRLF)
        EndIf
    EndIf
EndIf

ConsoleWrite("크롬/엑셀 강제 종료 중..." & @CRLF)
ProcessClose("chrome.exe")
ProcessClose("EXCEL.EXE")
Sleep(500)
ConsoleWrite("✅ 정리 완료." & @CRLF)
