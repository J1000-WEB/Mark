// 롯데면세 전용 — 새벽 2시에 성공하는 것으로 확인됨(실측). 딱 그 시간에만 시도합니다.
const { runChannelScheduler } = require("./channel-scheduler.js");
const { fetchLotte } = require("./build-inshop-upload.js");

runChannelScheduler({
  channelKey: "lotte",
  channelName: "롯데면세",
  retryHours: [2],
  fetchFn: fetchLotte,
});
