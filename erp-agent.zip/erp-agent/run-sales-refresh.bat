@echo off
REM MARK ERP Agent - 매출(SL1010) 40분마다 갱신
cd /d "%~dp0"

echo ============================================
echo  MARK 매출 실시간 갱신 (10분 주기) - 실행중
echo  (이 창을 닫으면 멈춥니다)
echo ============================================
echo.

node run-loop-interval.js sales-refresh.js 10

echo.
echo (멈췄습니다. 아무 키나 누르면 창이 닫힙니다)
pause >nul
