// 무신사 파트너센터 완전자동화 스크립트
//
// 로그인(아이디/비번) → OTP(비밀키로 자동 계산) → 정산 데이터 조회까지 자동으로 진행합니다.
// bizest.musinsa.com 쪽에 Cloudflare 보호가 걸려있어서, 순수 요청 조립 대신 진짜 브라우저로
// 진행합니다(로그인 성공하면 쿠키가 자동으로 생기고, 그걸로 데이터 API 요청까지 같은
// 브라우저 안에서(fetch) 실행합니다).
//
// 준비물(.env):
//   MUSINSA_USER_ID=sojaechun
//   MUSINSA_PASSWORD=실제비밀번호
//   MUSINSA_OTP_SECRET=E5UYTH4NPTMNNUV72KEOF3643VQT2FC4
//
// 설치(처음 한 번만):
//   npm install puppeteer xlsx dotenv otplib

const puppeteer = require("puppeteer");
const path = require("path");
const os = require("os");
require("dotenv").config();

const USER_ID = process.env.MUSINSA_USER_ID;
const PASSWORD = process.env.MUSINSA_PASSWORD;
const OTP_SECRET = process.env.MUSINSA_OTP_SECRET;

function log(...args) {
  console.log(`[${new Date().toLocaleString("ko-KR")}]`, ...args);
}

async function waitMs(ms) {
  await new Promise((r) => setTimeout(r, ms));
}

function getOtpCode() {
  // MARK: otplib 라이브러리(설치된 버전)가 표준 TOTP 값과 다른 결과를 내서(실측 확인함),
  // RFC 6238 표준 TOTP 계산식을 직접 구현했습니다. Python pyotp와 결과가 정확히 일치함을 확인했습니다.
  const crypto = require("crypto");
  function base32Decode(base32) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let bits = "";
    for (const char of base32.replace(/=+$/, "").toUpperCase()) {
      const val = alphabet.indexOf(char);
      if (val === -1) continue;
      bits += val.toString(2).padStart(5, "0");
    }
    const bytes = [];
    for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
    return Buffer.from(bytes);
  }
  const key = base32Decode(OTP_SECRET);
  const counter = Math.floor(Date.now() / 1000 / 30);
  const counterBuf = Buffer.alloc(8);
  counterBuf.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", key).update(counterBuf).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code =
    ((hmac[offset] & 0x7f) << 24) | ((hmac[offset + 1] & 0xff) << 16) | ((hmac[offset + 2] & 0xff) << 8) | (hmac[offset + 3] & 0xff);
  return String(code % 10 ** 6).padStart(6, "0");
}

async function main() {
  if (!USER_ID || !PASSWORD || !OTP_SECRET) {
    console.error("MUSINSA_USER_ID / MUSINSA_PASSWORD / MUSINSA_OTP_SECRET가 .env에 없습니다.");
    process.exit(1);
  }

  let fromDate = process.argv[2];
  let toDate = process.argv[3] || fromDate;
  if (!fromDate) {
    const y = new Date();
    y.setDate(y.getDate() - 1);
    fromDate = `${y.getFullYear()}${String(y.getMonth() + 1).padStart(2, "0")}${String(y.getDate()).padStart(2, "0")}`;
    toDate = fromDate;
  }
  const fromDateDash = `${fromDate.slice(0, 4)}-${fromDate.slice(4, 6)}-${fromDate.slice(6, 8)}`;
  const toDateDash = `${toDate.slice(0, 4)}-${toDate.slice(4, 6)}-${toDate.slice(6, 8)}`;

  log("브라우저 여는 중...");
  const browser = await puppeteer.launch({ headless: false, args: ["--disable-blink-features=AutomationControlled"] });
  const page = await browser.newPage();
  const realUA = (await browser.userAgent()).replace("HeadlessChrome", "Chrome");
  await page.setUserAgent(realUA);

  try {
    log("로그인 페이지 이동 중...");
    await page.goto("https://partner.musinsa.com/", { waitUntil: "networkidle2" });
    await waitMs(2000);

    log("아이디/비밀번호 입력 중...");
    await page.type('input[name="id"]', USER_ID, { delay: 30 });
    await page.type('input[name="password"]', PASSWORD, { delay: 30 });

    log("로그인 버튼 클릭...");
    await page.click('button[type="submit"]');
    await waitMs(2500);

    // OTP 입력칸이 나타났는지 확인 (아직 정확한 선택자를 몰라서, 새로 나타난 텍스트 입력칸을 찾습니다)
    log("OTP 입력칸 찾는 중...");
    let otpInputSelector = await page.evaluate(() => {
      const candidates = Array.from(document.querySelectorAll("input")).filter((el) => {
        const type = (el.getAttribute("type") || "text").toLowerCase();
        return (type === "text" || type === "tel" || type === "number") && el.offsetWidth > 0 && el.offsetHeight > 0;
      });
      for (const el of candidates) {
        const attrs = `${el.name || ""} ${el.id || ""} ${el.placeholder || ""}`.toLowerCase();
        if (attrs.includes("otp") || attrs.includes("code") || attrs.includes("인증")) {
          // 안정적인 선택자를 만들기 위해 임시 표시(data속성)를 답니다.
          el.setAttribute("data-mark-otp", "1");
          return 'input[data-mark-otp="1"]';
        }
      }
      return null;
    });

    if (!otpInputSelector) {
      await page.screenshot({ path: path.join(process.cwd(), "디버그_OTP화면.png") });
      throw new Error("OTP 입력칸을 못 찾았어요. (디버그_OTP화면.png 확인해주세요 — 화면 구조를 보고 선택자를 다시 잡아야 해요)");
    }

    const otpCode = getOtpCode();
    log(`OTP 코드 계산: ${otpCode}`);
    await page.type(otpInputSelector, otpCode, { delay: 50 });
    await waitMs(500);

    // OTP 확인 버튼 클릭 (로그인 버튼과 같은 형태일 가능성이 높음)
    const otpSubmitClicked = await page.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll("button"));
      const btn = buttons.find((b) => (b.textContent || "").includes("확인") || (b.textContent || "").includes("인증") || b.type === "submit");
      if (btn) {
        btn.click();
        return true;
      }
      return false;
    });
    if (!otpSubmitClicked) throw new Error("OTP 확인 버튼을 못 찾았어요.");

    log("로그인 처리 대기 중...");
    await waitMs(4000);

    const loggedIn = await page.evaluate(() => !document.querySelector('input[name="password"]'));
    if (!loggedIn) {
      await page.screenshot({ path: path.join(process.cwd(), "디버그_로그인실패.png") });
      throw new Error("로그인이 완료되지 않은 것 같아요. (디버그_로그인실패.png 확인해주세요)");
    }
    log("✅ 로그인 성공!");

    // 정산 데이터 화면(bizest.musinsa.com)으로 이동 — 같은 브라우저라 쿠키(Cloudflare 통과분 포함) 공유됨
    log("정산 데이터 화면으로 이동 중...");
    const dataPage = await browser.newPage();
    await dataPage.setUserAgent(realUA);
    await dataPage.goto("https://bizest.musinsa.com/po/order-group-admin/account/stt01?&LAYOUT_TYPE=popup", {
      waitUntil: "networkidle2",
    });
    await waitMs(2000);

    log(`매출 데이터 조회 중: ${fromDateDash} ~ ${toDateDash}`);
    const result = await dataPage.evaluate(
      async (fromDateDash, toDateDash) => {
        const body = `PAGE=1&S_SDATE=${fromDateDash}&S_EDATE=${toDateDash}&S_SHOP_LIST=&LIMIT=1000`;
        const res = await fetch("https://bizest.musinsa.com/po/order-group-admin/account/stt01/search", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "X-Requested-With": "XMLHttpRequest" },
          body,
          credentials: "include",
        });
        const text = await res.text();
        return { status: res.status, text };
      },
      fromDateDash,
      toDateDash
    );

    if (result.status !== 200) {
      throw new Error(`조회 실패 (status=${result.status}): ${result.text.slice(0, 500)}`);
    }

    const data = JSON.parse(result.text);
    if (data.result !== "success") {
      throw new Error(`조회 실패: ${JSON.stringify(data).slice(0, 500)}`);
    }

    const rows = data.data || [];
    log(`조회 완료: ${rows.length}건 (합계 제외)`);

    if (!rows.length) {
      log("데이터가 없습니다.");
      return;
    }

    const XLSX = require("xlsx");
    const mapped = rows.map((r) => ({
      일자: (r.date || "").slice(0, 10).replace(/-/g, ""),
      매장명: r.shopName || "",
      브랜드: r.brandName || "",
      품번: r.styleNo || "",
      상품명: r.goodsName || "",
      옵션: r.goodsOption || "",
      바코드: r.barcode || "",
      판매수량: Number(r.quantity || 0),
      판매금액: Number(r.saleAmount || 0),
      정산금액: Number(r.settlementAmount || 0),
    }));
    const ws = XLSX.utils.json_to_sheet(mapped);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "무신사매출");
    const dateLabel = fromDate === toDate ? fromDate : `${fromDate}_${toDate}`;
    const outPath = path.join(os.homedir(), "Desktop", `무신사매출_${dateLabel}.xlsx`);
    XLSX.writeFile(wb, outPath);
    log(`✅ 완료! 저장: ${outPath}`);
  } catch (err) {
    console.error("⚠ 실패:", err.message || err);
    console.error("   (브라우저 창은 안 닫았어요 — 직접 화면을 확인해주세요)");
    await waitMs(60000);
    process.exitCode = 1;
  } finally {
    await browser.close();
  }
}

main();
